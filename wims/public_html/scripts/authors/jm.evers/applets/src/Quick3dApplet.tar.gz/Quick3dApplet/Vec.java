//  Copyright (C) 2004 Philip Proudman
//
//  This file is part of Quick3dApplet
//
//  Quick3dApplet is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  Quick3dApplet is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with Quick3dApplet in the file called "COPYING" in the top directory;
//  if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


package Quick3dApplet;

public final class Vec
{
    public float x;
    public float y;
    public float z;

    public Vec() {}

    public Vec(Vec a) {
        x = a.x; y = a.y; z = a.z;
    }
    
    public Vec(float xi, float yi, float zi) {
        x = xi; y = yi; z = zi;
    }

    public void set(float xi, float yi, float zi) {
        x = xi; y = yi; z = zi;
    }
    
    public void set(Vec a) {
        x = a.x; y = a.y; z = a.z;
    }

    public String toString() {
        return (x+","+y+","+z);
    }
    
    public float magnitude() {
        return (float)(Math.sqrt(x*x + y*y + z*z));
    }

    public void makeUnitVec() {
        float m = 1f/magnitude();
        x *= m;
        y *= m;
        z *= m;
    }

    public static float dot(Vec v1, Vec v2) {
        return v1.x*v2.x + v1.y*v2.y + v1.z*v2.z;
    }

    public static Vec add(Vec v1, Vec v2) {
        return new Vec(v1.x+v2.x, v1.y+v2.y, v1.z+v2.z);
    }

    public static Vec sub(Vec v1, Vec v2) {
        return new Vec(v1.x-v2.x, v1.y-v2.y, v1.z-v2.z);
    }

    public static Vec cross(Vec v1, Vec v2) {
        return new Vec(v1.y*v2.z - v1.z*v2.y, v1.z*v2.x - v1.x*v2.z, v1.x*v2.y - v1.y*v2.x);
    }

    public static Vec mul(Vec v, float s) {
        return new Vec(v.x*s, v.y*s, v.z*s);
    }
}
