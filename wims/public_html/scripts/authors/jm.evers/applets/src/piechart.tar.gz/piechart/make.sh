#!/bin/sh
rm PieChart.class 

javac -source 1.4 -target 1.4 PieChart.java

if [ -e "PieChart.class" ] ;then
    jar cvf 2D_pie.jar *.class
    rm -rf ~/.java
    mozilla file://`pwd`/1.html
else
    echo "compile error"
    read whatever
fi