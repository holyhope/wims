//  Copyright (C) 2004 Philip Proudman
//
//  This file is part of Quick3dApplet
//
//  Quick3dApplet is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  Quick3dApplet is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with Quick3dApplet in the file called "COPYING" in the top directory;
//  if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


package Quick3dApplet;

public abstract class Tri
{
    // The points of the triangle
    public Vertex a, b, c;

    // Used by the render method...
    Line2 l[] = new Line2[3]; // Outline
    Line2 rightLine = null;
    float depth;
    float deltaDepth;
    byte in = 0; // bit 0=a, 1=b, 2=c
    byte fastCullNum;
    
    public Tri(Vertex ai, Vertex bi, Vertex ci) {
        a = ai;
        b = bi;
        c = ci;
        l[0] = new Line2((byte)1, this);
        l[1] = new Line2((byte)2, this);
        l[2] = new Line2((byte)4, this);
    }

    abstract void init(Render r, Vec norm);
    abstract void map(Render r, Line2 left, float y);
    abstract void prep(Line2 left, int x);
    abstract void draw(Render r, Pixstore px, int mi, float xStart);
    abstract void nextLine();
    abstract void getClipped(float clipPlane, RenderObject cro);

    public final Vec getOrigNorm() {
        // Will not be unit vector yet!!
        Vec d1 = Vec.sub(b.pos, a.pos);
        Vec d2 = Vec.sub(c.pos, a.pos);
        return Vec.cross(d1,d2);
    }

    public final Vec getNorm() {
        // Works on the transformed coordinates
        // Will not be unit vector yet!!
        Vec d1 = Vec.sub(b.xformed, a.xformed);
        Vec d2 = Vec.sub(c.xformed, a.xformed);
        return Vec.cross(d1,d2);
    }
}
