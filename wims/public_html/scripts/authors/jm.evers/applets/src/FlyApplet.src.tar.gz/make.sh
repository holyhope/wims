#!/bin/sh


if [ ! -e test.html ] ; then

echo "
<html>
 <body>
    <script type=\"text/javascript\">
	function ReadThis(){
	    reply = document.getElementById('FlyApplet').ReadApplet();
	    alert(reply);
	}    
    </script>
    <table bgcolor=\"green\" cellpadding=100 >
	<th>
	<td>
	    <applet id=\"FlyApplet\" name=\"FlyApplet\" code=\"FlyApplet.class\" archive=\"FlyApplet.jar\" width=\"500\" height=\"500\">
		<param name=\"file\" value=\"fly.script\">
	    </applet>
	</th>
	</td>
    </table>

    <p>
    <input type=\"button\" name=\"flyapplet\" value=\"clicked points\" onclick=\"javascript:ReadThis();\">
 </body>
</html>
" > test.html

fi 

rm *.class
rm *.jar
rm -rf ~/.java
javac  *.java

if [ -e FlyApplet.class ] ; then
    jar cvf FlyApplet.jar *.class org
    find . -name "*.class" -exec rm -v "{}" ";"
    tar cvzf FlyApplet.src.tar.gz *.java org test.html make.sh fly.script
    appletviewer test.html
#    mozilla file://`pwd`/test.html
else
    read hmmm
fi



