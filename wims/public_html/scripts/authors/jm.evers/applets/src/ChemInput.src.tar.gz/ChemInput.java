/*
    J.M. Evers 18/11/2009
						 +
    A chemical formula input applet for Wims: H O
					       3
    Based on applet code from http://web.uconn.edu/~cdavid
    See below.
    No license information found.
    No licence required...


<html>
    <body>
    <script type="text/javascript">
	function ReadThis(t){
	    var reply="";
	    if(t == 1){
		reply = document.getElementById('ChemInput').ReadAnswer();
	    }
	    else
	    {
		reply = document.getElementById('ChemInput').ReadLatex();
	    }
	alert(reply);
    }
    </script>
    <applet id="ChemInput" name="ChemInput" code="ChemInput.class" archive="ChemInput.jar" width="400" height="400">
	<param name="applettext" value="H_{3}0^{+} + OH^{-} \leftrightarrow "><!-- latex wims question  ; default empty -->
	<param name="send_applettext" value="yes"><!-- default no options 0,1 : ReadLatex() ignores this setting  -->
	<param name="lang" value="nl"><!-- default en optional nl,fr -->
	<param name="fontsize" value="28"><!-- default 48 -->
	<param name="pencolor" value="0,0,255,0.8"><!-- default black  ; R,G,B,alpha -->
	<param name="bgcolor1" value="240,240,240,0.2"><!-- default white ; R,G,B,alpha -->
	<param name="bgcolor2" value="0,255,0,0.8"><!-- default green ;R,G,B,alpha -->
	<param name="chembuttons" value="1"><!-- Default 1/yes ; options 0/no ; shows a few arrows-->
	<param name="navbuttons"  value="1"><!-- Default 1/yes ; options 0/no ; shows a few navigation buttons -->
    </applet>                           
    
    <input type="button" name="Ascii" value="Ascii" onclick="javascript:ReadThis(1);">
    <input type="button" name="LateX" value="LateX" onclick="javascript:ReadThis(0);">       
    
    </body>
</html>
*/

import java.awt.*;
import java.awt.event.*;                                                                                                
import java.applet.*;
import java.util.*;
import java.io.*;
import java.awt.Color;

public class ChemInput extends  Applet {
    public void init(){
	String param;
	param =  getParameter("lang");
	if(param != null){
	    if(param.equalsIgnoreCase("nl")){Clear="Wissen";Solid="vast";Gas="gas";Up="naar boven";Down="naar beneden";Precip="neerslag";}
	    else{ if(param.equalsIgnoreCase("fr")){Clear="Effacer";Solid="solide";Gas="gaz";Up="Up";Down="Down";Precip="precipite";}}
	}
	param =  getParameter("send_applettext");
	if(param != null){ if(param.equalsIgnoreCase("yes") || param.equals("1")){send_applettext = true; }}

	param =  getParameter("chembuttons");
	if(param != null){ if(param.equalsIgnoreCase("no") || param.equals("0")){chembuttons = false; }}

	param =  getParameter("navbuttons");
	if(param != null){ if(param.equalsIgnoreCase("no") || param.equals("0")){navbuttons = false; }}
	
 	param =  getParameter("fontsize");
	if(param != null){fontsize =  Integer.parseInt(param);}

	param=getParameter("pencolor");     
        if (param != null && param.length()>0){pencolor = readColor(param);}
	else pencolor=new Color(0,0,0);                                                                                                                                                           

	param=getParameter("bgcolor1");     
        if (param != null && param.length()>0){bgcolor1 = readColor(param);}
	else bgcolor1=new Color(255,255,255);                                                                                                                                                           

	param=getParameter("bgcolor2");     
        if (param != null && param.length()>0){bgcolor2 = readColor(param);}
	else bgcolor2=new Color(0,255,0);                                                                                                                                                           
	
	xsize = getSize().width;                                  
        ysize = getSize().height; 
	resize(xsize,ysize); 
	setLayout(new BorderLayout());
	if(navbuttons){
	    Panel p1 = new Panel();
	    p1.setLayout(new FlowLayout());
	    p1.add(new Button(Up));
	    p1.add(new Button(Down));
	    p1.add(new Button(Clear)); 
	    this.add("North", p1);
	}
	if(chembuttons){
	    Panel p2 = new Panel();
	    p2.add(new Button(Arrow1));
	    p2.add(new Button(Arrow2));
	    p2.add(new Button(Solid));
	    p2.add(new Button(Gas));
	    p2.add(new Button(Precip));
	    this.add("South", p2);
	}
	cd_disp = new ChemInputCanvas();
	this.add("Center", cd_disp);
	param=getParameter("applettext");
	if(param != null){
	    param=filter1(param,"param2uni");
	    applettext = param;
	    s1=applettext;
	    cd_disp.update(s1);
	}
	cd_disp.setBackground(bgcolor1);

	start();
    }
    public boolean mouseDown(Event e, int x, int y) {
	if(y<(cd_disp.cy+cd_disp.fm.getHeight())){
	    cd_disp.setsuper(1);
	}
	else
	{
	    if(y>(ChemInputCanvas.cy-ChemInputCanvas.fm.getHeight())){
		cd_disp.setsuper(-1);
	    }
	    else 
	    {
		 cd_disp.setsuper(0);
	    }
	}
	return true; 
    } 
    
    
    public boolean keyDown(Event evt, int key){
	if (key == Event.LEFT || key == 8 || key == 127){
	    StringBuffer new_str = new StringBuffer(100);
	    new_str.append(s1);
	    int len = new_str.length();//{
	    if(new_str.charAt(len-1) == '}'){
		new_str.setLength(len-1-3);
	    }
	    else 
	    {
		new_str.setLength(len-1);
	    }
	    s1 = new_str.toString();
	    cd_disp.update(s1);
	    return true;
	}
	else
	{
	    if (key == Event.UP || key == 94 ){cd_disp.setsuper(1); return true;}
	    else
	    if(key == Event.DOWN || key == 95){cd_disp.setsuper(-1);return true;}
	    else
	    if( key >= 32 && key <= 122  ){
	    //
		StringBuffer new_str = new StringBuffer(100);
		StringBuffer cd = new StringBuffer(1);
		char key_char = (char) key;//cast key -> char
		cd.append(key_char);//need to convert to character
		new_str.append(s1);
		if(cd_disp.state() == 1){new_str.append("^{"+cd+"}");}
		else
		if(cd_disp.state() == -1){new_str.append("_{"+cd+"}");}
		else{ new_str.append(cd);}
		s1 = new_str.toString();
		cd_disp.update(s1);
		return true;	    
	    }
	    else
	    return false;
	}
    }
    
    
    public boolean action(Event evt, Object arg) {
	if (arg.equals(Clear)){
	    StringBuffer cd_str = new StringBuffer(100);
	    cd_disp.clear();
	    cd_str.append(applettext);
	    s1=cd_str.toString();
	    cd_disp.update(s1);
	    return true;
	}
	if(arg.equals(Arrow1)){
	    StringBuffer cd_str = new StringBuffer(100);
	    cd_str.append(s1+" "+Arrow1+" ");
	    s1 = cd_str.toString();
	    cd_disp.update(s1);
	    return true;
	}
	if(arg.equals(Arrow2)){
	    StringBuffer cd_str = new StringBuffer(100);
	    cd_str.append(s1+" "+Arrow2+" ");
	    s1 = cd_str.toString();
	    cd_disp.update(s1);
	    return true;
	}
	
	if (arg.equals(Down)){
	    cd_disp.setsuper(-1);
	    return true;
	}

	if (arg.equals(Up)){
	    cd_disp.setsuper(1);
	    return true;
	}

	if(arg.equals(Solid)){
	    StringBuffer cd_str = new StringBuffer(100);
	    cd_str.append(s1+"_{(s)} ");
	    s1 = cd_str.toString();
	    cd_disp.update(s1);
	    return true;
	}

	if(arg.equals(Gas)){
	    StringBuffer cd_str = new StringBuffer(100);
	    cd_str.append(s1+"_{(g)} ");
	    s1 = cd_str.toString();
	    cd_disp.update(s1);
	    return true;
	}

	if(arg.equals(Precip)){
	    StringBuffer cd_str = new StringBuffer(100);
	    cd_str.append(s1+"_{\u2193} ");
	    s1 = cd_str.toString();
	    cd_disp.update(s1);
	    return true;
	}
	    

	return false;
    }

    public Color readColor(String param){
    	    param=param.replace(':',',');param=param.replace(';',',');                                                  
            StringTokenizer q = new StringTokenizer(param, ",");                                                        
            String k;float rgb;R1=1.0f;G1=1.0f;B1=1.0f;alpha=0.5f;
            for( int a=0; a<4 ; a++){                                                                                   
                k=q.nextToken();                                                                                        
                rgb=Float.parseFloat(k);                                                                         
                if(rgb<0){rgb=0.0f;}                                                                                       
                if(rgb>255){rgb=1.0f;}                                                                                   
                if(a == 0){R1 = (float)rgb/255;}                                                                                   
                else if(a == 1){G1 = (float)rgb/255;}                                                                              
                else if(a == 2){B1 = (float)rgb/255;}                                                                              
                else if(a == 3){alpha = rgb;}                                                                              
            }
	    Color a = new Color(R1,G1,B1,alpha);
	    return a;                                                                                                           
	}

    public String ReadLatex(){
	String reply=replace(s1,"}^{","");
	reply=replace(reply,"}_{","");
	reply=filter1(reply,"uni2latex");
	return reply;	
    }
    public String ReadAnswer(){
	if(!send_applettext){s1=replace(s1,applettext,"");}
	String reply=replace(s1,"}^{","");
	reply=replace(reply,"}_{","");
	reply=replace(reply,"{","");	
	reply=replace(reply,"}","");
	reply=filter1(reply,"uni2ascii");
	return reply;
    }
    
     public boolean keyUp(Event event, int key){                                                                         
        return true;                                                                                                    
    } 
    

    public static String replace(String source, String pattern, String replace){
        if (source!=null){
	    final int len = pattern.length();
	    StringBuffer sb = new StringBuffer();
	    int found = -1;
	    int start = 0;
	    while( (found = source.indexOf(pattern, start) ) != -1) {
		sb.append(source.substring(start, found));
		sb.append(replace);
		start = found + len;
	    }
	    sb.append(source.substring(start));
	    return sb.toString();
        }
        else return "";
    }
   //
    private String filter1(String S1 , String k ){
        int p;String r1;String r2;
	String d1[] = new String[]{"->","=>","-->","==>","\\rightarrow","<->","<=>","<-->","<==>","\\leftrightarrow","\\downarrow","\\uparrow"};
	
	String d2[] = new String[]{"\u2192","\u2192","\u2192","\u2192","\u2192","\u21C4","\u21C4","\u21C4","\u21C4","\u21C4","\u2193","\u2191"};

	String d3[] = new String[]{"->","->","->","->","->","<->","<->","<->","<->","<->","(s)","(g)"};

	String d4[] = new String[]{"\\rightarrow","\\rightarrow","\\rightarrow","\\rightarrow","\\rightarrow",
	"\\leftrightarrow","\\leftrightarrow","\\leftrightarrow","\\leftrightarrow","\\leftrightarrow","\\downarrow","\\uparrow"};
	
	int d=d1.length;
	//int e=d1.length;int f=d1.length;if( d!=e || d!=f){System.out.println("ERROR array lengte verschil d= " + d +"\n e= "+ e +"\n f =" +f) ;}
	if(k.equals("param2uni")){// from ascii applettext-param to unicode applet
    	    for ( p=0;p<d;p++){                                                                                                                
        	r1=d1[p];                                                                                                                 
        	r2=d2[p];                                                                                                                 
        	S1=replace(S1,r1,r2);                                                                                                          
    	    }
	}
	else
	{
	    if(k.equals("uni2ascii")){// from applet unicode to ascii [wims answer]
    		for ( p=0;p<d;p++){                                                                                                                
        	    r1=d2[p];                                                                                                                 
        	    r2=d3[p];                                                                                                                 
        	    S1=replace(S1,r1,r2);                                                                                                          
    		}
	    }
	    else
	    {
		if(k.equals("uni2latex")){// from applet unicode to latex [wims presentation presentation] 
    		    for ( p=0;p<d;p++){                                                                                                                
        		r1=d2[p];                                                                                                                 
        	        r2=d4[p];                                                                                                                 
        		S1=replace(S1,r1,r2);
		    }                                                                                                         
    		}
		else
		{
		System.out.println("error");
		}
	    }
	}
        return S1;                                                                                                                         
    }

	float R1,G1,B1,alpha;
	public boolean send_applettext = false;
	public boolean chembuttons = true;
	public boolean navbuttons = true;
	public boolean DeBug = false;
	public ChemInputCanvas cd_disp;
        public static StringBuffer cd_str;
        public static String s1 = "";
	public Checkbox sup;
	public Checkbox sub;
	public Checkbox normal;
	public static int fontsize = 48;
	public static int xsize;
	public static int ysize;
	public static String applettext ="";
	public String Solid="s";
	public String Gas="g";
	public String Clear="Clear";
	public String Arrow1="\u2192";
	public String Arrow2="\u21C4";
	public String Up="Up";
	public String Down="Down";
	public String Precip="Precipitate";
	public Color bgcolor1;
	public static Color pencolor;
	public static Color bgcolor2;
}




/*
<html><head>
<meta http-equiv="content-type" content="text/html; charset=ISO-8859-1"><title>Inputting Chemical Symbols Using Java</title></head><body><h1>Java Input for Chemical Symbols</h1>
This is our second (and perhaps last) attempt at creating a
chemical symbol input device which would allow students
to enter chemical formulii in the approximate form that textbooks
use.
<br>ChemSymIn is written as an applet, which means that one needs a 
&lt;APPLET&gt;&lt;/APPLET&gt; line of html code to activate it.
<br>
<pre>import java.awt.*;
import java.applet.*;
import java.util.*;
import java.io.*;

public class ChemSymIn extends  Applet {

   public void init() { 
	resize(550,300); 
	setLayout(new BorderLayout());

  

 Panel p = new Panel();
   p.setLayout(new FlowLayout());
   p.add(new Button("Submit for Grading")); 
   p.add(new Button("ReDisplay")); 
   this.add("North", p);


   cd_disp = new ChemSymInCanv2();
   this.add("Center", cd_disp);
	cd_disp.update("Click `ReDisplay' to Start");
	start();
   }
   
	public boolean handleEvent(Event evt) {  
		if (evt.id == Event.WINDOW_DESTROY
			&amp;&amp; evt.target == this) System.exit(0);//for the Help about
      return super.handleEvent(evt);
   }
   

	public boolean keyDown(Event evt, int key){
		if(DeBug){	
			System.out.println("Event (keydown) = "+evt);
			System.out.println("key = "+ key);
			}	
		if (key == Event.LEFT || key == 8 || key == 127) {
			StringBuffer new_str = new StringBuffer(100);
			new_str.append(s1);
			if(DeBug) System.out.println("s1 before delete = "+s1);
			int len = new_str.length();
			if(new_str.charAt(len-1) == '}')new_str.setLength(len-1-3);
			else new_str.setLength(len-1);
			s1 = new_str.toString();
			if(DeBug) System.out.println("s1 after delete = "+s1);
			cd_disp.update(s1);
			return true;
			}
		else
		if (key == Event.UP){
			cd_disp.setsuper(1);
			return true;
			}
		else
		if(key == Event.DOWN){
			cd_disp.setsuper(-1);
			return true;
			}
		else
		if( key &gt;= 40 &amp;&amp; key &lt;= 122  ){
			StringBuffer new_str = new StringBuffer(100);
			StringBuffer cd = new StringBuffer(1);
			char key_char = (char) key;//cast key -&gt; char
			cd.append(key_char);//need to convert to character
			if(DeBug){
				System.out.println("s1 before appending key_char = "+s1);
				System.out.println("s1 before appending key_char = "+s1);
				}
			new_str.append(s1);
			if(cd_disp.state() == 1){new_str.append("^{"+cd+"}");}
			else
			if(cd_disp.state() == -1){new_str.append("_{"+cd+"}");}
			else{ new_str.append(cd);}
			s1 = new_str.toString();
			cd_disp.update(s1);
			return true;
			}
		return false;
	}
		
	public boolean action(Event evt, Object arg) {
		String ans = getParameter("answer");
		if(DeBug){	
			System.out.println("Event (action) = "+evt);
			System.out.println("arg = "+ arg);
			}
	   if (arg.equals("Submit for Grading")){
			if (s1.equals(ans)){
				StringBuffer cd_str = new StringBuffer(100);
				cd_str.append (" YES ");
				String s9 = cd_str.toString();
				cd_disp.update(s9);
				return true;
				}
			else{
				StringBuffer cd_str = new StringBuffer(100);
				cd_str.append (" NO ");
				String s9 = cd_str.toString();
				cd_disp.update(s9);
				return true;
				}
			}
		if (arg.equals("ReDisplay")){
			cd_disp.clear();
			StringBuffer cd_str = new StringBuffer(100);
			cd_str.append(s1);
			s1 = cd_str.toString();
			cd_disp.update(s1);
			return true;
			}
		else
		return false;
	}




	public boolean DeBug = false;
        public TextField display;
	public String ans;
        private TextField minuteField;
	public ChemSymInCanv2 cd_disp;
        public static StringBuffer cd_str;
        public String s1 = "";
	public Checkbox sup;
	public Checkbox sub;
	public Checkbox normal;
   
}



class ChemSymInCanv2 extends Canvas {
	public void paint(Graphics g )
   {
	Font f = new Font("TimesRoman",Font.BOLD,48);
	Font n = new Font("TimesRoman",Font.BOLD,16);
	FontMetrics fm = g.getFontMetrics(f);
	FontMetrics nm = g.getFontMetrics(n);
	g.setFont(f);
	Dimension d = size();
	int client_width = d.width ;
	int sup_sub = 0;
	int inc = 0;
	int h_mul = 1;
	int i,j = 0;
	boolean test;
	int client_height = d.height;
	int cx = client_width /2;
	int cy = client_height/2;

	StringBuffer t = new StringBuffer(100);
	t.insert(0,s1);//copy s1 to t
	String s6 = t.toString();//convert t back to String s6



	for (i=0;i&lt;s6.length();i++){
		if (s6.indexOf("}") != -1){
				if(DeBug){System.out.println("index = "+s6.indexOf("^{"));}
				if (s6.indexOf("^{",i) == i || s6.indexOf("_{",i)==i){
				if (s6.indexOf("^{",i) == i ) sup_sub = 1;
				if (s6.indexOf("_{",i) == i ) sup_sub = -1;
					i = i +2;
					if(DeBug){System.out.println("in superscript (after i+2), line, i = "+i);}
					j = fm.getHeight()*h_mul/2;
					test = s6.substring(i,i+1).equals("}"); 	
				
					while ( !test){
						g.drawString(s6.substring(i,i+1),4+inc,cy-j*sup_sub);
						inc += fm.stringWidth(s6.substring(i,i+1));//width of font???
						i++;
						test = s6.substring(i,i+1).equals("}"); 	
						}
					}
				else {
					sup_sub = 0;
					if(DeBug)System.out.println("in Default line, i = "+i);
					j = 0;
					if(DeBug){
						System.out.println("s6.substring("+i+") = "+s6.substring(i,i+1));
						System.out.println("s6 = "+s6);
						}
					g.drawString(s6.substring(i,i+1),4+inc,cy+j*sup_sub);
					inc += fm.stringWidth(s6.substring(i,i+1));//width of font???
					if(DeBug)System.out.println("inc = "+inc);
					}
				}
			else {
				g.drawString(s6,4,cy);	
				break ;
				}
			}
	int charWidth = fm.charWidth('W');
	int maxChars = client_width / charWidth;
	g.setColor(Color.yellow);
	g.drawRect(4,cy-fm.getHeight()/2,client_width-8,30);
	g.setColor(Color.green);
	if(state() == 0) g.drawRect(4,cy-fm.getHeight()/2,client_width-8,30);
	if(state() == 1)g.drawRect(4,cy-2*fm.getHeight()/2,client_width-8,30);
	if(state() == -1)g.drawRect(4,cy,client_width-8,30);
	g.setColor(Color.blue);
	g.setFont(n);
	g.drawString("Enter characters using up and down arrows for `super' and `sub' scripts.",1,12);	
	g.drawString("`BackSpace', `Left Arrow', and `Delete' all remove last character.",1,12+nm.getHeight());	
	g.drawString("`ReDisplay' after `Submit for Grading' to see formula again.",1,12+2*nm.getHeight());	
	g.setColor(Color.green);
	g.drawString("Next character appears in Green Box.",1,12+9*nm.getHeight());	
	g.setColor(Color.yellow);
	if(First == 0) g.drawString("Choose `ReDisplay' to start.",300,12+9*nm.getHeight());	
	First = 1;
	g.setFont(f);
	g.setColor(Color.black);
   }
   
   public void setsuper(int flag) {  
      ChemSymInCanv2.super_flag = state()+flag;
		if(ChemSymInCanv2.super_flag == 2)ChemSymInCanv2.super_flag = -1;
		if(ChemSymInCanv2.super_flag == -2)ChemSymInCanv2.super_flag = 1;
      repaint();
		}
  
	public int state() {
		if (ChemSymInCanv2.super_flag == 1) return (1);
		else if (ChemSymInCanv2.super_flag == -1) return (-1);
		else return (0);
		}

   public void update(String args) {  
		ChemSymInCanv2.s1 = args;
		if(DeBug)System.out.println("args in subroutine update = "+args);
      repaint();
		}

   public void clear() {  
		ChemSymInCanv2.s1 = "";
		repaint();
  	 }

   
	public boolean DeBug = false;
   public StringBuffer c1;
	public String s1 = "";
	public int super_flag;
	public int First = 0;
	

}
</pre>
<hr>
Here is an annotated version of the above, commented to indicate
what is going on.
<p>
</p><pre>import java.awt.*;
import java.applet.*;
import java.util.*;
import java.io.*;

public class ChemSymIn extends  Applet {

   public void init() { 
	resize(550,300); 
	setLayout(new BorderLayout());

</pre>
The coding (above) first makes available subroutines from
various subroutine libraries (fortran terminology, sorry).
Next, the code tells the system how big a Java display
is going to be created. 
Finally, the code says that we will be using a BorderLayout,
i.e., one which uses `North', `South', etc., as indicators
of position.

<pre> Panel p = new Panel();
   p.setLayout(new FlowLayout());
   p.add(new Button("Submit for Grading")); 
   p.add(new Button("ReDisplay")); 
   this.add("North", p);

</pre>
We have here created a new panel, called p, whose internal
layout fill be a FlowLayout, i.e., left to right sequential.
It consists of two buttons, one for submission, and one for
clearing the display and re-displaying whatever is currently
contained in the `answer string'.
The last line adds p to the main BorderLayout, placing it 
at the top of the display.
<pre>   cd_disp = new ChemSymInCanv2();
</pre>
Below, you will see where ChemSymInCanv2 is created.
<pre>   this.add("Center", cd_disp);
</pre>
We have just added the ChemSymCanv2 display, called cd_disp,
to the main display, placing it in the center!
<pre>	cd_disp.update("Click `ReDisplay' to Start");
	start();
</pre>
Here we insert a message into the `answer string' which
will show the first time the applet is invoked, and never again.
<pre>   }
   
	public boolean handleEvent(Event evt) {  
		if (evt.id == Event.WINDOW_DESTROY
			&amp;&amp; evt.target == this) System.exit(0);//for the Help about
      return super.handleEvent(evt);
   }
   

	public boolean keyDown(Event evt, int key){
		if(DeBug){	
			System.out.println("Event (keydown) = "+evt);
			System.out.println("key = "+ key);
			}	
</pre>
Next, we are going to handle all left moving keys the same, i.e.,
Delete, BackSpace, and Left Arrow keys are handled here:
<pre>		if (key == Event.LEFT || key == 8 || key == 127) {
			StringBuffer new_str = new StringBuffer(100);
			new_str.append(s1);
			if(DeBug) System.out.println("s1 before delete = "+s1);
			int len = new_str.length();
			if(new_str.charAt(len-1) == '}')new_str.setLength(len-1-3);
			else new_str.setLength(len-1);
			s1 = new_str.toString();
			if(DeBug) System.out.println("s1 after delete = "+s1);
			cd_disp.update(s1);
			return true;
			}
		else
		if (key == Event.UP){
			cd_disp.setsuper(1);
			return true;
			}
		else
		if(key == Event.DOWN){
			cd_disp.setsuper(-1);
			return true;
			}
		else
		if( key &gt;= 40 &amp;&amp; key &lt;= 122  ){
			StringBuffer new_str = new StringBuffer(100);
			StringBuffer cd = new StringBuffer(1);
			char key_char = (char) key;//cast key -&gt; char
			cd.append(key_char);//need to convert to character
			if(DeBug){
				System.out.println("s1 before appending key_char = "+s1);
				System.out.println("s1 before appending key_char = "+s1);
				}
			new_str.append(s1);
			if(cd_disp.state() == 1){new_str.append("^{"+cd+"}");}
			else
			if(cd_disp.state() == -1){new_str.append("_{"+cd+"}");}
			else{ new_str.append(cd);}
			s1 = new_str.toString();
			cd_disp.update(s1);
			return true;
			}
		return false;
	}
		
	public boolean action(Event evt, Object arg) {
		String ans = getParameter("answer");
		if(DeBug){	
			System.out.println("Event (action) = "+evt);
			System.out.println("arg = "+ arg);
			}
	   if (arg.equals("Submit for Grading")){
			if (s1.equals(ans)){
				StringBuffer cd_str = new StringBuffer(100);
				cd_str.append (" YES ");
				String s9 = cd_str.toString();
				cd_disp.update(s9);
				return true;
				}
			else{
				StringBuffer cd_str = new StringBuffer(100);
				cd_str.append (" NO ");
				String s9 = cd_str.toString();
				cd_disp.update(s9);
				return true;
				}
			}
		if (arg.equals("ReDisplay")){
			cd_disp.clear();
			StringBuffer cd_str = new StringBuffer(100);
			cd_str.append(s1);
			s1 = cd_str.toString();
			cd_disp.update(s1);
			return true;
			}
		else
		return false;
	}




	public boolean DeBug = false;
        public TextField display;
	public String ans;
        private TextField minuteField;
	public ChemSymInCanv2 cd_disp;
        public static StringBuffer cd_str;
        public String s1 = "";
	public Checkbox sup;
	public Checkbox sub;
	public Checkbox normal;
   
}



class ChemSymInCanv2 extends Canvas {
	public void paint(Graphics g )
   {
	Font f = new Font("TimesRoman",Font.BOLD,48);
	Font n = new Font("TimesRoman",Font.BOLD,16);
	FontMetrics fm = g.getFontMetrics(f);
	FontMetrics nm = g.getFontMetrics(n);
	g.setFont(f);
	Dimension d = size();
	int client_width = d.width ;
	int sup_sub = 0;
	int inc = 0;
	int h_mul = 1;
	int i,j = 0;
	boolean test;
	int client_height = d.height;
	int cx = client_width /2;
	int cy = client_height/2;

	StringBuffer t = new StringBuffer(100);
	t.insert(0,s1);//copy s1 to t
	String s6 = t.toString();//convert t back to String s6



	for (i=0;i&lt;s6.length();i++){

		if (s6.indexOf("}") != -1){
				if(DeBug){System.out.println("index = "+s6.indexOf("^{"));}
				if (s6.indexOf("^{",i) == i || s6.indexOf("_{",i)==i){
				if (s6.indexOf("^{",i) == i ) sup_sub = 1;
				if (s6.indexOf("_{",i) == i ) sup_sub = -1;
					i = i +2;
					if(DeBug){System.out.println("in superscript (after i+2), line, i = "+i);}
					j = fm.getHeight()*h_mul/2;
					test = s6.substring(i,i+1).equals("}"); 	
				
					while ( !test){
						g.drawString(s6.substring(i,i+1),4+inc,cy-j*sup_sub);
						inc += fm.stringWidth(s6.substring(i,i+1));//width of font???
						i++;
						test = s6.substring(i,i+1).equals("}"); 	
						}
					}
				else {
					sup_sub = 0;
					if(DeBug)System.out.println("in Default line, i = "+i);
					j = 0;
					if(DeBug){
						System.out.println("s6.substring("+i+") = "+s6.substring(i,i+1));
						System.out.println("s6 = "+s6);
						}
					g.drawString(s6.substring(i,i+1),4+inc,cy+j*sup_sub);
					inc += fm.stringWidth(s6.substring(i,i+1));//width of font???
					if(DeBug)System.out.println("inc = "+inc);
					}
				}
			else {
				g.drawString(s6,4,cy);	
				break ;
				}
			}
	int charWidth = fm.charWidth('W');
	int maxChars = client_width / charWidth;
	g.setColor(Color.yellow);
	g.drawRect(4,cy-fm.getHeight()/2,client_width-8,30);
	g.setColor(Color.green);
	if(state() == 0) g.drawRect(4,cy-fm.getHeight()/2,client_width-8,30);
	if(state() == 1)g.drawRect(4,cy-2*fm.getHeight()/2,client_width-8,30);
	if(state() == -1)g.drawRect(4,cy,client_width-8,30);
	g.setColor(Color.blue);
	g.setFont(n);
	g.drawString("Enter characters using up and down arrows for `super' and `sub' scripts.",1,12);	
	g.drawString("`BackSpace', `Left Arrow', and `Delete' all remove last character.",1,12+nm.getHeight());	
	g.drawString("`ReDisplay' after `Submit for Grading' to see formula again.",1,12+2*nm.getHeight());	
	g.setColor(Color.green);
	g.drawString("Next character appears in Green Box.",1,12+9*nm.getHeight());	
	g.setColor(Color.yellow);
	if(First == 0) g.drawString("Choose `ReDisplay' to start.",300,12+9*nm.getHeight());	
	First = 1;
	g.setFont(f);
	g.setColor(Color.black);
   }
   
   public void setsuper(int flag) {  
      ChemSymInCanv2.super_flag = state()+flag;
		if(ChemSymInCanv2.super_flag == 2)ChemSymInCanv2.super_flag = -1;
		if(ChemSymInCanv2.super_flag == -2)ChemSymInCanv2.super_flag = 1;
      repaint();
		}
  
	public int state() {
		if (ChemSymInCanv2.super_flag == 1) return (1);
		else if (ChemSymInCanv2.super_flag == -1) return (-1);
		else return (0);
		}

   public void update(String args) {  
		ChemSymInCanv2.s1 = args;
		if(DeBug)System.out.println("args in subroutine update = "+args);
      repaint();
		}

   public void clear() {  
		ChemSymInCanv2.s1 = "";
		repaint();
  	 }

   
	public boolean DeBug = false;
   public StringBuffer c1;
	public String s1 = "";
	public int super_flag;
	public int First = 0;
	

}
</pre>

<br><a href="http://web.uconn.edu/%7Ecdavid/cgi-bin/book_prelim_test.html">Test the above html code.<br>
</a><a href="http://web.uconn.edu/%7Ecdavid/cgi-bin/book/prelim2.pl">Continue on to next section (prelim2).
<br></a><a href="http://web.uconn.edu/%7Ecdavid/cgi-bin/book/intro.pl">Return to the last section (intro).<br>
</a><a href="http://web.uconn.edu/%7Ecdavid/cgi-bin/book.html">Return to the main book TOC.</a></body></html>

*/