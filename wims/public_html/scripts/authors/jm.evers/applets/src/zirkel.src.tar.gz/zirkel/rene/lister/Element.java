/*
 * Created on 14.01.2006
 *
 */
package rene.lister;

import java.awt.*;

public interface Element 
{	public String getElementString (int state);
	public String getElementString ();
	public Color getElementColor ();
}
