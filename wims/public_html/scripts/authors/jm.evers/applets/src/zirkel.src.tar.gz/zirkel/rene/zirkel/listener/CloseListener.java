package rene.zirkel.listener;

// file: CloseListener.java

import java.awt.*; // imports Frame

public interface CloseListener
{	public void closed (Frame f);
}
