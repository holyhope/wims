import java.awt.*;
import java.awt.event.*;

public class ChemInputFrame extends Frame implements ActionListener{

    public static void main(String args[]){
        new ChemInputFrame();
    }

    public ChemInputFrame(){
        super(ChemInputApplet.Title);
        setBackground(ChemInputApplet.bgcolor1);
        canvas = new ChemInputCanvas();
	add("Center", canvas);
	setTitle(ChemInputApplet.Title);
	getBounds();
        Menu textMenu = new Menu(ChemInputApplet.Text, true);
        textMenu.add(ChemInputApplet.Quit);
	textMenu.addSeparator();
        textMenu.add(ChemInputApplet.Clear);
	textMenu.addSeparator();
        textMenu.add(ChemInputApplet.More);
        textMenu.add(ChemInputApplet.Less);
	textMenu.addSeparator();
        textMenu.add(ChemInputApplet.Up);
        textMenu.add(ChemInputApplet.Down);
        textMenu.addActionListener(this);
        
	Menu colorMenu = new Menu(ChemInputApplet.Color, true);
        colorMenu.add("Red");
        colorMenu.add("Blue");
        colorMenu.add("Black");
        colorMenu.addActionListener(this);

        Menu chemMenu = new Menu(ChemInputApplet.Chemarrows, true);
        chemMenu.add(ChemInputApplet.Arrow1);
        chemMenu.add(ChemInputApplet.Arrow2);
	chemMenu.addSeparator();
        chemMenu.add(ChemInputApplet.Precip);
        chemMenu.add(ChemInputApplet.Solid);
        chemMenu.add(ChemInputApplet.Liquid);
        chemMenu.add(ChemInputApplet.Gas);
        chemMenu.add(ChemInputApplet.Precip);
        chemMenu.addActionListener(this);
        
	MenuBar mbar = new MenuBar();
	if(ChemInputApplet.chembuttons && ChemInputApplet.navbuttons){
    	    mbar.add(textMenu);
    	    mbar.add(colorMenu);
    	    mbar.add(chemMenu);
	}
	else
	{
	    if(ChemInputApplet.navbuttons){
    		mbar.add(textMenu);
    		mbar.add(colorMenu);
	    }
	    else
	    {
		if(ChemInputApplet.chembuttons){
    		    mbar.add(chemMenu);
		}
	    }
	}
        setMenuBar(mbar);
        setBounds(0, 0,ChemInputApplet.frame_x,ChemInputApplet.frame_y);
        setResizable(true);
        addWindowListener(new WindowAdapter(){public void windowClosing(WindowEvent evt){dispose();}});
	//pack();
        show();
    }
    
    public void actionPerformed(ActionEvent evt){
        String command = evt.getActionCommand();
        if(command.equals("Red"))
            canvas.pencolor = Color.red;
        else
        if(command.equals("Blue"))
            canvas.pencolor = Color.blue;
        else
        if(command.equals("Black"))
            canvas.pencolor = Color.black;
        else
        if(command.equals(ChemInputApplet.Quit))
            dispose();
        else
        if(command.equals(ChemInputApplet.Arrow1))
	    canvas.modify(ChemInputApplet.Arrow1);
	else
        if(command.equals(ChemInputApplet.Arrow2))
	    canvas.modify(ChemInputApplet.Arrow2);
	else
        if(command.equals(ChemInputApplet.Up))
	    canvas.ModifySuper(1);
	else
        if(command.equals(ChemInputApplet.Down))
	    canvas.ModifySuper(-1);
	else
        if(command.equals(ChemInputApplet.Gas))
	    canvas.modify("_{(g)} ");
	else
        if(command.equals(ChemInputApplet.Precip))
	    canvas.modify("_{\u2193} ");
	else
        if(command.equals(ChemInputApplet.Solid))
	    canvas.modify("_{(s)} ");
	else
        if(command.equals(ChemInputApplet.Liquid))
	    canvas.modify("_{(l)} ");
	else
        if(command.equals(ChemInputApplet.Clear))
            canvas.clear();
	else
        if(command.equals(ChemInputApplet.More))
            canvas.SwitchFont(4);
	else
        if(command.equals(ChemInputApplet.Less))
            canvas.SwitchFont(-4);

    }

    ChemInputCanvas canvas;
}

