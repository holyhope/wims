// ballenbak.java - jpq - 09/01/03
import java.awt.event.* ;
import java.awt.* ;
import java.applet.* ;
import java.util.* ;

public class ballenbak extends java.applet.Applet
{ controles C ;
  dessin D ;
//
  String START="Drop all balls";
  String OK="OK";
  String numgate="number of gates";
  String oneextra="drop one ball";
  String numballs="number of balls";
  String droptime="droptime";
  int result[];
  int totalballs;
  int bars;

//
  public String ReadApplet(){
    String reply="";int t;
//    bars = getparam ("bars", 6) ;
    for(int p=0;p<bars+1;p++){
	t=result[p];
	if(p!=0){reply=reply+","+t;}else{reply=reply+t;}   
    }                                                                                                                                  
        return reply;                                                                                                                      
  }


  private int getparam (String s, int n)
  { int nn = n ;
    s = getParameter (s) ;
    if (s != null)
    { try { nn = Integer.parseInt (s) ; }
      catch (NumberFormatException nfe) { }
      if (nn <= 0) nn = n ;
    }
    return nn ;
  }

  public void init ()
  { setLayout (new BorderLayout ()) ;
    bars = getparam ("bars", 1) ;
    int balls = getparam ("balls", 1) ;
    int delay = getparam ("delay", 0) ;
    if(delay*balls>120){delay=1;}
    String lang=getParameter("lang");
    if(lang!=null){
	if(lang.equals("nl")){START="Alles in 1 keer";OK="OK";numgate="aantal rijen poortjes";oneextra="1 bal";numballs="aantal ballen";droptime="valtijd";}
	if(lang.equals("fr")){START="MARCHE";OK="RAZ";numgate="clous";oneextra="1 bille";numballs="billes";droptime="temps";}
    }
    D = new dessin (bars, delay, balls) ;
    C = new controles (D) ;
    D.C = C ;
    add (C, BorderLayout.NORTH) ;
    add (D, BorderLayout.CENTER) ;
  }

  public void destroy ()
  { remove (D) ; remove (C) ; }

  public String getAppletInfo ()
  { return "ballebak par j.-p. Quelen" ; }

////////////////////////////////////////////////////////////////////////////////
protected class dessin extends Canvas

{ int bars, n, delay, boucle ;
  int L, H, Ls2, Hs4, Hb, Hb1 ;
  Random rnd ;
  int [] classes ;
  controles C ;
  gtab gt ;
  Image img ;
  Graphics g ;

  public dessin (int bars, int delay, int n)
  { this.bars = bars ;
    this.delay = delay ;
    this.n = n ;
    classes = new int [bars + 1] ;
    gt = new gtab () ;
    gt.maj (classes.length, classes) ;
    rnd = new Random () ;
  }

// dessin de l'entonnoir

  private void ent (Graphics g)
  { g.setColor (Color.white) ;
    g.fillRect (1, 1, L, Hs4 - 10) ;
    g.setColor (Color.black) ;
    g.drawLine (Ls2 - Hs4, 1, Ls2 - 10, Hs4 - 10) ;
    g.drawLine (Ls2 + 10, Hs4 - 10,  Ls2 + Hs4, 1) ;
    g.setColor (Color.blue) ;
    for (int i = 0 ; i < n ; i ++)
    { int x = (int)(rnd.nextDouble () * (Math.max (0, Hs4 - 15))) ;
      int y = (int)(rnd.nextDouble () * (Math.max (0, Hs4 - x - 15))) ;
      x *= (int)(rnd.nextDouble () * 2) * 2 - 1 ;
      g.fillOval (Ls2 + x, y, 7, 7) ;
    }
    g.setColor (Color.black) ;
    g.drawLine (0, 0, L, 0) ;
  }

  public void update (Graphics g)
  { paint (g) ; }

  public void paint (Graphics g)
  { // if (img == null)
    Font f = new Font ("Arial", Font.BOLD, 16) ;
  g.setFont (f) ;
    { L = getSize().width ;
      H = getSize().height ;
//      img = createImage (L, H) ;
//      g = img.getGraphics () ;
      L -= 2 ; H -= 2 ;
      Ls2 = L / 2 ;
      Hs4 = H / 4 ;
      Hb = H - 50 ;
    }
    g.setColor (Color.black) ;
    g.drawRect (0, 0, L + 1, H + 1) ;
    g.setColor (Color.white) ;
    g.fillRect (1, 1, L, H) ;
// dessin de l'entonnoir
    ent (g) ;
// dessin des clous
    g.setColor (Color.green) ;
    int pas = (Hb - Hs4) / bars ;
    int dec = 0 ;
    int x = Ls2 - 2 ;
    int x1 = x ;
    int y = Hs4 - 2 ;
    for (int i = 0 ; i < bars ; i ++)
    { while (x1 - 3 - dec > 0)
      { g.fillOval (x, y, 5, 5) ;
        g.fillOval (x1, y, 5, 5) ;
        x += pas ;
        x1 -= pas ;
      }
      y += pas ;
      if (dec == 0) dec = pas / 2 ; else dec = 0 ;
      x = Ls2 - 2 + dec ;
      x1 = x ;
    }
// dessin des bacs
    Hb1 = y ;
    g.setColor (Color.black) ;
    g.drawLine (1, H, L, H) ;
    int dec1 = 0 ;
    if (dec == 0) dec1 = pas / 2 ;
    x = Ls2 + dec1 ;
    x1 = x ;
    int ind = bars / 2 ;
    int ind1 = ind ;
    while (x1 + pas > 0)
    { g.setColor (Color.black) ;
      g.drawLine (x, H, x, Hb1) ;
      g.drawLine (x1, H, x1, Hb1) ;
      g.setColor (Color.blue) ;
      if ((ind >= 0) && (ind < classes.length))
      { int ci = classes [ind] ;
        if (ci > 0) g.fillRect (x - pas, H - ci, pas, ci) ;
      }
      if ((ind1 >= 0) && (ind1 < classes.length))
      { int ci = classes [ind1] ;
        if (ci > 0) g.fillRect (x1 - pas, H - ci, pas, ci) ;
      }
      result=classes;
      x += pas ;
      x1 -= pas ;
      ind ++ ;
      ind1 -- ;
    }
//   g1.drawImage (img, 0, 0, this) ;
// dessin de la bille qui tombe
    while (boucle > 0)
    { boucle -- ;
      n -- ;
      ent (g) ;
      C.tn.setText (Integer.toString (n)) ;
      dec = 0 ;
      int xp = 10000 ;
      int yp = 10000 ;
      x = Ls2 - 3 ;
      y = Hs4 - pas / 2 - 3 ;
      ind = 0 ;
      for (int i = 0 ; i < bars ; i ++)
      { boolean brnd = (rnd.nextDouble () >= 0.5) ;
        if (brnd) x += pas / 2 ; else x -= pas / 2 ;
        if (brnd) ind ++ ;
        for (int k = 0 ; k < pas ; k ++)
        { g.setColor (Color.white) ;
          g.fillOval (xp, yp, 7, 7) ;
          g.setColor (Color.blue) ;
          g.fillOval (x, y, 7, 7) ;
//          g1.drawImage (img, 0, 0, this) ;
          xp = x ; yp = y ++ ;
          if (delay > 0)
          { try { Thread.sleep (delay); }
            catch (InterruptedException e) {}
          }
        }
        if (i == 0)
        { g.setColor (Color.black) ;
          g.drawLine (Ls2 - Hs4, 1, Ls2 - 10, Hs4 - 10) ;
          g.drawLine (Ls2 + 10, Hs4 - 10,  Ls2 + Hs4, 1) ;
//          g1.drawImage (img, 0, 0, this) ;
        }
      }
      g.setColor (Color.white) ;
      g.fillOval (xp, yp, 7, 7) ;
      if ((ind >= 0) && (ind < classes.length)) classes [ind] ++ ;
    x = Ls2 + dec1 ;
    x1 = x ;
    ind = bars / 2 ;
    ind1 = ind ;
    while (x1 + pas > 0)
    { g.setColor (Color.black) ;
      g.drawLine (x, H, x, Hb1) ;
      g.drawLine (x1, H, x1, Hb1) ;
      g.setColor (Color.blue) ;
      if ((ind >= 0) && (ind < classes.length))
      { int ci = classes [ind] ;
        if (ci > 0) g.fillRect (x - pas, H - ci, pas, ci) ;
      }
      if ((ind1 >= 0) && (ind1 < classes.length))
      { int ci = classes [ind1] ;
        if (ci > 0) g.fillRect (x1 - pas, H - ci, pas, ci) ;
      }
       x += pas ;
      x1 -= pas ;
      ind ++ ;
      ind1 -- ;
    }
    
    int cnt=0;
    g.setColor (Color.black) ;
    for(int p=0;p<pas;p++){
	g.drawString(" "+cnt+" ",p*pas-pas/2,H);
	cnt++;
    }
//    g1.drawImage (img, 0, 0, this) ;
// 
    gt.maj (bars + 1, classes) ;
    }
  }
}
////////////////////////////////////////////////////////////////////////////////
protected class controles extends Panel implements ActionListener
{ dessin D ;
  TextField tn, tdt, tbars ;
  Button ok, plus, etoile ;
  Font f ;

  private Label ajoutlbl (String s)
  { Label l = new Label (s) ;
    l.setBackground (Color.white) ;
    l.setFont (f) ;
    return l ;
  }

  private TextField ajouttf (int i, int j)
  { TextField T = new TextField (Integer.toString (i), j) ;
  T.setBackground (Color.yellow) ; 
    T.setFont (f) ;
    return T ;
  }

  private Button ajoutb (String s)
  { Button b = new Button (s) ;
    b.addActionListener (this) ;
    b.setFont (f) ;
    return b ;
  }


  public controles (dessin D)
  { this.D = D ;
    f = new Font ("Arial", Font.PLAIN, 10) ;
    setBackground (Color.white) ;
    setLayout (new GridLayout(2, 1)) ;
    Panel p = new Panel () ;
    add (p) ;
    p.add (tdt = ajouttf (D.delay, 2)) ;
    p.add (ajoutlbl (droptime)) ;
    p.add (ajoutlbl (numgate)) ;
    p.add (tbars = ajouttf (D.bars, 2)) ;
    p.add (ok = ajoutb (OK)) ;
    p = new Panel () ;
    add (p) ;
    p.add (ajoutlbl (numballs)) ;
    p.add (tn = ajouttf (D.n, 3)) ;
    p.add (plus = ajoutb (oneextra)) ;
    p.add (etoile = ajoutb (START)) ;
  }

  private int maj (TextField T, int n)
  { try { n = Integer.parseInt (T.getText ()) ; }
      catch (NumberFormatException nfe) { }
    if (n <= 0) n = 1 ;
    return n ;
  }

  public void actionPerformed (ActionEvent e)
  { 
    Object obj = e.getSource () ;
    if (( obj == ok) || (obj == plus) || (obj == etoile))
    { int n = maj (tn, D.n) ;
      if (n >= 0) D.n = n ;
      tn.setText (Integer.toString (D.n)) ;
      try { D.delay = Integer.parseInt (tdt.getText ()) ; }
      catch (NumberFormatException nfe) { }
      tdt.setText (Integer.toString (D.delay)) ;
      if (obj == ok)
      { bars = maj (tbars, D.bars) ;
        if (bars > 0) D.bars = bars ;
        if (D.classes.length < bars + 1) D.classes = new int [bars + 1] ;
        else for (int i = 0 ; i < D.classes.length ; i ++) D.classes [i] = 0 ;
        D.gt.maj (D.bars + 1, D.classes) ;
      }
      else if (obj == plus) D.boucle = 1 ;
           else D.boucle = D.n ;
      tbars.setText (Integer.toString (D.bars)) ;
      tdt.setText (Integer.toString (D.delay)) ;
      D.repaint () ;
    }
  }
}

}
////////////////////////////////////////////////////////////////////////////////
class gtab
{ static boolean change ;
  static int dim ;
  static int [] tableau ;

  static public void maj (int d, int [] tab)
  { dim = d ;
    tableau = tab ;
    change = true ;
  }

}
