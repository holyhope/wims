#!/bin/sh

name="ChemInput"
rm *.class
javac  *.java
if [ -e $name.class ] ; then
    jar cvf ChemInput.jar *.class
    appletviewer test.html
    rm -rf ~/.java
#    firefox file://`pwd`/test.html
else
    echo "trouble"
    read HMMM
fi