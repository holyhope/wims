import java.applet.*;
import javax.swing.*;

public class InputWindow extends javax.swing.JFrame {  
    
    public InputWindow() {
        panel1 = new javax.swing.JPanel();
	textarea=new JTextArea();
	panel1.add(textarea);
	getContentPane().add(panel1);
        pack();
    }

    public javax.swing.JPanel panel1;
    public JTextArea textarea;
    
}