//  Copyright (C) 2003 David Hook
//  Copyright (C) 2004 Philip Proudman
//
//  This file is released under a different licence to the rest of Quick3dApplet
//
//  Please read the file LICENSE.html in this directory.

import java.io.*;
import java.text.*;
import java.util.*;
import java.applet.*;
import Quick3dApplet.*;

class ThreeDStudioReader
{
    private RenderObject ro;
    private int vertBase;
        
    private static final int UNKNOWN_1              = 0x0002;
    private static final int MAIN_CHUNK             = 0x4d4d;
    private static final int MASTER_SCALE_CHUNK     = 0x0100;
    private static final int OBJMESH_CHUNK          = 0x3d3d;
    private static final int UNKNOWN_2              = 0x3d3e;
    private static final int MATERIAL_CHUNK         = 0xafff;
    private static final int MATERIAL_NAME_CHUNK    = 0xa000;
    private static final int MATERIAL_MAPNAME_CHUNK = 0xa300;
    private static final int AMBIENT_COLOR_CHUNK    = 0xa010;
    private static final int DIFFUSE_COLOR_CHUNK    = 0xa020;
    private static final int SPECULAR_COLOR_CHUNK   = 0xa030;
    private static final int SHININESS_CHUNK        = 0xa040;
    private static final int SHININESS2_CHUNK       = 0xa041;
    private static final int TRANSPARENCY_CHUNK     = 0xa050;
    private static final int TEXTURE_MAP_1          = 0xa200;
    private static final int RGB_FLOAT_CHUNK        = 0x0010;
    private static final int RGB_BYTE_CHUNK         = 0x0011;
    private static final int RGB_BYTE_LIN_CHUNK     = 0x0012;
    private static final int PERCENT_INT_CHUNK      = 0x0030;
    private static final int PERCENT_FLOAT_CHUNK    = 0x0031;
    private static final int OBJECT_BLOCK_CHUNK     = 0x4000;
    private static final int TRIMESH_CHUNK          = 0x4100;
    private static final int VERTEX_LIST_CHUNK      = 0x4110;
    private static final int FACE_LIST_CHUNK        = 0x4120;
    private static final int MESH_MAT_CHUNK         = 0x4130;
    private static final int TEX_VERTEX_CHUNK       = 0x4140;
    private static final int SMOOTH_CHUNK           = 0x4150;
    private static final int TRANSFORM_CHUNK        = 0x4160;
    private static final int MESH_COLOR_CHUNK       = 0x4165;
    private static final int DIRECT_LIGHT_CHUNK     = 0x4600;
    private static final int CAMERA_CHUNK           = 0x4700;
    private static final int KF_CHUNK               = 0xb000;
    private static final int KFHDR_CHUNK            = 0xb00a;
    private static final int VIEWPORT_LAYOUT_CHUNK  = 0x7001;
    private static final int KF_SEG_CHUNK           = 0xb008;
    private static final int KF_CURTIME_CHUNK       = 0xb009;
    private static final int OBJECT_NODE_TAG_CHUNK  = 0xb002;
    private static final int NODEHDR_CHUNK          = 0xb010;
    private static final int DUMMY_CHUNK            = 0xffff;

    ThreeDStudioReader(RenderObject r) {
        ro = r;
        Material m = new Material();
        materials.addElement(m);
        m.name = "Default_internal";
        m.setCol(0xffffff); // White
    }

    private class Chunk {
        private long size;
        private long len;
        private InputStream in;
        private Chunk subChunk;
        private int id;
        private int indent;
            
        Chunk(InputStream inp) throws IOException {
            indent = 0;
            in = inp;
            len = 0;
            size = 6;
            subChunk = null;
            id = read16();
            size = read32();
        }

        int getId() {
            return id;
        }
            
        long getSize() {
            return size;
        }

        void end() throws IOException {
            if (subChunk != null) {
                subChunk.end();
                subChunk = null;
            }
            while (size != len) read8();
            //long t = size-len;
            //long skipped = in.skip(t);
            //if (skipped != t)
            //    throw new IOException("Only skipped "+skipped+", should be "+t);
            //len = size;
        }

        boolean isDone() {
            return len == size;
        }
            
        Chunk getSubChunk() throws IOException {
            if (subChunk != null) subChunk.end();
            //for (int i=0; i<indent; ++i) System.out.print("  ");
            subChunk = new Chunk(in);
            len += subChunk.getSize();
            if (size < len) throw new IOException("Trolls1");
            subChunk.indent = indent+1;
            return subChunk;
        }
            
        int read8() throws IOException {
            if (subChunk != null) {
                subChunk.end();
                subChunk = null;
            }
            len++;
            if (size < len) throw new IOException("Trolls2");
            int rv = in.read();
            if (rv == -1)
                throw new IOException("Unexpected end of stream");
            return rv;
        }

        int read16() throws IOException {
            int rv = (read8() | (read8() << 8));
            return rv;
        }

        long read32() throws IOException {
            long rv = (read8() | (read8() << 8) | (read8() << 16) | ((long)read8() << 24));
            return rv;
        }
            
        float readFloat() throws IOException {
            float rv = Float.intBitsToFloat(read8() | (read8() << 8) | (read8() << 16) | (read8() << 24));
            return rv;
        }

        String readName() throws IOException {
            ByteArrayOutputStream bOut = new ByteArrayOutputStream();
            int c;
                
            while ((c = read8()) > 0) {
                bOut.write(c);
            }
                
            return new String(bOut.toByteArray());
        }
    };     

    float readPercentage(Chunk c) throws IOException {
        float p = 0;
        Chunk sc = c.getSubChunk();
        switch (sc.getId()) {
        case PERCENT_INT_CHUNK:
            p = (sc.read16() / 100.0f);
            break;
        case PERCENT_FLOAT_CHUNK:
            p = (sc.readFloat() / 100.0f);
            break;
        default:
            System.out.println("  readPercentage failed");
        }

        return p;
    }

    int readColor(Chunk c) throws IOException {
        int col = 0;

        try {
            Chunk sc = c.getSubChunk();
            switch (sc.getId()) {
            case RGB_FLOAT_CHUNK:
                col = ((int)(sc.readFloat()*255)<<16)
                    | ((int)(sc.readFloat()*255)<<8)
                    | (int)(sc.readFloat()*255);
                break;
            case RGB_BYTE_CHUNK:
            case RGB_BYTE_LIN_CHUNK:
                col = (sc.read8()<<16) | (sc.read8()<<8) | sc.read8();
                break;
            default:
                System.out.println("  readColor failed");
            }
        } catch (IOException e) {
            System.out.println("  readColor");
            throw e;
        }

        return col;
    }

    private static class Material {
        public String name;
        public int col;
        public Pixstore tex;

        public void setCol(int c) {
            col = c;
            tex = new Pixstore(2,2);
            tex.pix[0] = c; tex.pix[1] = c;
            tex.pix[2] = c; tex.pix[3] = c;
        }
    }
    private Vector materials = new Vector();
    private Material getMaterial(String a) {
        Material rv = null;
        for (int i=0;i<materials.size(); ++i) {
            Material t = (Material)materials.elementAt(i);
            if (t.name.equals(a)) {
                rv = t;
                break;
            }
        }
        return rv;
    }
        
    void readMaterial(Chunk c) throws IOException {
        Material m = new Material();
        materials.addElement(m);
                    
        try {
            while (!c.isDone()) {
                Chunk sc = c.getSubChunk();

                switch (sc.getId()) {
                case MATERIAL_NAME_CHUNK:
                    m.name = sc.readName();
                    break;
                case AMBIENT_COLOR_CHUNK:
                    readColor(sc);
                    break;
                case DIFFUSE_COLOR_CHUNK:
                    m.setCol(readColor(sc));
                    break;
                case SPECULAR_COLOR_CHUNK:
                    readColor(sc);
                    break;
                case SHININESS_CHUNK:
                    float shininess1 = readPercentage(sc);
                    break;
                case SHININESS2_CHUNK:
                    float shininess2 = readPercentage(sc);
                    break;
                case TRANSPARENCY_CHUNK:
                    float transparency = readPercentage(sc);
                    break;
                case DUMMY_CHUNK:
                    break;
                case TEXTURE_MAP_1:
                    System.out.println("  Texmap not handled yet");
                    break;
                default:
                    break;
                }
            }

        } catch (IOException e) {
            System.out.println("  readMaterial error");
            throw e;
        }
    }

    void readLight(Chunk c) throws IOException
    {
        float    x, y, z;
            
        x = c.readFloat();
        y = c.readFloat();
        z = c.readFloat();

        readColor(c);
    }

    void readCamera(Chunk c) throws IOException {
        float eyex = c.readFloat();
        float eyey = c.readFloat();
        float eyez = c.readFloat();

        float focx = c.readFloat();
        float focy = c.readFloat();
        float focz = c.readFloat();

        float twist = c.readFloat();    /* Not sure on this one */
        float n = c.readFloat();            /* Not sure on this one */
    }

    void readVerticies(Chunk c) throws IOException {
        int         nVerts, i;
        float       x, y, z;

        nVerts = c.read16();
        vertBase = ro.getVertNum();

        for (i = 0; i < nVerts; i++) {
            x = c.readFloat();
            y = c.readFloat();
            z = c.readFloat();

            ro.addVert(new Vertex(new Vec(x, y, z)));
        }
    }

    void readFaces(Chunk ch) throws IOException {
        try {
            int nPoly = ch.read16();
            int nVert = ro.getVertNum() - vertBase;
                
            int v1[] = new int[nPoly];
            int v2[] = new int[nPoly];
            int v3[] = new int[nPoly];
            int ltu1[] = new int[nPoly];
            int ltu2[] = new int[nPoly];
            int ltu3[] = new int[nPoly];
            int lastTriToUseVert[] = new int[nVert];
            Material col[] = new Material[nPoly];
            int sg[] = new int[nPoly];
            Vec norm[] = new Vec[nPoly];

            for (int i=0; i<nVert;++i) {
                lastTriToUseVert[i] = -1;
            }
                
            for (int i = 0; i < nPoly; i++) {
                v2[i] = ch.read16();
                v1[i] = ch.read16();
                v3[i] = ch.read16();
                int flag = ch.read16();
                // Default texture, may be updated later by MESH_MAT_CHUNK
                col[i] = (Material)materials.elementAt(0);
                // For smoothing
                sg[i] = -1;
                norm[i] = Vec.cross(Vec.sub(ro.vertv[v1[i]+vertBase].pos,
                                            ro.vertv[v2[i]+vertBase].pos),
                                    Vec.sub(ro.vertv[v3[i]+vertBase].pos,
                                            ro.vertv[v2[i]+vertBase].pos));
                norm[i].makeUnitVec();

                // Make a list of triangles using a particular vertex
                ltu1[i] = lastTriToUseVert[v1[i]];
                ltu2[i] = lastTriToUseVert[v2[i]];
                ltu3[i] = lastTriToUseVert[v3[i]];
                lastTriToUseVert[v1[i]] = i;
                lastTriToUseVert[v2[i]] = i;
                lastTriToUseVert[v3[i]] = i;
            }

            while (!ch.isDone()) {
                Chunk sc = ch.getSubChunk();
                switch(sc.getId())
                    {
                    case MESH_MAT_CHUNK:
                        {
                            Material m = getMaterial(sc.readName());            
                            int nFaces = sc.read16();
                            for (int i = 0; i < nFaces; i++) {
                                int f = sc.read16();
                                col[f] = m;
                            }
                        }
                        break;
                    case SMOOTH_CHUNK:
                        for (int i = 0; i < nPoly; i++) {
                            sg[i] = (int)sc.read32();
                        }
                        break;
                    case OBJECT_BLOCK_CHUNK:
                        readObjectBlock(sc);
                        break;
                    default:
                    }
            }

            // Add polygons
            for (int i = 0; i < nPoly; i++) {
                if (v1[i] >= 0) {
                    if (sg[i] >= 0) {
                        // Smoothed polygon
                        // ... work out normals from the smoothgroup info
                        Vec nv1 = new Vec(0,0,0);
                        int j = lastTriToUseVert[v1[i]];
                        while (j>=0) {
                            if (sg[i] == sg[j]) {
                                nv1 = Vec.add(nv1, norm[j]);
                            }
                            if (v1[i] == v1[j]) j = ltu1[j];
                            else if (v1[i] == v2[j]) j = ltu2[j];
                            else  j = ltu3[j];
                        }
                        Vec nv2 = new Vec(0,0,0);
                        j = lastTriToUseVert[v2[i]];
                        while (j>=0) {
                            if (sg[i] == sg[j]) {
                                nv2 = Vec.add(nv2, norm[j]);
                            }
                            if (v2[i] == v1[j]) j = ltu1[j];
                            else if (v2[i] == v2[j]) j = ltu2[j];
                            else  j = ltu3[j];
                        }
                        Vec nv3 = new Vec(0,0,0);
                        j = lastTriToUseVert[v3[i]];
                        while (j>=0) {
                            if (sg[i] == sg[j]) {
                                nv3 = Vec.add(nv3, norm[j]);
                            }
                            if (v3[i] == v1[j]) j = ltu1[j];
                            else if (v3[i] == v2[j]) j = ltu2[j];
                            else  j = ltu3[j];
                        }
                            
                        nv1.makeUnitVec();
                        nv2.makeUnitVec();
                        nv3.makeUnitVec();
                        int n1 = ro.getVertNormNum(); ro.addVertNorm(new VertexNorm(nv1));
                        int n2 = ro.getVertNormNum(); ro.addVertNorm(new VertexNorm(nv2));
                        int n3 = ro.getVertNormNum(); ro.addVertNorm(new VertexNorm(nv3));
                        ro.addTri(new PhongTri(ro.vertv[v1[i]+vertBase],
                                               ro.vertv[v2[i]+vertBase],
                                               ro.vertv[v3[i]+vertBase],
                                               ro.vertNorm[n1],
                                               ro.vertNorm[n2],
                                               ro.vertNorm[n3],
                                               col[i].tex,
                                               new Vec2(0,0),
                                               new Vec2(0,1),
                                               new Vec2(1,0)));
                    }
                    else {
                        // Non-smoothed poly
                        ro.addTri(new ColTri(ro.vertv[v1[i]+vertBase],
                                             ro.vertv[v2[i]+vertBase],
                                             ro.vertv[v3[i]+vertBase],
                                             col[i].col));
                    }
                }
            }
                
        } catch (IOException e) {
            System.out.println("  readFaces error");
            throw e;
        }
    }

    void readTransform(Chunk c) throws IOException {
        float[][] m = new float[4][];

        m[0] = new float[4];
        m[1] = new float[4];
        m[2] = new float[4];
        m[3] = new float[4];

        m[0][0] = c.readFloat();
        m[0][1] = c.readFloat();
        m[0][2] = c.readFloat();

        m[1][0] = c.readFloat();
        m[1][1] = c.readFloat();
        m[1][2] = c.readFloat();

        m[2][0] = c.readFloat();
        m[2][1] = c.readFloat();
        m[2][2] = c.readFloat();

        m[3][0] = c.readFloat();
        m[3][1] = c.readFloat();
        m[3][2] = c.readFloat();
    }

    void readTextureVertices(Chunk c) throws IOException {
        int nVerts = c.read16();

        for (int i = 0; i < nVerts; i++) {
            c.readFloat();
            c.readFloat();
        }
    }

    void readTriMesh(Chunk c) throws IOException {
        try {
            while (!c.isDone()) {
                Chunk sc = c.getSubChunk();
                switch (sc.getId()) {
                case FACE_LIST_CHUNK:
                    readFaces(sc);
                    break;
                case VERTEX_LIST_CHUNK:
                    readVerticies(sc);
                    break;
                case TRANSFORM_CHUNK:
                    readTransform(sc);
                    break;
                case MESH_COLOR_CHUNK:
                    int mc = sc.read8();
                    break;
                case TEX_VERTEX_CHUNK:
                    readTextureVertices(sc);
                    break;
                case DUMMY_CHUNK:
                default:
                }
            }

        } catch (IOException e) {
            System.out.println("  readTriMesh error");
            throw e;
        }
    }
        
    void readObjectBlock(Chunk c) throws IOException {
        try {
            String  n = c.readName();
            while (!c.isDone()) {
                Chunk sc = c.getSubChunk();
                switch (sc.getId()) {
                case TRIMESH_CHUNK:
                    readTriMesh(sc);
                    break;
                default:
                }
            }
        } catch (IOException e) {
            System.out.println("  readObjectBlock error");
            throw e;
        }
    }

    void readObjMeshChunk(Chunk c) throws IOException {
        while (!c.isDone()) {
            Chunk sc = c.getSubChunk();
            switch (sc.getId()) {
            case UNKNOWN_2:
                break;
            case MASTER_SCALE_CHUNK:
                float mscale = sc.readFloat();
                break;
            case MATERIAL_CHUNK:
                readMaterial(sc);
                break;
            case OBJECT_BLOCK_CHUNK:
                readObjectBlock(sc);
                break;
            default:
            }
        }
    }

    void readChunk(Chunk c) throws IOException {
        while (!c.isDone()) {
            Chunk sc = c.getSubChunk();
            switch (sc.getId()) {
            case UNKNOWN_1:
                break;
            case OBJMESH_CHUNK:
                readObjMeshChunk(sc);
                break;
            case KF_CHUNK:
                System.out.println("  Keyframe animations not handled yet");
                break;
            default:
                System.out.println("  unknown chunk ignored (" + Integer.toString(c.getId(), 16) + ")");
            }
        }
    }

    void readChunk(InputStream in) throws IOException {
        Chunk c = new Chunk(in);
        switch(c.getId()) {
        case MAIN_CHUNK:
            readChunk(c);
            break;
        default:
            System.out.println("  unknown chunk ignored in main (" + Integer.toString(c.getId(), 16) + ")");
        }
    }
}
