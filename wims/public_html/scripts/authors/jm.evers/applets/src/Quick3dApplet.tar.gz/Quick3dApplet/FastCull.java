//  Copyright (C) 2004 Philip Proudman
//
//  This file is part of Quick3dApplet
//
//  Quick3dApplet is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  Quick3dApplet is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with Quick3dApplet in the file called "COPYING" in the top directory;
//  if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

package Quick3dApplet;

// This class performs a very rough first stage cull of triangles that
// can't be seen from the current position. Tris that pass this test
// should be followed by an accurate visibility test. This is much
// faster than the accurate test, and can remove many triangles before
// the accurate test needs to be done.
//
// Class assigns a 6 bit number to each triangle. This number points to
// a map of regions in space from where it can be seen. A simple logical
// AND can be used as a first stage cull of this triangle (if not visible).

public final class FastCull
{
    class Adjacent {
        Adjacent() {
            for (int i=0; i<4; ++i) {
                point[i] = null;
            }
            //for (int i=0; i<10; ++i) {
            //    adj[i] = null;
            //}
        }
        int nPoints = 0;
        Vec point[] = new Vec[4];
        //int nAdjacent = 0;
        //Adjacent adj[] = new Adjacent[10];
    }

    public FastCull() {
        // Init the lookup table
        // Each element is a bit mask, each representing part of a sphere divided into
        // maxLookup equal (roughly equal!) triangles.

        // The number returned by getTriNumber() represents a rough hemisphere
        // from which a trianlge is viewable.

        // The setRenderObject method creates another bitmask of possible viewing angles
        // represented on the same rough sphere.

        // isCulled only needs to perform a logical AND of the above masks, and if the
        // answer is zero then the object can be culled. Note the result is not perfect,
        // and results in letting through some triangles that can actually be culled, therefore
        // a further, much slower, check is necessary (done in Render.java)

        Adjacent adj[] = new Adjacent[maxLookup];
        Vec allSegments[] = new Vec[maxSeg];
        
        int pl = 0;
        final int maxZ = 7;
        final int div = 10;
        for (int z = 0; z<maxZ; ++z) {
            float zfLu[] = {1,sphDiv1,sphDiv2,0,-sphDiv2,-sphDiv1,-1};
            float zf = zfLu[z];
            int maxRot = (z == 0 || z == maxZ-1) ? 1 : div;
            for (int rot = 0; rot<maxRot; ++rot) {
                double ang = rot*Math.PI*2/div;
                float s = (float)(Math.sin(ang) * Math.sqrt(1-zf*zf));
                float c = (float)(Math.cos(ang) * Math.sqrt(1-zf*zf));
                allSegments[pl] = new Vec(c, s, zf);
                pl++;
            }
        }

        for (int i=0; i<maxLookup; ++i) {
            adj[i] = new Adjacent();
            clipLookupFlags[i] = 0;
            visibleLookupFlags[i] = 0;
            viewMaskLookup[i] = (long)1<<i;
            for (int k=1; k<numAng; ++k) {
                viewMaskLookup[k*maxLookup+i] = 0;
            }
        }

        // Populate the segment sides lookup
        for (int z = 0; z<12; ++z) {
            final float offs = 0.01f;
            final float offs2 = 0.0001f;
            float zfLu[] = {1-offs,
                            sphDiv1+offs, sphDiv1-offs,
                            sphDiv2+offs, sphDiv2-offs,
                            offs, -offs,
                            -sphDiv2+offs, -sphDiv2-offs,
                            -sphDiv1+offs, -sphDiv1-offs,
                            -1+offs};
            float zf = zfLu[z];
            for (int rot = 0; rot<div*2; ++rot) {
                double ang = (rot>>1) * Math.PI*2/div;
                ang += ((rot&1) == 0) ? offs2 : -offs2;
                float s = (float)(Math.sin(ang) * Math.sqrt(1-zf*zf));
                float c = (float)(Math.cos(ang) * Math.sqrt(1-zf*zf));
                Vec near = new Vec(s, c, zf);
                int segNo = getTriNumber(near);

                // find closest segment
                Vec cl = allSegments[0];
                {
                    float clo = Vec.sub(near, cl).magnitude();
                    for (int i=1; i<maxSeg; ++i) {
                        float d = Vec.sub(near, allSegments[i]).magnitude();
                        if (d < clo) {
                            clo = d;
                            cl = allSegments[i];
                        }
                    }
                }
                
                Adjacent a = adj[segNo];
                if (cl != a.point[0] &&
                    cl != a.point[1] &&
                    cl != a.point[2] &&
                    cl != a.point[3]) {
                    a.point[a.nPoints++] = cl;
                }
            }
        }

        Vec p1[];
        Vec p2[];
        for (int i=0; i<maxLookup; ++i) {
            int n1 = adj[i].nPoints; p1 = adj[i].point;
            for (int j=0; j<maxLookup; ++j) {
                int n2 = adj[j].nPoints; p2 = adj[j].point;

                // Calculate the clipping flags
                boolean setVisible = true;
                boolean setClipped = false;
                float closestAngle = 0;
                for (int l1 = 0; l1<n1; ++l1) {
                    for (int l2 = 0; l2<n2; ++l2) {
                        float d = Vec.dot(p1[l1], p2[l2]);
                        if (d>closestAngle) closestAngle=d;
                        //if (j != i && p1[l1] == p2[l2]) {
                        //boolean doot = true;
                        //for (int k=0; k<adj[i].nAdjacent; ++k)
                        //    if (adj[i].adj[k] == adj[j]) doot = false;
                        //if (doot) {
                        //    adj[i].adj[ adj[i].nAdjacent++ ] = adj[j];
                        //}
                        //}
                        if (d <= 0) setVisible = false; // Normals are pointing in opposite direction
                        else setClipped = true;
                    }
                }
                if (setClipped) {
                    clipLookupFlags[i] |= (long)1<<j;
                }
                if (setVisible) {
                    visibleLookupFlags[i] |= (long)1<<j;
                }

                if (closestAngle > 0) {
                    // Calculate the view masks. The closer an object is to the viewpoint,
                    // FastCull becomes less efficient at culling. We have a lookup table
                    // to keep further objects as efficient as possible.
                    closestAngle = (float)Math.acos(closestAngle);
                    for (int k=1; k<numAng; ++k) {
                        // Angle the shape's raious makes at the viewpoint when the object is
                        // at a certain distance..
                        float ang = (float)Math.asin(1/Math.sqrt(angLookup[k]));
                        if (ang > closestAngle) {
                            viewMaskLookup[k*maxLookup+i] |= (long)1<<j;
                        }
                    }
                }
            }
        }
    }

    public int getTriNumber(Vec normal) { // Normal must be unit vec
        int num = 0;
        // Quadrant
        if (normal.x < 0) num += 5;
        final float p1 =  .8090169944f; // cos(PI/5)
        final float p2 =  .3090169944f; // cos(2PI/5)
        final float p3 = -p2; // cos(3PI/5)
        final float p4 = -p1; // cos(4PI/5)
        float ya = 1-normal.z*normal.z;
        if (ya > 0.00001) 
            ya = normal.y / (float)Math.sqrt(ya);
        if (ya < p2) {
            if (ya < p3) {
                if (ya < p4) num += 1;
                else num += 2;
            }
            else num += 3;
        }
        else {
            if (ya < p1) num += 4;
        }
        if (normal.z < 0) {
            if (normal.z < -sphDiv2) {
                if (normal.z < -sphDiv1) {
                    num += 10;
                }
                else num += 20;
            }
            else num += 30;
        }
        else {
            if (normal.z < sphDiv1) {
                if (normal.z < sphDiv2) {
                    num += 40;
                }
                else num += 50;
            }
        }
        return num;
    }

    public void setRenderObject(RenderObject ro, Vec viewDir) {
        boolean single = false;
        float an = (viewDir.x*viewDir.x +
                    viewDir.y*viewDir.y +
                    viewDir.z*viewDir.z) * ro.getRecipRadiousSq();
        if (an < angLookup[numAng-1]) {
            viewMask = -1; // Don't think about fast culling - the object is too
            // big, or too close to be accurate
        }
        else {
            Matrix inv = new Matrix();
            inv.inverseOf(ro.rot);
            viewDir = Matrix.mul(inv, viewDir);
            viewDir.makeUnitVec();
            int i=0;
            while (angLookup[i] > an) ++i;
            int tn = getTriNumber(viewDir);
            viewMask = viewMaskLookup[i*maxLookup + tn];
        }
    }
    
    public boolean isCulled(int triNum) {
        boolean cull = (clipLookupFlags[triNum] & viewMask) == 0;
        return cull;
    }

    public boolean isVisible(int triNum) {
        boolean vis = (visibleLookupFlags[triNum] & viewMask) == 0;
        return vis;
    }
    
    private long clipLookupFlags[] = new long[maxLookup];
    private long visibleLookupFlags[] = new long[maxLookup];
    private long viewMaskLookup[] = new long[maxLookup * numAng];
    private long viewMask;


    private static final float sphDiv1 = 0.741535f; // Set to give roughly equal distribution of normals
    private static final float sphDiv2 = 0.405639f; // Set to give roughly equal distribution of normals
    private static final int maxLookup = 60;
    private static final int maxSeg = 52;
    private static final int numAng = 5; // Same as the number of elements below
    private static final float angLookup[] = {1000f*1000f,
                                              200f*200f,
                                              1.9f*1.9f,
                                              1.6f*1.6f,
                                              1.4f*1.4f};
}
