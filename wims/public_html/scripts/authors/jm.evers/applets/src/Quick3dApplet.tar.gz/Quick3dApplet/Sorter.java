//  Copyright (C) 2004 Philip Proudman
//
//  This file is part of Quick3dApplet
//
//  Quick3dApplet is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  Quick3dApplet is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with Quick3dApplet in the file called "COPYING" in the top directory;
//  if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


package Quick3dApplet;
import java.util.*;

final class Sorter {
    private SortIt s;

    Sorter(SortIt si) {
        s = si;
    }
        
    void sort() {
        quickSort(0, s.numElem()-1);
        insertionSort();
    }

    static int binSearch(Vector vt, Object o, Lessthan l) {
        int bot = 0;
        int top = vt.size()-1;
        if (top < 0) return 0;
        while (top>bot+1) {
            int mid = (top+bot)>>1;
            if (l.lessthan(o, vt.elementAt(mid)))
                top = mid;
            else
                bot = mid;
        }
        if (top>bot && l.lessthan(o, vt.elementAt(top))) {
            top = bot;
        }
        if (l.lessthan(vt.elementAt(top), o))
            ++top;
        return top;
    }
    
    private void quickSort(int L, int R) {
        while (R-L >= 7) {
            int mid = (L+R)>>1;
            if (s.compare(L, mid) > 0) s.swap(L,mid);
            if (s.compare(L, R) > 0) s.swap(L, R);
            if (s.compare(mid, R) > 0) s.swap(mid, R);
            --R;
            s.swap(mid, R);
            int i = L;
            int j = R;
            while (true) {
                while (s.compare(++i, R) < 0);
                while (s.compare(--j, R) > 0);
                if (i >= j) break;
                s.swap(i, j);
            }
            s.swap(i, R);
            ++R;
            if (i-L > R-i) {
                quickSort(i+1, R);
                R=i-1;
            }
            else {
                quickSort(L, i-1);
                L=i+1;
            }
        }
    }
    
    public void insertionSort() {
        int n = s.numElem();
        for (int step=1; step<n; ++step) {
            int i;
            for(i=step-1; i>=0 && s.compare(i, step) > 0; --i);
            ++i;
            if (i!=step) s.insert(i, step);
        }
    }
    
    static public void swap(Vector vt, int loc1, int loc2) {
        Object tmp = vt.elementAt(loc1);
        vt.setElementAt(vt.elementAt(loc2), loc1);
        vt.setElementAt(tmp, loc2);
    }
}
