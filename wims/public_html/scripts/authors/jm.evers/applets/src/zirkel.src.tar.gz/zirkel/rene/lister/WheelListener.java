/*
 * Created on 14.01.2006
 *
 */
package rene.lister;

public interface WheelListener
{	void up (int n);
	void down (int n);
	void pageUp ();
	void pageDown ();
}
