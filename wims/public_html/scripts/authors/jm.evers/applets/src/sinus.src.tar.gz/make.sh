#!/bin/sh

find ./build -type f -name "*.class" -exec rm "{}" ";" 

rm build/sinus.jar*

ant -v jar -l log.txt

if [ -e "build/sinus.jar" ] ; then
    #mozilla file://`pwd`/1.html
    appletviewer 1.html & 
else
    echo "build failed"
    tail log.txt
    read whatever
fi

tar cvzf sinus.src.tar.gz sinus make.sh build.xml 1.html