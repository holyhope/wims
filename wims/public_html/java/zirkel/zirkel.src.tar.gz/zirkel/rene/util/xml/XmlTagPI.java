package rene.util.xml;

public class XmlTagPI extends XmlTag
{	String Content;
	public XmlTagPI (String s)
	{	super(s);
	}
}
