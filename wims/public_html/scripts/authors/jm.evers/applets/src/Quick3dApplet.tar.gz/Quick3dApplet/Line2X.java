//  Copyright (C) 2004 Philip Proudman
//
//  This file is part of Quick3dApplet
//
//  Quick3dApplet is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  Quick3dApplet is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with Quick3dApplet in the file called "COPYING" in the top directory;
//  if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


package Quick3dApplet;
import java.util.*;

final class Line2X implements SortIt {
    private Line2[] a;
    private int offs;
    private int num;
    Line2X(Line2[] ar, int n, int offset) {
        a = ar;
        num = n;
        offs = offset;
    }
    public int compare(int l, int r) {
        Line2 ll = a[l+offs];
        Line2 rl = a[r+offs];
        return compare(ll, rl);
    }
    static int compare( Line2 ll, Line2 rl) {
        if (ll.currentX < rl.currentX) return -1;
        if (ll.currentX == rl.currentX) return 0;
        return 1;
    }
    public void swap(int i, int j) {
        i+=offs;
        j+=offs;
        Line2 t = a[i]; a[i] = a[j]; a[j] = t;
    }
    public void insert(int i, int j) {
        i+=offs;
        j+=offs;
        Line2 tm = a[j];
        for (int k=j-1; k >= i; --k) a[k+1] = a[k];
        a[i] = tm;
    }
    public int numElem() {
        return num;
    }
};
