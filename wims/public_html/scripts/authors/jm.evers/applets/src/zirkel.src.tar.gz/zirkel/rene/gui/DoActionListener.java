package rene.gui;

public interface DoActionListener
{   void doAction (String o);
    void itemAction (String o, boolean flag);
}
