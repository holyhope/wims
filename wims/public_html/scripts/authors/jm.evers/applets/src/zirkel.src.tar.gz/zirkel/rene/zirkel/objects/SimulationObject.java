/*
 * Created on 21.12.2005
 *
 */
package rene.zirkel.objects;

public interface SimulationObject 
{	public void setSimulationValue (double x);
	public void resetSimulationValue ();
}
