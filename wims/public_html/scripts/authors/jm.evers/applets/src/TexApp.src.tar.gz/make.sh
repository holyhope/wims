#!/bin/sh

# remove java cache in user home
rm -rf ~/.java
# remove previous build
rm -rf build
# make new build dir
mkdir -p build/atp
# copy the images needed for latex
cp atp/*.gif build/atp
# build atp source
javac -verbose -source 1.4 -target 1.4   atp/*.java
mv  atp/*.class build/atp
# build the applet
javac -verbose -source 1.4 -target 1.4 *.java 
mv *.class build

cd build
# make jar
if [ -e *.class ] ; then
jar cvf TexApp.jar *.class atp/*
cd ..
# make src arcive
tar cvzf TexApp.src.tar.gz *.java test.html make.sh atp/*java atp/*.gif atp/gpl.txt CHANGELOG
mozilla file://`pwd`/test.html
#appletviewer test.html
else
echo "compilation error"
read key
fi