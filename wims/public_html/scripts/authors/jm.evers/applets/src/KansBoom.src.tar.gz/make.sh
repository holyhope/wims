#!/bin/sh
name="KansBoom"

htmfile="1.html"

if [ ! -e $htmfile ] ; then
echo "
<html>
<head></head>
<body>
    <script language=\"javascript\" type=\"text/javascript\">                                                                                      
	function READTHIS(){                                                                                                                           
	    var input=document.applets[0].ReadApplet(1);

	    <!--- gives textdata for probability tree :  ReadApplet(whatever) gives objects and coordinates -->
		
	    alert(\"the applet will send:\n\"+input); 
	}                                                                                                                                         
    </script>                                                                                                                                  
    <center>
    <applet code=\"KansBoom.class\" archive=\"KansBoom.jar\" width=\"600\" height=\"400\">
	<param name=\"xsize\" value=\"380\">
	<param name=\"ysize\" value=\"380\">
	<param name=\"bgcolor\" value=\"200,215,235\">
	<param name=\"textcolor\" value=\"250,115,50\">
	<param name=\"drawcolor\" value=\"50,50,150\">
	<param name=\"penthickness\" value=\"6\">
	<param name=\"penfontsize\" value=\"36\">
	<param name=\"penfontfamily\" value=\"Helvetia\">
	<param name=\"penfontstyle\" value=\"italic\">
	<param name=\"language\" value=\"fr\">
	<param name=\"textlines\" value=\"8\"> <!-- number of lines in the applet: strings are bound to these lines -->
	<param name=\"textalign\" value=\"horizontal\"> <!-- probability tree orientation --> 
    </applet>
    <input type=\"button\" name=\".....TEST......\" value=\".....TEST.....\" onclick=\"javascript:READTHIS();\">
</body>
</html>
" > $htmfile

fi


rm *.class 2>/dev/null
rm -rf ~/.java 2>/dev/null 

javac -verbose -source 1.4 -target 1.4 *.java

if [ ! -e "$name.class" ] ; then
    echo "Hmmm...compilation went wrong ?!"
    read anything
else
    echo "
    Making jar file
    
    "
    jar cvf $name.jar *.class
    echo "
    Making source archive
    "
    rm -v *.class
    tar cvzf $name.src.tar.gz $name.java make.sh
    echo "
    appletviewer
    
    "
    mozilla file://`pwd`/1.html
    #appletviewer 1.html
fi


