/*
    J.M. Evers
    A check for browserversion.
    A very small applet to be started before the WIMSchem applet.
    
    <applet id="CheckApplet" name="CheckApplet" data="WIMSchem/CheckVersion.class" archive="dist/WIMSchem.jar" width="1" height="1">
    </applet>
    <script language="javascript" type="text/javascript">
	var VERSION_REQUIRED = "1.6.0";
	var javaVersion;
	try { javaVersion = document.getElementById('CheckApplet').getVersion();} catch(e) {javaVersion = null;}
	if(javaVersion == null){
	    alert(" No Java Plugin detected \n You must go to the java download page to get the correct JavaPlugin..."+VERSION_REQUIRED);
	    window.open("http://java.sun.com/javase/downloads/index.jsp","","status=1,toolbar=1,width=600,height=480");
	}
	else
	{
	    if( javaVersion < VERSION_REQUIRED ){
		alert("You must go to the java download page to get the correct JavaPlugin..."+VERSION_REQUIRED);
		window.open("http://java.sun.com/javase/downloads/index.jsp","","status=1,toolbar=1,width=600,height=480");
	    }
	}    
    </script>
*/

package WIMSchem;
import java.applet.Applet;
import java.awt.*;

public class CheckVersion extends Applet{
    public void init(){}
    public void stop(){}
    public void destroy(){}
    
    public String getVersion(){
        String v=System.getProperty("java.version");
	return v;
    }    
}
