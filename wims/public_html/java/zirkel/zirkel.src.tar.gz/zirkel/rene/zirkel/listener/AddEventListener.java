package rene.zirkel.listener;

import rene.zirkel.construction.Construction;
import rene.zirkel.objects.*;

public interface AddEventListener
{	public void added (Construction c, ConstructionObject o);
}