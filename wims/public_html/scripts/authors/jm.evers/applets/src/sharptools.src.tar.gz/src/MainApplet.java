/*
  J.M. Evers 5/2009
  trying to produce an applet from a opensource spreadsheet java application.
*/

package SharpTools;

import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import java.net.*;


public class MainApplet extends JApplet  {
  SharpTools sharptools=null;
  public String visible="TRUE";
  public static boolean inapplet=true;
  public boolean matrix=true;
  // instead of a configfile, a tunable paramlist;
  public static int ROWS;
  public static int COLUMNS;
  public static int FIRSTCOLUMNWIDTH;
  public static int COLUMNWIDTH;
  public static boolean SAVEWINDOW=false;
  public static int X;
  public static int Y;
  public static int WIDTH;
  public static int HEIGHT;
  public static int HISTOGRAMWIDTH;
  public static int HISTOGRAMHEIGHT;
  public static boolean TOOLBAR_NEW=false;
  public static boolean TOOLBAR_OPEN=false;
  public static boolean TOOLBAR_SAVE=false;
  public static boolean TOOLBAR_PASSWORD=false;
  public static boolean TOOLBAR_PRINT=true;
  public static boolean TOOLBAR_UNDO=true;
  public static boolean TOOLBAR_REDO=true;
  public static boolean TOOLBAR_CUT=true;
  public static boolean TOOLBAR_COPY=true;
  public static boolean TOOLBAR_PASTE=true;
  public static boolean TOOLBAR_FIND=true;
  public static boolean TOOLBAR_INSERTROW=true;
  public static boolean TOOLBAR_INSERTCOLUMN=true;
  public static boolean TOOLBAR_DELETEROW=true;
  public static boolean TOOLBAR_DELETECOLUMN=true;
  public static boolean TOOLBAR_SORTCOLUMN=true;
  public static boolean TOOLBAR_HISTOGRAM=true;
  public static boolean TOOLBAR_HELP=true;
  public static boolean TOOLBAR_FUNCTIONS=true;
  public static int NUMCONNECTIONS=5;
  public static String CONNECTION1NAME="";
  public static String CONNECTION1USERNAME="";
  public static String CONNECTION1PASSWORD="";
  public static String CONNECTION1URL="";
  public static String CONNECTION1DRIVER="";
  public static int RECENTFILELIST=8;
  public static String RECENTFILE0="";
  public static String RECENTFILE1="";
  public static String RECENTFILE2="";
  public static String RECENTFILE3="";
  public static String RECENTFILE4="";
  public static String RECENTFILE5="";
  public static String RECENTFILE6="";
  public static String RECENTFILE7="";
  public static String AppletReply="";
  public String language="en";
  Font defaultFont = new Font( "Helvetica", Font.BOLD, 14 );
  Color green=new Color(0,255,0);                                                      
  Color red=new Color(255,0,0);
  Color current_color=new Color(0,255,0);
  
  private Container container;
  private JButton OpenButton;
  private JButton CloseButton;
  ImageIcon OpenIcon=new ImageIcon(getClass().getResource("/images/start.gif"));
  ImageIcon CloseIcon=new ImageIcon(getClass().getResource("/images/close.gif"));
  String Tooltip_open="Open spreadsheet";
  String Tooltip_close="Close spreadsheet";
  
  
  
  
  
  
  public void init(){
    container = this.getContentPane();                                                        
    container.setLayout(new BorderLayout());
    OpenButton = new JButton(OpenIcon);
    OpenButton.setToolTipText(Tooltip_open);
    CloseButton = new JButton(CloseIcon);
    CloseButton.setToolTipText(Tooltip_close);
    container.add(OpenButton,BorderLayout.EAST);
    container.add(CloseButton,BorderLayout.WEST);
    container.validate();
    
    OpenButton.addActionListener (new ActionListener(){                                                                              
            public void actionPerformed (ActionEvent evt){
		visible="TRUE";
		ShowSpreadSheet(visible);
	    }                                                                                                                          
	}
    ); 

    CloseButton.addActionListener (new ActionListener(){                                                                              
            public void actionPerformed (ActionEvent evt){
		visible="FALSE";
		ShowSpreadSheet(visible);
	    }                                                                                                                          
	}
    ); 
    
    String c;
    c=getParameter("language");
    String nee="no";
    if(c.equalsIgnoreCase("en") || c.equalsIgnoreCase("nl") || c.equalsIgnoreCase("fr") ){
	language=c.toLowerCase(); 
	if(language.equals("nl")){ nee = "nee";}
	else
	if(language.equals("fr")){ nee = "non";}
	else
	if(language.equals("de")){ nee = "nein";}
    }
    else
    {
        language="en";
    }

    //c=getParameter("TOOLBAR_OPEN") cannot be set: it's an applet
    //c=getParameter("TOOLBAR_SAVE")  cannot be set: it's an applet
    //c=getParameter("TOOLBAR_PASSWORD") cannot be set: it's an applet
    c=getParameter("show_applet_on_start");   
    if(c != null && c.length()>0){if(c.equals("0") || c.equalsIgnoreCase(nee) || c.equalsIgnoreCase("FALSE")){visible="FALSE";}}
    c=getParameter("matrix_format");   
    if(c != null && c.length()>0){if(c.equals("0") || c.equalsIgnoreCase(nee) || c.equalsIgnoreCase("FALSE")){matrix=false;}}

    c=getParameter("COLUMNS");   
    if(c != null && c.length()>0){COLUMNS = Integer.parseInt(c,10);}else{ COLUMNS = 10;}
    c=getParameter("ROWS");    
    if(c != null && c.length()>0){ROWS = Integer.parseInt(c,10);}else{ ROWS = 10;}
    c=getParameter("COLUMNWIDTH");
    if(c != null && c.length()>0){COLUMNWIDTH = Integer.parseInt(c,10);}else{ COLUMNWIDTH = 80;}
    c=getParameter("FIRSTCOLUMNWIDTH");
    if(c != null && c.length()>0){FIRSTCOLUMNWIDTH = Integer.parseInt(c,10);}else{ FIRSTCOLUMNWIDTH = 25;}
    c=getParameter("X");    
    if(c != null && c.length()>0){X = Integer.parseInt(c,10);}else{ X=640;}
    c=getParameter("Y");    
    if(c != null && c.length()>0){Y = Integer.parseInt(c,10);}else{ Y=420;}
    c=getParameter("WIDTH");    
    if(c != null && c.length()>0){WIDTH = Integer.parseInt(c,10);}else{ WIDTH = 760;}
    c=getParameter("HEIGHT");    
    if(c != null && c.length()>0){HEIGHT = Integer.parseInt(c,10);}else{ HEIGHT = 484;}
    c=getParameter("HISTOGRAMWIDTH");    
    if(c != null && c.length()>0){HISTOGRAMWIDTH = Integer.parseInt(c,10);}else{ HISTOGRAMWIDTH = 500;}
    c=getParameter("HISTOGRAMHEIGHT");    
    if(c != null && c.length()>0){HISTOGRAMHEIGHT = Integer.parseInt(c,10);}else{ HISTOGRAMHEIGHT = 400;}
    c=getParameter("TOOLBAR_NEW");
    if(c != null && c.length()>0){if(c.equals("0") || c.equalsIgnoreCase(nee) || c.equalsIgnoreCase("FALSE")){TOOLBAR_NEW=false;}}
    c=getParameter("TOOLBAR_PRINT");
    if(c != null && c.length()>0){if(c.equals("0") || c.equalsIgnoreCase(nee) || c.equalsIgnoreCase("FALSE")){TOOLBAR_PRINT=false;}}
    c=getParameter("TOOLBAR_UNDO");
    if(c != null && c.length()>0){if(c.equals("0") || c.equalsIgnoreCase(nee) || c.equalsIgnoreCase("FALSE")){TOOLBAR_UNDO=false;}}
    c=getParameter("TOOLBAR_REDO");
    if(c != null && c.length()>0){if(c.equals("0") || c.equalsIgnoreCase(nee) || c.equalsIgnoreCase("FALSE")){TOOLBAR_REDO=false;}}
    c=getParameter("TOOLBAR_CUT");
    if(c != null && c.length()>0){if(c.equals("0") || c.equalsIgnoreCase(nee) || c.equalsIgnoreCase("FALSE")){TOOLBAR_CUT=false;}}
    c=getParameter("TOOLBAR_COPY");
    if(c != null && c.length()>0){if(c.equals("0") || c.equalsIgnoreCase(nee) || c.equalsIgnoreCase("FALSE")){TOOLBAR_COPY=false;}} 
    c=getParameter("TOOLBAR_PASTE");
    if(c != null && c.length()>0){if(c.equals("0") || c.equalsIgnoreCase(nee) || c.equalsIgnoreCase("FALSE")){TOOLBAR_PASTE=false;}} 
    c=getParameter("TOOLBAR_FIND");
    if(c != null && c.length()>0){if(c.equals("0") || c.equalsIgnoreCase(nee) || c.equalsIgnoreCase("FALSE")){TOOLBAR_FIND=false;}}
    c=getParameter("TOOLBAR_INSERTROW");
    if(c != null && c.length()>0){if(c.equals("0") || c.equalsIgnoreCase(nee) || c.equalsIgnoreCase("FALSE")){TOOLBAR_INSERTROW=false;}}
    c=getParameter("TOOLBAR_INSERTCOLUMN");
    if(c != null && c.length()>0){if(c.equals("0") || c.equalsIgnoreCase(nee) || c.equalsIgnoreCase("FALSE")){TOOLBAR_INSERTCOLUMN=false;}} 
    c=getParameter("TOOLBAR_DELETEROW");
    if(c != null && c.length()>0){if(c.equals("0") || c.equalsIgnoreCase(nee) || c.equalsIgnoreCase("FALSE")){TOOLBAR_DELETEROW=false;}}
    c=getParameter("TOOLBAR_DELETECOLUMN");
    if(c != null && c.length()>0){if(c.equals("0") || c.equalsIgnoreCase(nee) || c.equalsIgnoreCase("FALSE")){TOOLBAR_DELETECOLUMN=false;}}
    c=getParameter("TOOLBAR_SORTCOLUMN");
    if(c != null && c.length()>0){if(c.equals("0") || c.equalsIgnoreCase(nee) || c.equalsIgnoreCase("FALSE")){TOOLBAR_SORTCOLUMN=false;}}
    c=getParameter("TOOLBAR_HISTOGRAM");
    if(c != null && c.length()>0){if(c.equals("0") || c.equalsIgnoreCase(nee) || c.equalsIgnoreCase("FALSE")){TOOLBAR_HISTOGRAM=false;}}
    c=getParameter("TOOLBAR_HELP");
    if(c != null && c.length()>0){if(c.equals("0") || c.equalsIgnoreCase(nee) || c.equalsIgnoreCase("FALSE")){TOOLBAR_HELP=false;}}
    c=getParameter("TOOLBAR_FUNCTIONS");
    if(c != null && c.length()>0){if(c.equals("0") || c.equalsIgnoreCase(nee) || c.equalsIgnoreCase("FALSE")){TOOLBAR_FUNCTIONS=false;}}

    sharptools=new SharpTools(inapplet,language);
    sharptools.setVisible(false);
    repaint();

  }
  
  public void stop(){}
  public void destroy(){}
  public void run(){}
  public void start(){}
  
  public String ReadRawApplet(){//send data in tab-separated format to Javascript
	AppletReply=sharptools.ReadRawSpreadSheet();
	return AppletReply;
  }
  
  public String ReadApplet(){//send data in tab-separated or matrix format to Javascript
	// default [1,2,3;4,5,6]
	AppletReply=sharptools.ReadSpreadSheet(matrix);
	return AppletReply;
  }
  
  public void ShowSpreadSheet(String start){
	if(start.equalsIgnoreCase("start") || start.equalsIgnoreCase("true") || start.equalsIgnoreCase("show") ){
	    sharptools.setVisible(true);
	}
	if(start.equalsIgnoreCase("stop") || start.equalsIgnoreCase("false") || start.equalsIgnoreCase("hide")){
	    sharptools.setVisible(false);
	}
    repaint();
  }
}


/*
  public static byte [] loadURL(URL url) throws IOException {
  // jm.evers :handy functions !!! not mine :(
  int bufSize = 1024 * 2;
	byte [] buf = new byte[bufSize];
	ByteArrayOutputStream bout = new ByteArrayOutputStream();
	BufferedInputStream in = new BufferedInputStream(url.openStream());
	int n;
	while ((n = in.read(buf)) > 0) {
  	  bout.write(buf, 0, n);
	}
	try 
	{ in.close(); } catch (Exception ignored) { }
	return bout.toByteArray();
  }

  public static String loadFile(String fname) throws IOException {
  // jm.evers :handy functions !!! not mine :(
	byte[] bytes = loadURL(new URL("file:" + fname));
	return new String(bytes);
  }
  
  public static String load(String fileOrURL) throws IOException {
  // jm.evers :handy functions !!! not mine :(
	try {
	  URL url = new URL(fileOrURL);
	  return new String(loadURL(url));
	} catch (Exception e) {
	return loadFile(fileOrURL);
	}
  }
*/