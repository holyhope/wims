package atp;


class c
{

    public int _flddo;
    public int _fldif;
    public int a;

    public c(int i, int j, int k)
    {
        _flddo = i;
        _fldif = j;
        a = k;
    }

    public c()
    {
        _flddo = 0;
        _fldif = 0;
        a = 0;
    }
}