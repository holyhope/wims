/*
    Written by J.M. Evers 
    Used as small but fairly powerfull calculator in WIMS
    No memory, no buttons: a single input line.
    Capable of sending the result -javascript- to WIMS.
    
    Read Arity documentation for capabilities and Copyright/License.
    This little program has no copyrights. Ofcourse.
*/

import java.awt.*;
import java.applet.*;
import java.util.*;
import org.javia.arity.*;
import javax.swing.*;
import java.awt.event.*;
import java.text.DecimalFormat;

public class Rekenmachien extends Applet {
    
    private JTextField input; /* need javax.swing JTextField : no tooltips for TextField !! */
    private JTextField output;
    private JTextField remarks;
    double precision=0.000001;int rounding=6;
    DecimalFormat decformat;
    Color pencolor1,pencolor2,bgcolor1,bgcolor2;
    int R1=225;int G1=255;int B1=255;
    int font_size1=16;int font_size2=16;
    String rem1="\u2023 Mathematical error";
    String rem2="\u2023 Nonsense Error";
    String rem3="\u2023 calculator";
    String rem4="\u2023 done";
    String rem5="\u2023 log(e) = 1";
    String rem6="\u2023 Usage";
    String rem7="\u2023 Please wait...";
    String rem8;
    String rem9="precision";
    
    public void init(){
        String param="";
	param=getParameter("language");
	if(param!=null && param.length()>0){
	    if(param.equalsIgnoreCase("nl")){
		rem1="\u2023 Wiskundige fout";
		rem2="\u2023 Onzinnige invoer";
		rem3="\u2023 rekenmachine";
		rem4="\u2023 klaar";
		rem5="\u2023 log(e) = 1";
		rem6="\u2023 info";
		rem7="\u2023 even geduld...";
		rem9="precisie";
	    }
	    else
	    {
		if(param.equalsIgnoreCase("de")){
		    rem1="\u2023 Mathematik Fehler";
		    rem2="\u2023 Nonsense Fehler";
		    rem3="\u2023 Taschenrechner";
		    rem4="\u2023 fertig";
		    rem5="\u2023 log(e) = 1";
		    rem6="\u2023 info";
		    rem7="\u2023 einen moment...";
		    rem9="precision";
		}
		else
		{
		    if(param.equalsIgnoreCase("fr")){
			rem1="\u2023 Erreur mathematique";
			rem2="\u2023 Nonsense Erreur";
			rem3="\u2023 calculateur";
			rem4="\u2023 fini";
			rem5="\u2023 log(e) = 1";
			rem6="\u2023 info";
			rem7="\u2023 Please wait...";
			rem9="precision";
		    }
		}
	    }
	}

	// display precision 
	param=getParameter("decimals");
	if(param!=null && param.length()>0){
	    rounding =Integer.parseInt(param, 10);
	    precision=(double) 1/(Math.pow(10,rounding));
	}
	String numformat="#.";
	for(int n=0;n<rounding;n++){
	    numformat=numformat+"#";
	}
	decformat = new DecimalFormat(numformat);

	// very slow java tooltip text: multiline through HTML
	rem8="<html><body bgcolor=white><ul><li>\u2023"+rem9+": \u00B1 "+precision+"</li><li>6*(123/4+1234/5)/(7+9)</li><li>(123^(4/3)+5)/6</li><li>sqrt(123/4)/5</li><li>sqrt[3](1234)</li><li>sin(2*pi)</li><li>sinh(pi)</li><li>log(123)/log(10)</li><li>ln(e)=log(e)=1</li></ul>";
	param=getParameter("fontsize1");
	if(param!=null && param.length()>0){font_size1 = Integer.parseInt(param, 10);}
	param=getParameter("fontsize2");
	if(param!=null && param.length()>0){font_size2 = Integer.parseInt(param, 10);}
	param=getParameter("pencolor1"); // foreground color of inputfield "input"
	if (param != null && param.length()>0){
	    param=param.replace(':',',');param=param.replace(';',',');
	    StringTokenizer q = new StringTokenizer(param, ",");
	    String k;int rgb;
	    for( int a=0; a<3 ; a++){
		k=q.nextToken();
		rgb=Integer.parseInt(k, 10);
		if(rgb<0){rgb=0;}
		if(rgb>255){rgb=255;}
		if(a == 0){R1 = rgb;}
		else if(a == 1){G1 = rgb;}
		else if(a == 2){B1 = rgb;}
	    }
	    pencolor1=new Color(R1,G1,B1);
	}
	param=getParameter("pencolor2"); // foreground color of inputfield "input"
	if (param != null && param.length()>0){
	    param=param.replace(':',',');param=param.replace(';',',');
	    StringTokenizer q = new StringTokenizer(param, ",");
	    String k;int rgb;
	    for( int a=0; a<3 ; a++){
		k=q.nextToken();
		rgb=Integer.parseInt(k, 10);
		if(rgb<0){rgb=0;}
		if(rgb>255){rgb=255;}
		if(a == 0){R1 = rgb;}
		else if(a == 1){G1 = rgb;}
		else if(a == 2){B1 = rgb;}
	    }
	    pencolor2=new Color(R1,G1,B1);
	}

	param=getParameter("bgcolor1"); // Background color of inputfield "input"
	if (param != null && param.length()>0){
	    param=param.replace(':',',');param=param.replace(';',',');
	    StringTokenizer q = new StringTokenizer(param, ",");
	    String k;int rgb;
	    for( int a=0; a<3 ; a++){
		k=q.nextToken();
		rgb=Integer.parseInt(k, 10);
		if(rgb<0){rgb=0;}
		if(rgb>255){rgb=255;}
		if(a == 0){R1 = rgb;}
		else if(a == 1){G1 = rgb;}
		else if(a == 2){B1 = rgb;}
	    }
	    bgcolor1=new Color(R1,G1,B1);
	}

	param=getParameter("bgcolor2"); // Background color of canvas
	if (param != null && param.length()>0){
	    param=param.replace(':',',');param=param.replace(';',',');
	    StringTokenizer q = new StringTokenizer(param, ",");
	    String k;int rgb;
	    for( int a=0; a<3 ; a++){
		k=q.nextToken();
		rgb=Integer.parseInt(k, 10);
		if(rgb<0){rgb=0;}
		if(rgb>255){rgb=255;}
		if(a == 0){R1 = rgb;}
		else if(a == 1){G1 = rgb;}
		else if(a == 2){B1 = rgb;}
	    }
	    bgcolor2=new Color(R1,G1,B1);
	}
	Font myfont1 = new Font("Helvetica", Font.BOLD, font_size1);
	Font myfont2 = new Font("Helvetica", Font.BOLD, font_size2);
	setLayout(new GridLayout(3, 1));
	input=new JTextField(font_size1);
	output=new JTextField(font_size2);
	remarks=new JTextField(font_size2);
	input.setForeground(pencolor1);
	output.setForeground(pencolor2);
	remarks.setForeground(pencolor2);
	input.setBackground(bgcolor1);
	output.setBackground(bgcolor2);	    
	remarks.setBackground(bgcolor2);	    
	input.setFont(myfont1);
	output.setFont(myfont2);
	remarks.setFont(myfont2);
	add(input);add(output);add(remarks);
	input.setText("? ");
	output.setText("\u2023 "); 
	remarks.setText(rem6); 
	remarks.setToolTipText(rem8);/* only a tooltip over the remark inputfield */
	input.setCaretPosition(2); 
	//input.requestFocus(); /* gives trouble in some exercises...not releasing the focus to the wims-input fields...*/
	
	input.addKeyListener(new KeyAdapter() {
    	    public void keyPressed(KeyEvent evt) {
		// enter and arrow_down is accepted for starting the calculation
		if(evt.getKeyCode() == evt.VK_ENTER  || evt.getKeyCode() == evt.VK_DOWN ){
    		    repaint();
    		}
	    }
	});
    }
	
    public void calculate(){
	String S=input.getText();
	S=replace(S,"?","");
	if(S.length()>1){
	    String remark="";
	    double result=0.0D;/* double is needed for Arity libs */
	    Symbols symbols=new Symbols(); /* Arity */
	    S=replace(S,",",".");
	    S=S.toLowerCase();
	    S=replace(S,"sqr(","sqrt(");/* common error */
	    if(S.indexOf("sqrt[") != -1){S=sqrtn(S);} /* sqrt[3](4) = 4^(1/3) ... */
	    if(S.indexOf("log")!=-1){remark=rem5;} /* alert log(3)=1 */
	    if(S.indexOf("ln")!=-1){S=replace(S,"ln","log");} /* dutch/belgian pupils will use ln(e)=1 */
	    for(int s=0;s<3;s++){/* arity lib throws errors +-5-+3------23 etc */
		S=replace(S,"+-","-");
	        S=replace(S,"-+","-");
		S=replace(S,"--","+");
	        S=replace(S,"++","+");
	    }
	    if(S != null){
		String ex[]=S.split("=");
	        try { 
		result=symbols.eval(ex[ex.length-1]); /* try to call arity  for evaluation */
		output.setText("\u2023 "+truncate(result));remarks.setText(rem4+remark);} 
		catch (SyntaxException e) {output.setText("\u2023 ?");remarks.setText(rem1+remark);}
	    }
	    else
	    {
		output.setText(rem2);
	        remarks.setText(rem4+remark);
	    }        
	}
	else
	{
	    output.setText("\u2023 ");
	    remarks.setText(rem6);
	}
	input.setText("? ");
	input.setCaretPosition(2); /* first 2 positions are: ? [space] */
    }
    
    public void paint(Graphics g){
	calculate();
	remarks.setToolTipText(rem8);/* only a tooltip over the remark inputfield */
    }
	 
    public static String replace(String source, String pattern, String replace){ /* java 1.4 lacks decent replace() */
	if (source!=null){
	    final int len = pattern.length();
	    StringBuffer sb = new StringBuffer();
	    int found = -1;
	    int start = 0;
	    while( (found = source.indexOf(pattern, start) ) != -1){
		sb.append(source.substring(start, found));
		sb.append(replace);
		start = found + len;
	    }
	    sb.append(source.substring(start));
	    return sb.toString();
        }
        else
	{
	    return "";
	}
    }

    public String ReadApplet(){ /* interface for sending the answer through javascript to WIMS */
	String reply=output.getText();
	String tmp[]=reply.split("\u2023");
	if( tmp[1].length() == 0){
	    remarks.setText(rem2); 
	    return "error";
	}
	else
	{
	    return " "+tmp[1];
	}
    }

    private String sqrtn(String t){/* function to replace sqrt[g](n) by n^(1/g) */
	int begin=t.indexOf("sqrt[");
	String org=t;
	int tot;int Got;int Wait;int End;char chr;int s;int restart;
	String value;String exp;String val;String L;String R;int cnt=0;
	while (begin >= 0){
	    cnt++;if(cnt>1000){remarks.setText("sqrt[]() syntax error");}
	    tot=t.length();Wait=0;Got=0;End=0;
	    for(s=begin+4;s<tot;s++){
		if(End==0){
		    chr=t.charAt(s);
		    if(chr=='['){Wait=Wait+1;}
		    if(chr==']'){Got=Got+1;}
		    if(Got!=0){if(Wait==Got){End=s;}}
		}
	    }
	    restart=End;    
	    exp=t.substring(begin+5,End);
	    Wait=0;Got=0;End=0;
	    for(s=restart;s<tot;s++){
		if(End==0){
		    chr=t.charAt(s);
		    if(chr=='('){Wait=Wait+1;}
		    if(chr==')'){Got=Got+1;}
		    if(Got!=0){if(Wait==Got){End=s;}}
		}
	    }
	    val=t.substring(restart+2,End);
	    R="("+val+")^(1/("+exp+"))";L="sqrt["+exp+"]("+val+")";
	    t=replace(t,L,R);
	    begin=t.indexOf("sqrt[");
	}
	return t;
    }

    public String getAppletInfo(){
	return "Java Calculator\n \u2023 using \"Arity\" library\n \u2023 normal arithmetics \n \u2023 sin(),cos(),tan(),sinh(),etc() \n \u2023 sqrt() sqrt[n]() log() \n \u2023 javascript communication [WIMS] \n \u2023 precision adjustable [\u00B1 "+precision+"]\nJ.M. Evers 10/2008";
    }

    public String truncate(double t){
	String r = decformat.format(precision*(Math.round(t/precision)));	
	return r;    
    }
    
    public void start(){}
    
    public void stop(){}

    public void run(){}
    
}




