#!/bin/sh

if [ ! -e 1.html ] ; then
echo "
<html>
<head>
<title>WIMSchem - Applet</title>
<style>a:link{color:blue;text-decoration:none;}a:hover{color:red;text-decoration:none;}</style> 
<script language=\"javascript\" type=\"text/javascript\"  src=\"chemicals/database.js\"></script>
<script language=\"javascript\" type=\"text/javascript\">
var chem;

function Set_Some_Chemical(){
<!-- picking a random chemical from the database.js include...stored in array demo[] -->
<!-- This is just for demonstation...in real life we would not show the correct answer , but-->
<!-- ask to draw the chemical structure of \"cis hexanediol\" ... -->

    var l=question.length;
    var c=Math.floor(Math.random()*l);
    chem=question[c];
    document.js.moltext.value=chem;
    document.molapplet.SetMoleculeNative(chem);
}

function GetMoleculeNative(){
    <!-- reading the WIMSchem  file format from a drawing and display it in textarea \"moltext\" -->
    var str=document.molapplet.GetMoleculeNative();
    document.js.moltext.value=str;
}


function SetMoleculeNative(){
    <!-- reading the WIMSchem  file format from a drawing and display it in textarea \"moltext\" -->
    var str=document.js.moltext.value
    document.molapplet.SetMoleculeNative(str);
}


function GetMoleculeMDLMol(){
    <!-- reading the WIMSchem  file format from a drawing and display it in textarea \"moltext\" -->
    var str=document.molapplet.GetMoleculeMDLMol();
    document.js.moltext.value=str;
}


function SetMoleculeMDLMol(){
    <!-- reading the WIMSchem  file format from a drawing and display it in textarea \"moltext\" -->
    var str=document.js.moltext.value
    document.molapplet.SetMoleculeMDLMol(str);
}

function ReadApplet(){
    var str=document.molapplet.ReadApplet();
    document.js.moltext.value=str;
}


function CompareNative(){
    <!-- \"Sending\" the correct WIMSchem data from the database.js for comparison with the drawing -->
    document.molapplet.GetQuestion(chem);
    var result=document.molapplet.CompareNative();
    var reply=result.split(\"\n\");
    var rest=result.split(\"@\");
	<!-- data format from applet :   	 	 -->
	<!-- sa=student answer			 	 -->
	<!-- ca=correct answer	 [the question]		 -->
	<!--    return score+			reply[0] -->
	<!--    \"\n\"+weight_sa+		reply[1] -->
	<!--    \"\n\"+weight_ca+		reply[2] -->
	<!--    \"\n\"+plain_formula_sa+	reply[3] -->
	<!--    \"\n\"+plain_formula_ca+	reply[4] -->
	<!--    \"\n\"+html_formula_sa+		reply[5] -->
	<!--    \"\n\"+html_formula_ca+		reply[6] -->
	<!--    \"\n\"+html_smiles_sa+		reply[7] -->
	<!--    \"\n\"+html_smiles_ca+		reply[8] -->
	<!--    \"\n\"+latex_formula_sa+	reply[9] -->
	<!--    \"\n\"+latex_formula_ca+	reply[10] -->
	<!--    \"\n\"+feedback+		reply[11] -->
	<!--    \"\n@\"+Student_answer+	rest[0] -->
	<!--    \"\n@\"+Correct_answer+	rest[2] -->
	

    document.js.a_reply.value=reply[0]+\"\n\"+reply[3]+\"\n\"+reply[4]+\"\n\"+reply[11];
    showhtml.innerHTML = \"<hr noshade>Your answer: \"+reply[5]+\"  [Molweight=\"+reply[1]+\"  \"+reply[7]+\"]<hr noshade>Correct answer:\"+reply[6]+\"  [Molweight=\"+reply[2]+\"   \"+reply[8]+\"]\";
}
</script>

</head> 

<body  bgcolor=\"#408040\" text=\"#ffffff\" link=\"#80ff80\" vlink=\"#70d070\" alink=\"#80ffff\">


<h1>WIMSchem Applet</h1>
<table>
    <th valign=\"top\">
	<div id=\"notify\" style=\"visibility:visible\"><blink><font color=\"red\">CHECKING JAVA PLUGIN VERSION</font></blink></div>
	<applet id=\"CheckApplet\" name=\"CheckApplet\" code=\"WIMSchem/CheckVersion.class\" archive=\"dist/WIMSchem.jar\" width=\"1\" height=\"1\" MAYSCRIPT></applet>
	    
	<script language=\"javascript\" type=\"text/javascript\">
	    var VERSION_REQUIRED = \"1.5.0\";
	    var javaVersion;
	    try { javaVersion = document.getElementById(\"CheckApplet\").getVersion();} catch(e) {javaVersion = null;}
	    if(javaVersion == null){
		alert(\" No Java Plugin detected \n You must go to the java download page to get the correct JavaPlugin...\nVersion :\"+VERSION_REQUIRED);
		window.open(\"http://java.sun.com/javase/downloads/index.jsp\",\"\",\"status=1,toolbar=1,width=600,height=480\");
	    }
	    else
	    {
		if( javaVersion < VERSION_REQUIRED ){
		    alert(\"You must go to the java download page to get the correct JavaPlugin...\nVersion :\"+VERSION_REQUIRED);
		    window.open(\"http://java.sun.com/javase/downloads/index.jsp\",\"\",\"status=1,toolbar=1,width=600,height=480\");
		}
	    }
	                
	    if(document.getElementById){
		document.getElementById(\"notify\").style.visibility = \"hidden\";
	    }
	    else
	    {
		if (document.layers) {
		    document.notify.visibility = \"hidden\";
		}
		else
		{
		    document.all.notify.style.visibility = \"hidden\";
		}
	    }
	</script>
	<applet name=\"molapplet\" code=\"WIMSchem.MainApplet\" archive=\"dist/WIMSchem.jar\" width=\"550\" height=\"550\">
	    <param name=\"language\" value=\"en\">
	    <param name=\"formattype\" value=\"plain\"> <!-- plain,html,latex representation of formulas --->
	    <!-- the lefthand tool button bar -->
	    <param name=\"TOOL_CURSOR\" value=\"yes\">
	    <param name=\"TOOL_ROTATOR\" value=\"yes\">
	    <param name=\"TOOL_ERASOR\" value=\"yes\">
	    <param name=\"TOOL_DIALOG\" value=\"yes\">
	    <param name=\"TOOL_EDIT\" value=\"yes\">
	    <param name=\"TOOL_SETATOM\" value=\"yes\">
	    <param name=\"TOOL_SINGLE\" value=\"yes\">
	    <param name=\"TOOL_DOUBLE\" value=\"yes\">
	    <param name=\"TOOL_TRIPLE\" value=\"yes\">
	    <param name=\"TOOL_ZERO\" value=\"yes\">
	    <param name=\"TOOL_INCLINED\" value=\"yes\">
	    <param name=\"TOOL_DECLINED\" value=\"yes\">
	    <param name=\"TOOL_CHARGE\" value=\"yes\">
	    <param name=\"TOOL_UNDO=\" value=\"yes\">
	    <param name=\"TOOL_REDO=\" value=\"yes\">
	    <param name=\"TOOL_TEMPLATE\" value=\"yes\">
	    <param name=\"TOOL_CUT\" value=\"yes\">
	    <param name=\"TOOL_COPY\" value=\"yes\">
	    <param name=\"TOOL_PASTE\" value=\"yes\">
	    <!-- the top menu -->
	    <param name=\"MENU_BLOCK\" value=\"yes\">
	    <param name=\"MENU_SELECT\" value=\"yes\">
	    <param name=\"MENU_TRANSFORM\" value=\"yes\">
	    <param name=\"MENU_ZOOM\" value=\"yes\">
	    <param name=\"MENU_SHOW\" value=\"yes\">
	    <param name=\"MENU_HYDROGEN\" value=\"yes\">
	    <param name=\"MENU_STEREO\" value=\"yes\">
	    <param name=\"MENU_HELP\" value=\"yes\">
	    (java unavailable)
	</applet>
    </th>
    <th valign=\"top\">
	<table>
	    <td halign=left>
		Molecule text representation:<br>
		<form name=\"js\">
		    <textarea name=\"moltext\" rows=\"17\" cols=\"50\"></textarea><br>
		    <textarea name=\"a_reply\" rows=\"2\" cols=\"50\"></textarea>
		    <div name=\"showhtml\" id=\"showhtml\"></div>
		</form>
		    <br>
		    <a onClick=\"javascript:Set_Some_Chemical()\">Show me a random question chemical</a>
		    <br>
		    <a onClick=\"javascript:GetMoleculeNative()\">Get the Native fileformat from the drawing</a>
		    <br>
		    <a onClick=\"javascript:SetMoleculeNative()\">Set drawing from textarea [Native]</a>
		    <br>
		    <a onClick=\"javascript:GetMoleculeMDLMol()\">Get the MDLMol fileformat from the drawing</a>
		    <br>
		    <a onClick=\"javascript:SetMoleculeMDLMol()\">Set drawing from textarea [MDLMol]</a>
		    <br>
		    <a onClick=\"javascript:ReadApplet()\">info about the correct drawing</a>
	    </td>
	    <tr>
		<td align=left>
		    <button type=\"button\" onClick=\"CompareNative()\">COMPARE DRAWING</button>
		</td>
		<tr>                                                                                                                       
                <td>
		    <small>
		    When signature [jar sign]  is accepted, the applet will become a standalone application<br>
		    if the <em>new window</em> is clicked in the menu.<br>
		    The browser will not communicate with this standalone java application window.<br>
		    So the CompareNative() will not read the molecule.<br>
		    It could be used to draw [question] chemicals and save them in Native of MDLmol format.<br>
		    Or use the \"export to javascript\" to generate a javascript string.
		    [see \"jm.evers module\" on chemistry].
            	    </small>
		</td>            
	    </table>	
	</form>
    </th>
</table>

</body>
</html>


" > 1.html
fi

rm -rf ~/.java
rm dist/*jar
ant -v -l log.txt dist
if [ -e dist/WIMSchem.jar ] ; then
    ./jarsign
    tar cvzf WIMSchem.src.tar.gz *.java build.xml make.sh templ ds chemical images lang 1.html
    # testing applet:
    # appletviewer 1.html
    mozilla file://`pwd`/1.html
    
    #testing application:
    # java -jar dist/WIMSchem.jar
else
    tail -n 50 log.txt
    read anything
    exit
fi    
