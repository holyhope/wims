#!/bin/sh

find ./build -type f -name "*.class" -exec rm "{}" ";" 
rm build/zirkel.jar*
ant -v jar -l log.txt

if [ -e "build/zirkel.jar" ] ; then
    mozilla file://`pwd`/1.html
else
    echo "build failed"
    read whatever
fi

