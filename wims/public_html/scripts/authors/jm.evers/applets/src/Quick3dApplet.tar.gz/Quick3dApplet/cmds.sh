#!/bin/sh
\rm -f *.class *.jar
javac -target 1.5 -extdirs "" *.java 
jar cf Quick3dNet.jar *.class
