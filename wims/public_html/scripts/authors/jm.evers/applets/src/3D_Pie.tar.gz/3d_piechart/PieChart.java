/*Real's Howto copyright notice  (real@rgagnon.com)
 *    -----------------------------
 *
 *Redistribution and use in source and binary forms, 
 *with or without modification, are permitted provided 
 *that the following conditions is met:
 *
 *the source code is used in a development project
 *  
 *   DISCLAIMER
 *
 *  THIS SOFTWARE IS PROVIDED BY Real Gagnon "AS IS" AND ANY
 *  EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 *  TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 *  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL 
 *  Real Gagnon BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
 *  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
 *  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
 *  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 *  STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 *  OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
 *  SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *
 * Simple Applet to demonstrate the use of PieChartCanvas
 *
 * author		Ciaran Treanor
 * email		ciaran@broadcom.ie
 * phone		+353-1-604-6000
 * web			http://www.broadcom.ie/~ct
 *
 * Revision History:
 *
 * 4-Dec-1995 : Use hashtable to map string names to colours
 *              Thanks to Jonathan Payne for the tip!
 *
*/
import java.util.*;
import java.awt.*;
import java.applet.Applet;


public class PieChart extends Applet {
  int depth, Width, AppletWidth;
  String title;

  public void init() {
    double value;

// Get necessary parameters
    String at = getParameter("width");
    AppletWidth = (at != null) ?  Integer.valueOf(at).intValue() : 100;
    at = getParameter("piewidth");
    Width = (at != null) ?  Integer.valueOf(at).intValue() : 100;
    at = getParameter("depth");
    depth = (at != null) ? Integer.valueOf(at).intValue() : 20;
    title = getParameter("title");
    if ( title == null ) 
      title = "";
    at = getParameter("values");

    PieChartCanvas c = new PieChartCanvas(Width, depth, false);
    setLayout(new BorderLayout());

// Create Hashtable to map color name (String) to Color type
    Hashtable colors = new Hashtable();
    colors.put("green", Color.green);
    colors.put("red", Color.red);
    colors.put("blue", Color.blue);
    colors.put("yellow", Color.yellow);
    colors.put("magenta", Color.magenta);
    colors.put("cyan", Color.cyan);
    colors.put("orange", Color.orange);
    colors.put("pink", Color.pink);
    colors.put("white", Color.white);
    colors.put("black", Color.black);

    PieLegend legend = new PieLegend(c.getPieLeft(), Width, 30 );

// Use a StringTokenizer to extract the slice values and colors
// They are comma separated value-color combinations
    int j=1;
    Color col;
    for(StringTokenizer t = new StringTokenizer(at, ","); t.hasMoreTokens();) {
	String str = t.nextToken();
	int i = str.indexOf('-');
	value = Double.valueOf(str.substring(0, i)).doubleValue();
        col = (Color)colors.get(str.substring(i + 1));
        if ( value > 0 ) {
	  c.addSlice(value, col );
	  legend.addSlice( col, ""+j );
        }
        j++;
    }
    add("North", new Label( title, Label.CENTER ) );
    add("South", legend );
    add("Center", c);
  }
}

class PieLegend extends Canvas {
  int Width, Interior, Left, Height, numSlices=0;
  Color colors[] = new Color[20];
  String labels[] = new String[20];
  Font font;
  FontMetrics fm;

  public PieLegend(int left, int width, int height) {
    font = new Font("Courier", Font.PLAIN, 12 );
    fm = getFontMetrics(font);

    Width = width;
    Height = height;
    Left = left;
    resize( Width+Left, Height );
  }

  public void addSlice( Color color, String text ) {
     colors[numSlices] = color;
     labels[numSlices] = text;
     numSlices++;
  }

  public void paint(Graphics g) {
    int blocksize, strwid, strht, left, i;

    blocksize = Width/numSlices;
    strht = fm.getAscent()+1;

    for (i=0, left=Left; i<numSlices; i++, left+=blocksize ) {
       g.setColor( colors[i] );
       g.fillRect( left+2, strht+1, blocksize-2, Height-strht-2 );
       g.setColor( Color.black );
       g.drawLine( left+blocksize, strht+1, left+blocksize, Height );
       strwid = fm.stringWidth(labels[i]);
       g.drawString(labels[i],left+(blocksize-strwid)/2,strht);
    }
  }
}

/**
 *
 * PieChartCanvas Class - Draws a 3D PieChart
 *
 * @version		1.02	4-Dec-1995
 * @author		Ciaran Treanor
 *
 * email		ciaran@broadcom.ie
 * phone		+353-1-604-6000
 * web			http://www.broadcom.ie/~ct
 *
 * Revision History:
 *
 * 1-Dec-1995 : Added buffering to do graphics offscreen
 *
 * 10-Dec-1996: Add title and labels around the pie
 *              Arlen Strader
 */
class PieChartCanvas extends Canvas {
  final double aspectFudge = 2.5;
  int Width;
  int depth, called = 1, numSlices = 0;
  int Cx, Cy, Rx, Ry;
  int PieLeft, PieTop;
  boolean DoLabels = true  ;
  double total = 0, value[] = new double[20];
  String label[] = new String[20];
  Color color[] = new Color[20];
  Graphics offGraphics;
  Image gfxBuff;
  Font font;
  FontMetrics fm;

  public PieChartCanvas(int width, int depth, boolean labels) {

    font = new Font("Courier", Font.PLAIN, 12 );
    fm = getFontMetrics( font );

    DoLabels = labels;
    this.value = value;
    this.color = color;
    Width = width;
    this.depth = depth;

    Rx = Width / 2;
    Ry = (int) ( Width/( 2.* aspectFudge ) );

    PieLeft = (int)(0.2*Rx) + 5;
    PieTop = (int)(0.2*Ry) + 5;
    if ( DoLabels ) {
      PieLeft += fm.stringWidth("AAA");
      PieTop += fm.getAscent();
    }
    Cx = Rx+ PieLeft;
    Cy = Ry+ PieTop;

    resize(minimumSize().width, minimumSize().height);
  }

  public int getPieLeft() {
    return PieLeft;
  }

  public void paint(Graphics g) {
    int startAngle;
    double angle;
    Dimension d = size();
    
    if(gfxBuff == null) {
      gfxBuff = createImage(d.width, d.height);
      offGraphics = gfxBuff.getGraphics();
      offGraphics.setColor(getBackground());
      offGraphics.fillRect(0, 0, d.width, d.height);
    }

// This is less than optimal, but we don't have a floodfill.
// Draw depth-1 ovals in a darker colour
    for(int x = depth; x >= 1; x--) {
      startAngle = -45;
      for(int i = 0; i < numSlices; i++) {
        offGraphics.setColor(color[i].darker());
        angle = Math.round(360 * (value[i] / total));
        offGraphics.fillArc(PieLeft, PieTop + x, 
			    Width, (int)(Width / aspectFudge),
			    startAngle, (int)angle);
	startAngle += angle;
      }
    }

// Now draw the final (top) oval in the undarkened color		
    startAngle = -45;
    for(int i = 0; i < numSlices; i++) {
	offGraphics.setColor(color[i]);
	angle = Math.round(360 * (value[i] / total));
	offGraphics.fillArc(PieLeft, PieTop, 
			    Width, (int)(Width / aspectFudge),
			    startAngle, (int)angle);
	startAngle += angle;
    }

    if ( DoLabels ) {
      /* Add labels around the periphery of the chart */
      startAngle = -45;
      offGraphics.setColor( Color.black );
      double Mid, sx, sy;
      for(int i=0; i<numSlices; i++ ) {
	angle = Math.round(360*value[i]/total);
	Mid = (startAngle+angle/2.)*Math.PI / 180.0;

	sx = 1.2*Rx*Math.cos(Mid);
	sy = 1.2*Ry*Math.sin(Mid);

	if ( Mid < 0. ) {
	  sy -= ( fm.getAscent() + depth );
	} else if ( Mid < Math.PI/2. ) {
	} else if ( Mid < Math.PI ) {
	  sx -= fm.stringWidth(""+i);
	} else {  /* Mid < 270 */
	  sx -= fm.stringWidth(""+i);
	  sy -= ( fm.getAscent() + depth );
	}

	offGraphics.drawString(label[i], (int)(sx+Cx), (int)(-sy+Cy) );
	startAngle += angle;
      }
    }

    offGraphics.setColor( Color.black );
//null
    g.drawImage(gfxBuff, 0, 0, null);
  }

  public void addSlice(double value, Color color) {
    this.value[numSlices] = value;
    label[numSlices] = "";
    this.color[numSlices++] = color;
    total += value;
    resize( minimumSize().width, minimumSize().height );
  }

  public void addSlice(double value, Color color, String text) {
    this.value[numSlices] = value;
    this.label[numSlices] = text;
    this.color[numSlices++] = color;
    total += value;
    resize( minimumSize().width, minimumSize().height );
  }

  public Dimension preferredSize() {
    return minimumSize();
  }

  public Dimension minimumSize() {
    int maxwidth;

    if ( DoLabels ) {
      maxwidth = MaxLabelWidth();
      return new Dimension( 2* (PieLeft + Rx + maxwidth), 
			    2* (PieTop + Ry + fm.getAscent() ) +depth );
    } else {
       return new Dimension( 2*(PieLeft + Rx), 2*(PieTop+Ry)+depth );
    }
  }

  public int MaxLabelWidth() {
    int max=0;
    for (int i=0; i<numSlices; i++) {
      if ( fm.stringWidth( label[i] ) > max )
	max = fm.stringWidth( label[i] );
    }
    return max;
  }
}
