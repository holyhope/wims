package geo ;

/**
 * Fonction abstraite � �tendre.
 */

public abstract class Fonction
{ 

/**
 * Retourne "true" si l'image de x existe.
 */

  public abstract boolean defini (double x) ;

/**
 * Retourne l'image de x.
 */

  public abstract double Image (double x) ;

}