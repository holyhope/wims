//  Copyright (C) 2004 Philip Proudman
//
//  This file is part of Quick3dApplet
//
//  Quick3dApplet is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  Quick3dApplet is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with Quick3dApplet in the file called "COPYING" in the top directory;
//  if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


package Quick3dApplet;

public final class Vec2 {
    public float x;
    public float y;
    
    public Vec2() {}

    public Vec2(float xi, float yi) {
        x = xi;
        y = yi;
    }

    public void set(float xi, float yi) {
        x = xi;
        y = yi;
    }

    public String toString() {
        return (x+","+y);
    }
    
    public float magnitude() {
        return (float)(Math.sqrt(x*x + y*y));
    }

    public void makeUnitVec() {
        float m = 1/magnitude();
        x *= m;
        y *= m;
    }

    public static float dot(Vec2 v1, Vec2 v2) {
        return v1.x*v2.x + v1.y*v2.y;
    }

    public static Vec2 add(Vec2 v1, Vec2 v2) {
        return new Vec2(v1.x+v2.x, v1.y+v2.y);
    }

    public static Vec2 sub(Vec2 v1, Vec2 v2) {
        return new Vec2(v1.x-v2.x, v1.y-v2.y);
    }
    
    public static Vec2 mul(Vec2 v, float s) {
        return new Vec2(v.x*s, v.y*s);
    }
}
