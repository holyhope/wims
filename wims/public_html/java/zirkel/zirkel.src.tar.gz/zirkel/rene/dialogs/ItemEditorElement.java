package rene.dialogs;

public interface ItemEditorElement
{	public String getName ();
}
