// horrible amateur scriblings...no copyrights

import java.applet.*;
import java.awt.*;
import java.util.*;
import java.awt.event.*;
import java.lang.Math;
import java.net.*;

//    <param name="max" value="20">                                                                                                  
//    <param name="renew" value="yes">                                                                                               
//    <param name="language" value="nl">                                                                                             
//    <param name="show_result" value="no">

public class VreemdeEend2 extends Applet implements Runnable{
    private static final long serialVersionUID = 1L;
    Thread thread = null;Graphics canvas;String replystring="";
    public int sy=22;public int xsize=680;public int ysize=7*sy;
    int dx;int dy;long start;int foutcounter=1;
    double diff;String duration="" ;
    int counter;int goedeantwoord;
    long stop;public long totaltime=0;
    public Image ok;public Image nok;
    String[][] Antwoorden;int v1;int v2;int v3;int v4;
    String[] Vragen;int records=0;int goedzo=1;int klaar=0;
    int volgorde[]={1,2,3,4};long begin;int pressed=1;
    int vraagnummers[];
    int fnsize=14;Font defaultFont = new Font( "Helvetica", Font.BOLD, fnsize );  
    Color blauw=new Color(0,0,255);
    Color zwart=new Color(0,0,0);
    Color kleur;int max=10;
    int m1=0;int m2=0;
    
    public void init(){
        begin=System.currentTimeMillis();klaar=0;
	ok=getImage(getCodeBase(), "ok.gif");nok=getImage(getCodeBase(), "nok.gif");
	String questions=getParameter("questions");if(questions==null){System.out.println("CAN NOT READ QUESTION PARAM");}
	String ss=getParameter("max");if(ss!=null && ss.length()>0){max = Integer.parseInt(ss, 10);}
	StringTokenizer vragen = new StringTokenizer(questions, ":");
	String vraag="";String antwoord="";int w=0;
	Antwoorden=new String[max][4*max];
	vraagnummers=new int[max+1];
	Vragen=new String[max+1];
	int tmp=0;
	for(int s=0;s<max-1;s++){
	    vraag=vragen.nextToken();
	    StringTokenizer antwoorden = new StringTokenizer(vraag, ";");
	    w=antwoorden.countTokens();
	    vraagnummers[s]=s;
	    for(int r=0;r<w;r++){
		antwoord=antwoorden.nextToken();
		tmp=fnsize*antwoord.length();if(tmp>xsize){xsize=tmp;}
		if(r==0){
		    Vragen[s]=antwoord;
		    //System.out.println("de vraag = "+antwoord);
		}
		else
		{
		    Antwoorden[s][r-1]=antwoord;
		    //System.out.println("antwoord  ="+antwoord);
		}
	    }
	}
	vraagnummers=Shuffle(vraagnummers);
	
	addMouseMotionListener(new MouseMotionAdapter(){
	    public void mouseMoved(MouseEvent e){
		dy = e.getY();
		kleur=zwart;
		for(int i=2;i<6;i++){
		    m1=i*sy;m2=(i+1)*sy;
		    if(dy>m1 && dy<m2){
			pressed=0;
			kleur=blauw;
			i=10;
		    }
		}
		repaint();
	    }
	}
	);
	
	
	addMouseListener(
	    new MouseAdapter(){
		public void mousePressed(MouseEvent e){
		    dx = e.getX();
		    dy = e.getY();
		    if(klaar==0){
			kleur=zwart;
			for(int p=2;p<7;p++){
			    if(dx>0 && dx<xsize){
				if(dy>(p)*sy+5 && dy<(p+1)*sy+5){
				    if(counter==max){klaar=1;}
				    if(goedeantwoord==p){
					stop=System.currentTimeMillis();
					diff=(double)(stop-start)/1000;
					duration=duration+","+diff;
					replystring=replystring+"\n"+diff+":"+foutcounter;
					foutcounter=1;
					counter++;goedzo=1;
					start=System.currentTimeMillis();
					pressed=1;
				    }
				    else
				    {
					goedzo=0;foutcounter++;
					pressed=0;
				    }
				    repaint();
				}
			    }
			}
		    }
		}
	    }
	);

    }

       
    public static int[] Shuffle(int[] S){
	    int ll= S.length;
	    for (int i=0;i<ll;i++){
		int r = (int) (Math.random() * (i+1));
		int swap = S[r];
		S[r] = S[i];
		S[i] = swap;
	    }
	    for(int i=0;i<ll;i++){
            //System.out.println(S[i]);
	    }
        return S;
    }
    
    
    public void paint(Graphics canvas){
	if(counter==0){start=begin;}
	if(klaar==0){
	    int num=vraagnummers[counter];
	    canvas.setColor(Color.black);canvas.fillRect(0,0,xsize,ysize);
	    canvas.setColor(kleur);canvas.fillRect(0,m1+5,xsize,m2+5);
	    canvas.setColor(Color.black);canvas.fillRect(0,m2+5,xsize,6*sy);
	    canvas.setFont(defaultFont);canvas.setColor(Color.yellow);
	    canvas.drawString("Multiplechoice Q "+(counter+1)+") ",10,sy);
	    canvas.drawString(Vragen[num],10,2*sy);
	    canvas.setColor(Color.white);
	    if(pressed!=0){volgorde=Shuffle(volgorde);}
	    int k;
	    for(int p=0;p<4;p++){
		k=volgorde[p];
		if(k==4){goedeantwoord=p+2;}
		canvas.setColor(Color.red);canvas.drawLine(0,(p+3)*(sy)+5,xsize,(p+3)*(sy)+5);
		canvas.setColor(Color.white);canvas.drawString((p+1)+") "+Antwoorden[num][k-1],10,(p+3)*(sy));
	    }
	    canvas.clearRect(0,6*sy+5,xsize,ysize);
	    canvas.setColor(Color.black);canvas.fillRect(0,6*sy+5,xsize,ysize);
	    if(goedzo==0){
		canvas.drawImage(nok,50,ysize, this);
	    }
	    else
	    {
		canvas.drawImage(ok,50,ysize, this);
	    }
	}
	
	if(klaar==1){
	    canvas.setColor(Color.black);canvas.fillRect(0,0,xsize,ysize);
	    canvas.setFont(defaultFont);
	    StringTokenizer q = new StringTokenizer(replystring, "\n");
	    int m=q.countTokens(); 
	    String sub="";int X=10;int Y=10; 
	    canvas.setColor(Color.white);
	    canvas.drawString("time :attempts",X,Y);
	    for(int s=0;s<m;s++){
		Y=Y+14;sub=q.nextToken(); canvas.drawString(sub,X,Y);
		if(Y>(ysize-14)){ X=X+120; Y=10;canvas.drawString("time :attempts",X,Y);}
	    }
	}
			//System.out.println("goede antwoord="+goedeantwoord);
    }
 
    public void start(){
	if(thread == null){
	    thread = new Thread(this);
    	    thread.start();
	}
    }

 
    public void stop(){
	thread =null;
    }

    public void run(){
	while(thread != null){
	try{
	    Thread.sleep(100);
	}
	catch (InterruptedException e){
	}
    }
}

public void update( Graphics canvas ){
    paint( canvas ) ;
}
 
public String ReadApplet(){
    if(counter<max){
	return "error: not finished";
    }
    else
    {
	double totaltime=(double) (stop-begin)/1000;
	return totaltime+":"+(max-1)+"\n"+replystring;
    }
}
 
 
}










































