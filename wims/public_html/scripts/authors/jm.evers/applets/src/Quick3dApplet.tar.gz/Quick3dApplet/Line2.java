//  Copyright (C) 2004 Philip Proudman
//
//  This file is part of Quick3dApplet
//
//  Quick3dApplet is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  Quick3dApplet is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with Quick3dApplet in the file called "COPYING" in the top directory;
//  if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


package Quick3dApplet;
import java.util.*;

final class Line2
{
    public Vec p1;
    public Vec p2;
    public Tri t;

    public float currentX;
    public float deltaX;
    public float currentZ;
    public float deltaZ;
    public byte flag; // The lower 3 bits indicate the "side" of the triangle

    public static final byte YFLIP = 8;
    public static final byte CURRENT_X_CALC = 16;
    
    public Line2(byte fl, Tri tl) { flag = fl; t = tl; }

    public void set(Vec p1i, Vec p2i) {
        if (p1i.y < p2i.y) {
            p1 = p1i;
            p2 = p2i;
            flag &= (byte)23; // Clear YFLIP
        }
        else if (p1i.y == p2i.y) {
            flag &= (byte)23; // Clear YFLIP
            p1 = new Vec(10000, 10000, 10000);
            p2 = p1;
        }
        else {
            p1 = p2i;
            p2 = p1i;
            flag |= YFLIP;
        }
    }

    public void calcCurrentX(float y) {
        flag |= CURRENT_X_CALC;
        float f = 1/(p2.y - p1.y);
        if (f<10000) {
            deltaX = (p2.x - p1.x)*f;
            float di = y - p1.y;
            currentX = p1.x + deltaX*di;
            deltaZ = (p2.z - p1.z)*f;
            currentZ = p1.z + deltaZ*di;
        } else {
            currentX = 10000; // Something bigger than the pixmap
            deltaX = 0;
        }
    }

    public String toString() {
        return (p1+"->"+p2);
    }
}
