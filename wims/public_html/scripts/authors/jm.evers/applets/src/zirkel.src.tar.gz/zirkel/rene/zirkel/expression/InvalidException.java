package rene.zirkel.expression;

import rene.zirkel.construction.ConstructionException;

public class InvalidException extends ConstructionException
{	public InvalidException (String s)
	{	super(s);
	}
}
