//  Copyright (C) 2001 Trenkwalder Markus
//  Copyright (C) 2004 Philip Proudman
//
//  This file is part of Quick3dApplet
//
//  Quick3dApplet is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  Quick3dApplet is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with Quick3dApplet in the file called "COPYING" in the top directory;
//  if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

package Quick3dApplet;
import java.awt.*;

public abstract class Mouse extends tinyptc {
    //************************************************************
    // Mauszust�nde abfragen
    //************************************************************
    
    // Zuweisung von Konstanten f�r die einzelnen Maustasten

    public final int LEFTBUTTON   = 0;
    public final int RIGHTBUTTON  = 1;
    public final int MIDDLEBUTTON = 2;
    
    // Maus X-Koordinate abfragen
    public int getMouseX() {
        return _mouseX;
    }
    
    // Maus Y-Koordinate abfragen
    public int getMouseY() {
        return _mouseY;
    }
    
    // Zustand einer Maustaste abfragen
    public boolean getMouseButton(int button)
    {
        switch (button)
            {
            default:
            case LEFTBUTTON:
                return _mouseButton1;
            case RIGHTBUTTON:
                return _mouseButton2;
            case MIDDLEBUTTON:
                return _mouseButton3;
            }
        
    }
    
    
    
    //************************************************************
    // Mausereignisse bearbeiten
    //************************************************************
    
    // Mauskoordinaten
    int _mouseX = 0, _mouseY = 0;
    
    // Maustaste gedr�ckt?
    boolean _mouseButton1 = false;
    boolean _mouseButton2 = false;
    boolean _mouseButton3 = false;
    
    //************************************************************
    
    public boolean mouseDown(Event evt, int x, int y) {
        _mouseX = x;
        _mouseY = y;
        
        if (evt.metaDown())
            // einen Klick mit der rechten Maustaste verarbeiten
            _mouseButton2 = true;
        else if (evt.controlDown())
            // einen Klick mit der mittleren Maustaste verarbeiten 
            _mouseButton3 = true;
        else // einen normalen Klick verarbeiten
            _mouseButton1 = true;
        
        return true;
    } 
    
    //************************************************************

    public boolean mouseUp(Event evt, int x, int y) {
        _mouseX = x;
        _mouseY = y;
        
        if (evt.metaDown())
            // einen Klick mit der rechten Maustaste verarbeiten
            _mouseButton2 = false;
        else if (evt.controlDown())
            // einen Klick mit der mittleren Maustaste verarbeiten 
            _mouseButton3 = false;
        else // einen normalen Klick verarbeiten
            _mouseButton1 = false;
        
        return true;
    } 
    
    //************************************************************

    public boolean mouseMove(Event evt, int x, int y) {
        _mouseX = x;
        _mouseY = y;
        
        return true;
    }
    
    //************************************************************
    
    public boolean mouseDrag(Event evt, int x, int y) {
        _mouseX = x;
        _mouseY = y;
        
        return true;
    }

    //************************************************************
    
    public boolean mouseEnter(Event evt, int x, int y) {
        _mouseX = x;
        _mouseY = y;
        
        return true;
    }
    
    //************************************************************

    public boolean mouseExit(Event evt, int x, int y) {
        _mouseX = x;
        _mouseY = y;
        
        return true;
    }

    //************************************************************
    //************************************************************
}
