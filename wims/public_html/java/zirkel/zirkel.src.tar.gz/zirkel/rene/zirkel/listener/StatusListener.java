package rene.zirkel.listener;

public interface StatusListener
{	void showStatus (String s);
}
