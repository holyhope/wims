//  Copyright (C) 2004 Philip Proudman
//
//  This file is part of Quick3dApplet
//
//  Quick3dApplet is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  Quick3dApplet is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with Quick3dApplet in the file called "COPYING" in the top directory;
//  if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


import java.io.*;
import java.text.*;
import java.util.*;
import java.applet.*;
import Quick3dApplet.*;

public class threeDs extends Mouse
{
    public void main(int width, int height)
    {
        // Put up the loading picture
        Pixstore image = new Pixstore(width, height);
        Render rend = new Render(this, image);

        // Read parameters
        boolean doRotate = false;
        boolean antiAlias = false;
        RenderObject obj = null;
        Matrix rot = new Matrix();
        {
            String threeDsFile = getParameter("3DS_FILE");
            String backgroundPic = getParameter("BACKGROUND");
            String autoRotate = getParameter("AUTO_ROTATE");
            String initialRotX = getParameter("ROT_X");
            String initialRotY = getParameter("ROT_Y");
            String initialRotZ = getParameter("ROT_Z");
            String antiAliasSt = getParameter("ANTI_ALIAS");
            String split = getParameter("SPLIT3D");
            
            if (backgroundPic != null) {
                rend.background = new Pixstore(this, backgroundPic, image);
            }
            if (autoRotate != null && autoRotate.equals("TRUE")) {
                doRotate = true;
            }
            if (antiAliasSt != null && antiAliasSt.equals("TRUE")) {
                antiAlias = true;
            }
            if (split != null && split.equals("TRUE")) {
                rend.split3d = true;
            }
            float rx=0; float ry=0; float rz=0;
            if (initialRotX != null) {
                try {
                    rx = (float)(Integer.decode(initialRotX).intValue()*Math.PI/180);
                } catch (NumberFormatException e) {
                    System.out.println("Error with integer number "+initialRotX);
                }
            }
            if (initialRotY != null) {
                try {
                    ry = (float)(Integer.decode(initialRotY).intValue()*Math.PI/180);
                } catch (NumberFormatException e) {
                    System.out.println("Error with integer number "+initialRotY);
                }
            }
            if (initialRotZ != null) {
                try {
                    rz = (float)(Integer.decode(initialRotZ).intValue()*Math.PI/180);
                } catch (NumberFormatException e) {
                    System.out.println("Error with integer number "+initialRotZ);
                }
            }
            rot.setRotationXyzProgressive(rx, ry, rz);
            
            // Load model
            if (threeDsFile == null) {
                System.out.println("Please supply a 3ds filename..");
                System.out.println("<PARAM NAME=\"3DS_FILE\" VALUE=\"teapot.3ds\">");
            }
            else {
                InputStream in = threeDs.class.getResourceAsStream( threeDsFile );
                obj = get3ds(in);
            }
        }

        // Centre and place the object at a good distance
        Vector objects = new Vector();
        rend.optimise(obj);
        {
            Vec cen = obj.getCentre();
            obj.offsetAll( new Vec(-cen.x, -cen.y, -cen.z), .6f/obj.getRadious() );
            rend.optimise(obj);
        }
        obj.offs.set(0, 0, 4.6f);
        objects.addElement(obj);

        // Init main loop variables
        long timeStart = System.currentTimeMillis();
        Thread thisThread = Thread.currentThread();
        int lastX=0;
        int lastY=0;
        
        boolean firstPress = true;
        
        final float speed = 0.06f;
        int driftCount = 50;
        Matrix driftRot = new Matrix();
        driftRot.setRotationXyzProgressive(speed,0,0);
        boolean still = false;
        boolean drawn = false;
        
        while(true) {
            if (getMouseButton(RIGHTBUTTON)) {
                int nx = getMouseX();
                int ny = getMouseY();
                int xr = width>>1;
                int yr = height>>1;
                if (firstPress) {
                    lastX = nx;
                    lastY = ny;  
                    firstPress = false;
                }
                float rx = (float)(nx-xr)/xr;
                float ry = (float)(ny-yr)/yr;
                nx -= lastX;
                ny -= lastY;
                if (nx != 0 || ny != 0) {
                    drawn = false;
                    float zr = nx*ry - ny*rx;
                    lastX += nx;
                    lastY += ny;
                    Matrix delta = new Matrix();
                    delta.setRotationXyzProgressive(-ny*(1-Math.abs(rx))*.03f,
                                                    nx*(1-Math.abs(ry))*.03f,
                                                    zr*.03f);
                    rot = Matrix.mul(rot, delta);
                }
                driftCount = 75; // Hold still for a while after dragging
                still = true;
            }
            else {
                // Do an automatic rotation if the user isn't dragging
                firstPress = true;
                if (!still && doRotate) {
                    rot = Matrix.mul(rot, driftRot);
                    drawn = false;
                }
                if (--driftCount == 0) {
                    // Change dir
                    driftCount = 50;
                    Vec dir = new Vec((float)Math.random()-.5f,
                                      (float)Math.random()-.5f,
                                      (float)Math.random()-.5f);
                    if (Math.abs(dir.x) < 0.1) dir.x = 0.2f;
                    dir.makeUnitVec();
                    dir = Vec.mul(dir, speed);
                    driftRot.setRotationXyzProgressive(dir.x, dir.y, dir.z);
                    still = false;
                }
            }

            // Render
            int refreshPeriod = 200;
            if (!drawn) {
                obj.rot = rot;
                if (!antiAlias &&
                    !firstPress ||
                    (doRotate && !still)) {
                    rend.antiAlias = false;
                    rend.draw(objects, image);
                }
                else {
                    if (!rend.split3d) rend.antiAlias = true;                
                    rend.draw(objects, image);
                    drawn = true;
                }
                refreshPeriod = 40;
            }
            update(image.pix);

            // Timing
            long unt = timeStart + refreshPeriod;
            long t2 = System.currentTimeMillis();
            long diff = t2 - unt;
            timeStart = t2;
            if (diff < 0) {
                try {
                    thisThread.sleep(-diff);
                    timeStart -= diff;
                }
                catch (java.lang.InterruptedException r) {}
            }
        }
    }

    private RenderObject get3ds(InputStream in) {
        RenderObject ro = new RenderObject();
        
        ThreeDStudioReader r = new ThreeDStudioReader(ro);

        try {
            System.out.println("Start reading 3ds file..");
            r.readChunk(in);
            System.out.println("..completed reading 3ds file");
        }
        catch (java.io.IOException e) {
            System.out.println("Oops " + e.getMessage());
        }

        return ro;
    }
}
