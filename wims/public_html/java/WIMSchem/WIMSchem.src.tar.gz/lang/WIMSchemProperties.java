package WIMSchem.lang;

public abstract class WIMSchemProperties{
}
