//  Copyright (C) 2004 Philip Proudman
//
//  This file is part of Quick3dApplet
//
//  Quick3dApplet is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  Quick3dApplet is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with Quick3dApplet in the file called "COPYING" in the top directory;
//  if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


package Quick3dApplet;
import java.util.*;

//***************************************************************************

// All vertexes are rotated by matrix "rot" and offset by "offs"
// viewpoint is always (0,0,0) looking down the z axis.

final public class Render
{
    // User settings..
    public boolean shade = true; // Do we shade the triangles according to the current normal
    public float zdist = 3; // Zoom. The plane that we project onto is z=zdist...
    public boolean intersect = true; // Make this false for small speed up at the expense of...
    // no intersection calcs. This means that intersections (if they happen) won't display properly
    public int aascale = 2; // Anti-alias level. Do not exceed 8!

    // Rendermode
    public boolean antiAlias = false;
    public boolean split3d = false; // See disclaimer below
    // If set to true, set the applet width to be (height*2)+20
    // If set to false, applet width should be same as height


    // For split-screen 3d (window needs to be twice as wide)
    public float offs = .2f;
    public float poffs = .1f;
    public int gap = 20; // pixels
    public Pixstore background = null; // Background image (must be same size as image being rendered)

    public Render(tinyptc owner, Pixstore px) {
        drawSplash(owner, px);
        setLightDir(new Vec(0.33f,0.5f,.8f));
    }

    public void setAmbient(int level) {
         // Min ambient level, in 1/256 fractions
        amb = level;
        setLightDir(lightDir);
    }
    
    public void setLightDir(Vec ld) {
        lightDir = ld;
        lightDir.makeUnitVec();
        lightDirP1 = new Vec(1,0,0);
        lightDirP2 = Vec.cross(lightDir, lightDirP1);
        float m = lightDirP2.magnitude();
        if (m < 0.01) {
            lightDirP1.set(0,1,0);
            lightDirP2 = Vec.cross(lightDir, lightDirP1);
            m = lightDirP2.magnitude();
        }
        m = 1f/m;
        lightDirP2.x *= m;
        lightDirP2.y *= m;
        lightDirP2.z *= m;
        lightDirP1 = Vec.cross(lightDir, lightDirP2);
        PhongTri.initPhongMap(this);
    }
    
    public void draw(Vector renderObjects, Pixstore px) {
        redraw(renderObjects, renderObjects, px);
    }

    // This is faster than draw - but only if "redrawObjects"
    // contains a set of objects that occupy a small non-spread out
    // area of screen
    public void redraw(Vector allObjects, Vector redrawObjects, Pixstore px) {
        // Only draw the relevant bit of the board
        // .. this code calcultes the top and bottom of the
        // piece we are moving, and only redraws that section
        if (split3d)
            splitDraw(allObjects, px);
        else {
            int width = px.getWidth();
            int height = px.getHeight();
            if (antiAlias) {
                width *= aascale;
                height *= aascale;
            }

            int top; int bot;
            if (allObjects == redrawObjects) {
                top = 0; bot = px.getHeight()-1;
            }
            else {
                float topf = px.getHeight()-1;
                float botf = 0;
                for (int j=0; j < redrawObjects.size(); ++j) {
                    RenderObject moving = (RenderObject)redrawObjects.elementAt(j);
                    for (int i=0; i<moving.getTriNum(); ++i) {
                        Tri t = moving.triv[i];
                        if (t.in != 7) { // Not culled
                            if (t.a.xformed.y < topf) topf = t.a.xformed.y;
                            else if (t.a.xformed.y > botf) botf = t.a.xformed.y;
                            if (t.b.xformed.y < topf) topf = t.b.xformed.y;
                            else if (t.b.xformed.y > botf) botf = t.b.xformed.y;
                            if (t.c.xformed.y < topf) topf = t.c.xformed.y;
                            else if (t.c.xformed.y > botf) botf = t.c.xformed.y;
                        }
                    }
                }
                top = (int)topf;
                bot = (int)botf;
            }

            preCalc1(redrawObjects); // Vertices
            preCalc2(redrawObjects, width, height, width>>1); // Vertices

            if (allObjects != redrawObjects) {
                float topf = top; float botf = bot;
                for (int j=0; j < redrawObjects.size(); ++j) {
                    RenderObject moving = (RenderObject)redrawObjects.elementAt(j);
                    for (int i=0; i<moving.getTriNum(); ++i) {
                        Tri t = moving.triv[i];
                        if (t.in != 7) { // Not culled
                            if (t.a.xformed.y < topf) topf = t.a.xformed.y;
                            else if (t.a.xformed.y > botf) botf = t.a.xformed.y;
                            if (t.b.xformed.y < topf) topf = t.b.xformed.y;
                            else if (t.b.xformed.y > botf) botf = t.b.xformed.y;
                            if (t.c.xformed.y < topf) topf = t.c.xformed.y;
                            else if (t.c.xformed.y > botf) botf = t.c.xformed.y;
                        }
                    }
                }
                top = (int)topf;
                bot = (int)botf;
                if (antiAlias) { top /= aascale; bot /= aascale; }
                if (top < 0) top = 0;
                if (++bot >= px.getHeight()) bot = px.getHeight()-1;
            }
            if (antiAlias)
                preCalc3(allObjects, top*aascale, bot*aascale); // Tris
            else
                preCalc3(allObjects, top, bot); // Tris
            prepareRender();
                                            
            draw(allObjects, px, top, bot, px.getWidth());
        }
    }

    // If required, call this after rendering
    public boolean collisionDetect(RenderObject a, RenderObject b) {
        // Only works for two optimised, convex shapes!
        
        boolean colDet = false;
        // Quick proximity check
        if (a.getOptimised() && b.getOptimised()) {
            Vec aCen = Vec.add(a.offs, Matrix.mul(a.rot, a.getCentre()));
            Vec bCen = Vec.add(b.offs, Matrix.mul(b.rot, b.getCentre()));
            Vec diff = Vec.sub(aCen, bCen);
            float dist = diff.x*diff.x + diff.y*diff.y + diff.z*diff.z;
            dist = (float)Math.sqrt(dist);
            if (a.getRadious() + b.getRadious() > dist) {
                
                fastCull.setRenderObject(a, diff);
                for (int j = 0; !colDet && j < b.getVertNum(); ++j) {
                    Vec pt1 = b.vertv[j].xformed;
                    boolean out = false;
                    for (int i=0; !out && i<a.getTriNum(); ++i) {
                        Tri t = a.triv[i];
                        Vec pt2 = t.a.xformed;
                        if (!fastCull.isCulled(t.fastCullNum)) {
                            Vec norm = t.getNorm();
                            float d1 = Vec.dot(norm, pt1);
                            d1 -= Vec.dot(norm, pt2);
                            if (d1 > 0) out = true;
                        }
                    }
                    if (!out) colDet = true;
                }
            }
        }

        return colDet;
    }
    
    // If required, call this after rendering!
    public RenderObject getObjectPointedAt(Vector renderObjects, int x, int y) {
        if (antiAlias) { x *= aascale; y *= aascale; }
        Tri nt = null;
        RenderObject rv = null;
        Line2 [] myl = new Line2[2];
        for (int ob = 0; ob < renderObjects.size(); ++ob) {
            RenderObject o = (RenderObject)renderObjects.elementAt(ob);
            for (int i=0; i<o.getTriNum(); ++i) {
                Tri t = o.triv[i];
                if (t.in != 7) { // If not culled
                    // Are we within the correct height(y) range of this tri?
                    int c = 0;
                    if (t.l[0].p1.y <= y && t.l[0].p2.y >= y) myl[c++] = t.l[0];
                    if (t.l[1].p1.y <= y && t.l[1].p2.y >= y) myl[c++] = t.l[1];
                    if (c == 0) continue;
                    if (c != 2 && t.l[2].p1.y <= y && t.l[2].p2.y >= y) myl[c++] = t.l[2];
                    if (c != 2) continue;
                    
                    // Are we within the correct x range?
                    myl[0].currentX = myl[0].p1.x + (myl[0].p2.x - myl[0].p1.x) * (y - myl[0].p1.y)/(myl[0].p2.y - myl[0].p1.y);
                    myl[1].currentX = myl[1].p1.x + (myl[1].p2.x - myl[1].p1.x) * (y - myl[1].p1.y)/(myl[1].p2.y - myl[1].p1.y);
                    if (myl[0].currentX > myl[1].currentX) { Line2 tmp = myl[0]; myl[0] = myl[1]; myl[1] = tmp; }
                    if (x >= myl[0].currentX && x <= myl[1].currentX) {
                        // This tri is in the right place. Now for the depth....
                        myl[0].currentZ = myl[0].p1.z + (myl[0].p2.z - myl[0].p1.z) * (y - myl[0].p1.y)/(myl[0].p2.y - myl[0].p1.y);
                        myl[1].currentZ = myl[1].p1.z + (myl[1].p2.z - myl[1].p1.z) * (y - myl[1].p1.y)/(myl[1].p2.y - myl[1].p1.y);
                        t.depth = myl[0].currentZ + (myl[1].currentZ-myl[0].currentZ) * (x - myl[0].currentX)/(myl[1].currentX - myl[0].currentX);
                        if (nt == null || nt.depth < t.depth) {
                            nt = t;
                            rv = o;
                        }
                    }
                }
            }
        }
        return rv;
    }

    // Private stuff..
    private int linesSize = 0;
    private Line2 linesIn[]; // Vertically sorted list of the top of each Line2
    private Line2 linesOut[]; // Vertically sorted list of Line2 the bottom of each Line2
    private Line2 lines[]; // The set of active Line2 for this scanline
    private Line2 linesRem[];
    private Vector tris = new Vector();
    private int nLines;
    private RingBuffer rb = new RingBuffer();
    private int inY;
    private int outY;
    int idx;
    private int linesNum;
    private float clipPlane = .2f;
    private RenderObject clippedRo = new RenderObject();

    public void optimise(RenderObject ro) {
        ro.doOptimise(fastCull);
    }
    
    public void preCalc1(Vector renderObjects) {        
        // Calculate the vertex positions
        for (int ob = 0; ob < renderObjects.size(); ++ob) {
            RenderObject o = (RenderObject)renderObjects.elementAt(ob);
            for (int i=0; i<o.getVertNum(); ++i) {
                Vertex v = o.vertv[i];
                v.reset(o.rot, o.offs);
            }
            for (int i=0; i<o.getVertNormNum(); ++i) {
                VertexNorm v = o.vertNorm[i];
                v.reset(o.rot);
            }
        }
        clippedRo.clear();
    }

    public void preCalc2(Vector renderObjects, int width, int height, int wo) {
        // Calculate the vertex positions, and cull backfacing
        int numTriv = 0;
        float ho = height>>1;
        float ds = zdist * width;
        renderObjects.addElement(clippedRo);
        for (int ob = 0; ob < renderObjects.size(); ++ob) {
            RenderObject o = (RenderObject)renderObjects.elementAt(ob);
            // Prepare the fastCull
            if (o == clippedRo) {
                // We know all these are fine
                for (int i=0; i<o.getTriNum(); ++i) {
                    Tri t = o.triv[i];
                    t.in = 0;
                    t.init(this, t.getNorm());
                }
            }
            else {
                if (o.getOptimised()) {
                    Vec viewDir = Vec.add(o.offs, Matrix.mul(o.rot, o.getCentre()));
                    fastCull.setRenderObject(o, viewDir);
                }
                
                for (int i=0; i<o.getTriNum(); ++i) {
                    Tri t = o.triv[i];
                    // Can we cull this (backward facing?)
                    boolean culled = (o.getOptimised() && fastCull.isCulled(t.fastCullNum));

                    Vec d3 = null;
                    if (!culled) {
                        // Now need to do a more accurate test than the quick
                        // but dirty fastCull.isCulled()
                        d3 = t.getNorm();
                        if (Vec.dot(t.a.xformed, d3) <= 0) {
                            culled = true;
                        }
                    }

                    if (!culled && o != clippedRo) {
                        // Check for clipping
                        if (t.a.xformed.z < clipPlane ||
                            t.b.xformed.z < clipPlane ||
                            t.c.xformed.z < clipPlane) {
                            // Clips the near clipping plane (no far plane)
                            // Generate a new, clipped triangle and cull this one
                            t.getClipped(clipPlane, clippedRo);
                            culled = true;
                        }
                    }
                
                    if (culled) {
                        t.in = 7;
                    }
                    else {
                        // This triangle is visible
                        t.in = 0;
                        t.init(this, d3);
                    }
                }
            }

            for (int i=0; i<o.getVertNum(); ++i) {
                Vertex v = o.vertv[i];
                float wr = v.xformed.z;
                wr = ds / wr;
                v.xformed.set( v.xformed.x*wr + wo,
                               v.xformed.y*wr + ho,
                               wr );
            }
            numTriv += o.getTriNum();
        }
        numTriv *= 3;
        if (linesSize <= numTriv)
            alloc(numTriv, 0);
    }
    
    private void alloc(int nLines, int copy) {
        linesSize *= 2;
        if (linesSize < nLines)
            linesSize = nLines;
        Line2 linesInNew[] = new Line2[linesSize];
        Line2 linesOutNew[] = new Line2[linesSize];
        lines = new Line2[linesSize];
        linesRem = new Line2[linesSize];
        for (int i = 0; i<copy; ++i) {
            linesInNew[i] = linesIn[i];
            linesOutNew[i] = linesOut[i];
        }
        linesIn = linesInNew;
        linesOut = linesOutNew;
    }
    
    private void preCalc3(Vector renderObjects, float top, float bot) {
        // Calculate the triangles in the scene
        nLines = 0;
        for (int ob = 0; ob < renderObjects.size(); ++ob) {
            RenderObject o = (RenderObject)renderObjects.elementAt(ob);
            if (linesSize <= nLines + o.getTriNum())
                alloc(nLines + o.getTriNum(), nLines);
            for (int i=0; i<o.getTriNum(); ++i) {
                Tri t = o.triv[i];
                if (t.in != 7) { // Not culled
                    t.in = 0;
                    t.l[0].set(t.a.xformed, t.b.xformed);
                    t.l[1].set(t.b.xformed, t.c.xformed);
                    t.l[2].set(t.c.xformed, t.a.xformed);
                    t.rightLine = null;
                    for (int j=0; j<3; ++j) {
                        Line2 l = t.l[j];
                        if (l.p2.y > top && l.p1.y < bot) {
                            linesIn[nLines] = l;
                            linesOut[nLines] = l;
                            ++nLines;
                            l.flag &= (byte)15; // Clear CURRENT_X_CALC
                        }
                    }
                }
            }
        }
        if (renderObjects.elementAt(renderObjects.size()-1) == clippedRo) {
            renderObjects.removeElementAt(renderObjects.size()-1); // Remove the clip object
        }
        class Line2Yin implements SortIt {
            private Line2[] a;
            private int num;
            Line2Yin(Line2[] ar, int n) {
                a = ar;
                num = n;
            }
            public int compare(int l, int r) {
                if (a[l].p1.y < a[r].p1.y) return -1;
                else if (a[l].p1.y == a[r].p1.y) return 0;
                else return 1;
            }
            public void swap(int i, int j) {
                Line2 t = a[i]; a[i] = a[j]; a[j] = t;
            }
            public void insert(int i, int j) {
                Line2 tm = a[j];
                for (int k=j-1; k >= i; --k) a[k+1] = a[k];
                a[i] = tm;
            }
            public int numElem() {
                return num;
            }
        };
        class Line2Yout implements SortIt {
            private Line2[] a;
            private int num;
            Line2Yout(Line2[] ar, int n) {
                a = ar;
                num = n;
            }
            public int compare(int l, int r) {
                if (a[l].p2.y < a[r].p2.y) return -1;
                else if (a[l].p2.y == a[r].p2.y) return 0;
                return 1;
            }
            public void swap(int i, int j) {
                Line2 t = a[i]; a[i] = a[j]; a[j] = t;
            }
            public void insert(int i, int j) {
                Line2 tm = a[j];
                for (int k=j-1; k >= i; --k) a[k+1] = a[k];
                a[i] = tm;
            }
            public int numElem() {
                return num;
            }
        };
        
        // Put the in-out lists into order
        { Sorter s = new Sorter(new Line2Yin(linesIn, nLines)); s.sort(); }
        { Sorter s = new Sorter(new Line2Yout(linesOut, nLines)); s.sort(); }
    }

    private void prepareRender() {
        inY = 0;
        outY = 0;
        idx = 0;
        linesNum = 0;
    }

    private void processScanline(float y, Pixstore px, int width) {
        // First we update the lists of Line2 to add/ remove
        int linesAddNum = linesNum+1;
        int linesAddStart = linesAddNum;
        int linesRemStart = 0;
        int linesRemNum = 0;
        while (outY < nLines && linesOut[outY].p2.y < y) {
            Line2 l = linesOut[outY];
            ++outY;
            Tri t = l.t;
            t.in &= ~(l.flag&7);
            t.rightLine = null;
            if ((l.flag & l.CURRENT_X_CALC) == (byte)0)
                l.calcCurrentX(y);
            linesRem[linesRemNum] = l; ++linesRemNum;
        }
        while (inY < nLines && linesIn[inY].p1.y < y) {
            // Insert at right xpos!
            Line2 l = linesIn[inY];
            ++inY;
            Tri t = l.t;
            if ((l.flag & l.CURRENT_X_CALC) == (byte)0)
                l.calcCurrentX(y);
            lines[linesAddNum] = l; ++linesAddNum;
        }
        //UNCOMMENT TO CHECK
        //if ((linesAddNum-linesAddStart - linesRemNum)%2 != 0) {
        //    System.out.println("Very Odd! "+(linesAddNum-linesAddStart) + " " + linesRemNum);
        //    lines[-1].currentX=0;
        //}
        
        if (linesAddNum > linesAddStart || linesRemNum > 0) {
            // Sort the add/ rem lists
            { Sorter s = new Sorter(new Line2X(linesRem, linesRemNum, 0)); s.sort(); }
            { Sorter s = new Sorter(new Line2X(lines, linesAddNum-linesAddStart, linesAddStart)); s.sort(); }
        
            {
                // Update the lines array in a single pass, adding and removing alements as necessary
                int offs = 0;
                rb.reset();
                for (int i=0; i<linesNum; ++i) {
                    Line2 cl;
                    if (offs == 0) {
                        // Binary search for next point-of-interest
                        Line2 nx = null;
                        if (linesRemStart < linesRemNum) {
                            nx = linesRem[linesRemStart];
                            if (linesAddStart < linesAddNum && (Line2X.compare(lines[linesAddStart], nx) < 0))
                                nx = lines[linesAddStart];
                        }
                        else if (linesAddStart < linesAddNum)
                            nx = lines[linesAddStart];
                        if (nx == null) break; // Done
                        int bot = i;
                        int top = linesNum-1;
                        while (top > bot+1) {
                            int mid = (top+bot)>>1;
                            if (Line2X.compare(nx, lines[mid]) <= 0)
                                top = mid;
                            else
                                bot = mid;
                        }
                        if (top > bot && Line2X.compare(nx, lines[top]) <= 0) {
                            top = bot;
                        }
                        if (Line2X.compare(nx, lines[top]) > 0) {
                            ++top;
                            if (top >= linesNum) break;
                        }
                        i = top;
                    }
                    if (offs >= 0)
                        cl = lines[ i+offs ];
                    else if (i-offs == linesNum) {
                        cl = rb.pop();
                        ++offs;
                    }
                    else
                        cl = rb.popAndPush(lines[ i ]);
                
                    // Any for removal
                    {
                        boolean newCl = true;
                        while (newCl) {
                            newCl = false;
                            int lr = linesRemStart;
                            while (lr < linesRemNum && Line2X.compare(linesRem[lr], cl) <= 0) {
                                if (linesRem[lr] == cl) {
                                    //System.out.println("Removing " + cl.currentX);
                                    newCl = true;
                                    --linesNum; 
                                    ++offs;
                                    if (offs > 0) {
                                        cl = lines[ i+offs ];
                                    }
                                    else {
                                        cl = rb.pop();
                                    }
                                    while (lr > linesRemStart) linesRem[lr] = linesRem[--lr];
                                    linesRemStart++;
                                }
                                ++lr;
                            }
                        }
                    }
                    while (linesAddStart < linesAddNum && Line2X.compare(lines[linesAddStart], cl) < 0) {
                        Line2 l =  lines[linesAddStart];
                        ++linesAddStart;
                        boolean removed = false;
                        {
                            int lr = linesRemStart;
                            while (lr < linesRemNum && Line2X.compare(linesRem[lr], l) <= 0) {
                                if (linesRem[lr] == l) {
                                    //System.out.println("Skipping " + l.currentX);
                                    while (lr > linesRemStart) linesRem[lr] = linesRem[--lr];
                                    linesRemStart++;
                                    removed = true;
                                }
                                ++lr;
                            }
                        }
                        if (!removed) {
                            //System.out.println("Adding " + l.currentX);
                            if (offs <= 0) {
                                rb.pushBot(cl);
                            }
                            cl = l;
                            
                            --offs; ++linesNum;
                            // We need to do some action...
                            l.t.in |= (l.flag&(byte)7);
                            
                            if (canMapLu[l.t.in]) l.t.map(this, l, y);
                            break;
                        }
                    }
                    lines[i] = cl;
                }

                
                while (linesAddStart < linesAddNum) {
                    Line2 l =  lines[linesAddStart];
                    //System.out.println("Extra Adding " + l.currentX);
                    ++linesAddStart;
                    boolean removed = false;
                    {
                        int lr = linesRemStart;
                        while (lr < linesRemNum && Line2X.compare(linesRem[lr], l) <= 0) {
                            if (linesRem[lr] == l) {
                                //System.out.println("Extra Skipping " + l.currentX);
                                while (lr > linesRemStart) linesRem[lr] = linesRem[--lr];
                                linesRemStart++;
                                removed = true;
                            }
                            ++lr;
                        }
                    }
                    if (!removed) {
                        lines[linesNum] = l;
                        ++linesNum;
                        // We need to do some action...
                        l.t.in |= (l.flag&(byte)7);
                        if (canMapLu[l.t.in]) l.t.map(this, l, y);
                    }
                }
            }
            // UNCOMMENT FOR CHECKING
            //for (int i=0; i<linesNum; ++i) {
            //    Line2 l =  lines[i];
            //    System.out.println("** " + l.currentX + " " + ((int)l.t.in));
            //}
            //if (linesRemStart != linesRemNum) {
            //    System.out.println("Rem "+linesRemStart+" "+ linesRemNum);
            //    for (int i=linesRemStart; i<linesRemNum; ++i) {
            //        Line2 l =  linesRem[i];
            //        System.out.println(l.currentX);
            //    }
            //    lines[-1].currentX=0;
            //}
            //if (linesAddStart != linesAddNum) {
            //    System.out.println("Add "+linesAddStart +" "+ linesAddNum);
            //    lines[-1].currentX=0;
            //}
            //if ((linesNum%2) != 0) {
            //    System.out.println("Odd!");
            //    lines[-1].currentX=0;
            //}
            //for (int i=1; i<linesNum; ++i) {
            //    if (Line2X.compare( lines[i-1], lines[i] ) > 0) {
            //        System.out.println(i);
            //        lines[-1].currentX=0;
            //    }
            //}
        }
        
        // Draw this scan line
        tris.removeAllElements();
        int cX=0;
        for(int x=0; x<width;) {
            // Look for Line2 entries
            while (cX < linesNum && lines[cX].currentX < x) {
                Line2 l = lines[cX];
                ++cX;
                Tri t = l.t;
                if (t.rightLine != null) {
                    if (!tris.removeElement(t)) {
                        t.prep(l, x);
                        // Depth filter
                        class TriD implements Lessthan {
                            public boolean lessthan(Object o1, Object o2) {
                                float x1 = ((Tri)o1).depth;
                                float x2 = ((Tri)o2).depth;
                                return (x1 > x2);
                            }
                        };
                        int ind = Sorter.binSearch(tris, t, new TriD());
                        tris.insertElementAt(t, ind);
                    }
                }
            }

            int nx = width-1;
            if (cX < linesNum) nx = (int)lines[cX].currentX;
            if (nx >= width) nx = width-1;

            int mi = idx + nx - x;
            switch (tris.size()) {
            case 0:
                if (background == null) {
                    for(;idx<=mi; ++idx) {
                        px.pix[idx] = 0;
                    }
                    x = nx+1;
                }
                else if (antiAlias) {
                    for(;idx<=mi; ++idx) {
                        px.pix[idx] = background.pix[x/aascale + background.getWidth()*((int)y/aascale)];
                        ++x;
                    }
                }
                else {
                    for(;idx<=mi; ++idx) {
                        px.pix[idx] = background.pix[idx];
                    }
                    x = nx+1;
                }
                break;
                    
            case 1:
                {
                    Tri t = (Tri)tris.elementAt(0);
                    float updt = mi - idx + 1;
                    t.draw(this, px, mi, x);
                    t.depth += t.deltaDepth * updt;
                    x = nx+1;
                }
                break;
                    
            default:
                for(;idx<=mi;) {
                    // Look for the next depth change
                    Tri clo = (Tri)tris.elementAt(0);
                    int nxt = mi;
                    int old = idx;
                    if (intersect) {
                        for (int i=1; i<tris.size(); ++i) {
                            Tri t = (Tri)tris.elementAt(i);
                            float ddDiff = clo.deltaDepth-t.deltaDepth;
                            if (ddDiff > 0.00001f || ddDiff < -0.00001f) {
                                int n = (int)((t.depth-clo.depth)/ddDiff);
                                n += idx;
                                if (n<nxt && n>=idx-2) {
                                    if (n<idx) {
                                        nxt = idx;
                                        break;
                                    }
                                    else nxt = n;
                                }
                            }
                            else {
                                float diff = clo.depth-t.depth;
                                if (diff < 0.01f && diff > -0.01f) {
                                    nxt = idx;
                                    break;
                                }
                            }
                        }
                    }

                    clo.draw(this, px, nxt, x);
                    x += nxt-old+1;
                    
                    // Update the other texmap pointers, and all depths
                    float updt = nxt - old + 1;
                    for (int i=0; i<tris.size(); ++i) {
                        Tri t = (Tri)tris.elementAt(i);
                        t.depth += t.deltaDepth * updt;
                    }

                    // Update the depths
                    for (int i=1; i<tris.size(); ++i) {
                        Tri t = (Tri)tris.elementAt(i);
                        if (t.depth > clo.depth) {
                            tris.setElementAt(t, 0);
                            tris.setElementAt(clo, i);
                            clo = t;
                        }
                    }
                }
            }
        }
        
        // Prepare for the next line
        for (int i=0;i<linesNum;++i) {
            Line2 l = lines[i];
            if (l == l.t.rightLine) {
                l.t.nextLine();
            }
            l.currentX += l.deltaX;
            l.currentZ += l.deltaZ;
        }
        Line2X l2x = new Line2X(lines, linesNum, 0);
        Sorter s = new Sorter(l2x); s.insertionSort();
    }

    private void draw(Vector renderObjects, Pixstore px, int top, int bot, int width) {
        // For each scanline
        idx += top*px.getWidth();
        if (!antiAlias) {
            for (int y=top; y<=bot; ++y) {
                processScanline(y, px, width);
                idx += px.getWidth() - width;
            }
        }
        else {
            Pixstore imbuf = new Pixstore(px.getWidth()*aascale, aascale);
            for (int y=top; y<=bot; ++y) {
                aaScanline(y, px, imbuf);
            }
        }
    }
    
    private void splitDraw(Vector renderObjects, Pixstore px) {
        // stereo 3d version
        // Disclaimer - This is very bad for you,
        // do not view this version. It can cause eye strain, headaches, and
        // other bad symptoms.
        // If you decide to ignore this disclaimer then please at least do
        // not view for long periods.
        
        int w2 = (px.getWidth() - gap)>>1;  
        int w2g = w2+gap;

        // DRAW LEFT IMAGE
        final float offs = .2f;
        final float ang = .02f;
        preCalc1(renderObjects); // Tris
        for (int i=0; i<renderObjects.size(); ++i) {
            RenderObject ob = (RenderObject)renderObjects.elementAt(i);
            for (int j=0; j<ob.getVertNum(); ++j) {
                Vertex v = ob.vertv[j];
                v.xformed.x -= offs;
            }
        }
        preCalc2(renderObjects, w2, px.getHeight(), (int)((w2>>1)*(1+poffs))); // Vertices
        preCalc3(renderObjects, 0, px.getHeight()-1); // Tris
        prepareRender();
        draw(renderObjects, px, 0, px.getHeight()-1, w2);
        // DRAW RIGHT IMAGE
        preCalc1(renderObjects); // Tris
        for (int i=0; i<renderObjects.size(); ++i) {
            RenderObject ob = (RenderObject)renderObjects.elementAt(i);
            for (int j=0; j<ob.getVertNum(); ++j) {
                Vertex v = ob.vertv[j];
                v.xformed.x += offs;
            }
        }
        preCalc2(renderObjects, w2, px.getHeight(), (int)((w2>>1)*(1-poffs))); // Vertices
        preCalc3(renderObjects, 0, px.getHeight()-1); // Tris
        prepareRender();
        idx += w2g;
        draw(renderObjects, px, 0, px.getHeight()-1, w2);
    }
    
    private void aaScanline(float y, Pixstore px, Pixstore imageBuf) {
        {
            int indTmp = idx;
            idx = 0;
            for (int y2=0;y2<aascale;++y2) {
                processScanline(y*aascale+y2, imageBuf, imageBuf.getWidth());
            }
            idx = indTmp;
        }
        int ind2 = 0;
        int width = px.getWidth();
        int width2 = width*aascale;
        int aa2 = aascale*aascale;
        for (int x = 0; x<width; ++x) {
            int rb = 0; int g = 0;
            for (int y1=0;y1<aascale;++y1) {
                for (int x1=0;x1<aascale;++x1) {
                    int c = imageBuf.pix[ind2];
                    rb += c&0xff00ff;
                    g += c&0xff00;
                    ++ind2;
                }
                ind2 += width2-aascale;
            }
            ind2 -= (width2-1)*aascale;
            int r = rb & 0xffff0000;
            rb &= 0xffff;
            r /= aa2;
            rb /= aa2;
            g /= aa2;
            px.pix[idx] = (r&0xff0000) | (g&0xff00) | (rb&0xff00ff);
            ++idx;
        }
    }

    private void drawSplash(tinyptc owner, Pixstore px) {
        Pixstore splash = new Pixstore(owner, "q3dSplash.jpg", null);
        int wd = splash.getWidth();
        int hi = splash.getHeight();
        if (wd > px.getWidth()) wd = px.getWidth();
        if (hi > px.getHeight()) hi = px.getHeight();
        int y;
        for (y=0; y<hi; ++y) {
            int x;
            for (x=0; x<wd; ++x) {
                px.pix[x+y*px.getWidth()] = splash.pix[x+y*splash.getWidth()];
            }
            for (; x<px.getWidth(); ++x) {
                px.pix[x+y*px.getWidth()] = 0xffffff;
            }
        }
        for (; y<px.getHeight(); ++y) {
            for (int x=0; x<px.getWidth(); ++x) {
                px.pix[x+y*px.getWidth()] = 0xffffff;
            }
        }
    }
    
    // Non-user variables
    
    Vec lightDir; // Direction of light
    Vec lightDirP1;
    Vec lightDirP2;

    private static final boolean canMapLu[] = { false, false, false, true, false, true, true };
    private FastCull fastCull = new FastCull();
    int amb = 40;
}
