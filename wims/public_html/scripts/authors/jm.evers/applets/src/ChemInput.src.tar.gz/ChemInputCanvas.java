import java.awt.*;
import java.awt.event.*;
import java.util.Vector;

class ChemInputCanvas extends Canvas implements ActionListener, MouseListener, MouseMotionListener,KeyListener{

    ChemInputCanvas(){
        setBackground(ChemInputApplet.bgcolor3);
        addMouseListener(this);
	addKeyListener(this); 
        addMouseMotionListener(this);
    }

    public synchronized void paint(Graphics g){
	int wmax=getSize().width;
	int hmax = getSize().height;
	g.clearRect(0,0,wmax,hmax);
	f = new Font("TimesRoman",Font.BOLD,newsize);
	fm = g.getFontMetrics(f);
	g.setFont(f);
	int sup_sub = 0;
	int h_mul = 1;
	int i,j = 0;
	boolean test;
	central_y = 2*fm.getHeight();
	int charWidth = fm.charWidth('W');
	int maxChars = wmax / charWidth;
	g.setColor(bgcolor2);
	offset=offset*2*fm.getHeight();

	if(state() > 0) g.fillRect(0,central_y-fm.getHeight()+offset,wmax,fm.getHeight()/2);
	else
	if(state() <0 ) g.fillRect(0,central_y+offset,wmax,fm.getHeight()/2);
	else
	g.fillRect(0,central_y-fm.getHeight()/2+offset,wmax,fm.getHeight()/2);	
	
	g.setFont(f);
	g.setColor(pencolor);
	StringBuffer t = new StringBuffer(100);
	t.insert(0,s1);//copy s1 to t
	String s6 = t.toString();//convert t back to String s6
	offset = 0;
	increment = 0;
	for (i=0;i<s6.length();i++){
	    if(increment > wmax ){
		increment = 0;
		offset++;
		central_y = central_y+2*fm.getHeight();
	    }
	    if (s6.indexOf("}") != -1){
		if (s6.indexOf("^{",i) == i || s6.indexOf("_{",i)==i){//}}
		    if (s6.indexOf("^{",i) == i ) sup_sub = 1;//}
		    if (s6.indexOf("_{",i) == i ) sup_sub = -1;//}
		    i = i +2;
		    j = fm.getHeight()*h_mul/2;//{
		    test = s6.substring(i,i+1).equals("}"); 	
		    while ( !test){
			g.drawString(s6.substring(i,i+1),4+increment,central_y-j*sup_sub);
			increment +=  fm.stringWidth(s6.substring(i,i+1));//width of font???
			i++;//{
			test = s6.substring(i,i+1).equals("}"); 	
		    }
		}
		else
		{
		    sup_sub = 0;
		    j = 0;
		    g.drawString(s6.substring(i,i+1),4+increment,central_y+j*sup_sub);
		    increment += fm.stringWidth(s6.substring(i,i+1));//width of font???
		}
	    }
	    else 
	    {
		increment += fm.stringWidth(s6);//width of font???
		g.drawString(s6,4,central_y);
		break;
	    }
	}
    }
    
    public void ModifySuper(int flag){
	setsuper(flag);
    }
    
    public void setsuper(int flag){
	super_flag = state()+flag;
	if(super_flag > 0 ) super_flag = 1;
	else
	if(super_flag < 0 ) super_flag = -1;
        else super_flag = 0;
	repaint();
    }
  
    public int state() {
	if ( super_flag >0) return (1);
	else if ( super_flag <0) return (-1);
	else return (0);
    }

    public void modify(String mod){
	s1=s1+mod;
	update(s1);
    }
    
    public void update(String args) {
    	s1=replace(args,"}^{","");
	s1=replace(args,"}_{","");
	repaint();
    }

    public void clear() {
	if(ChemInputApplet.applettext.length() != 0){
	    s1 = ChemInputApplet.applettext;
	}
	else
	{
	    s1 = "";
	}
	// state() -> 0
	if(state() > 0 ){ setsuper(-1);}
	else
	if(state() < 0 ){ setsuper(1);}

	repaint();
    }
    
    public void SwitchFont(int s){
	newsize=newsize + s;
	repaint();
    }
    
    public String replace(String source, String pattern, String replace){
        if (source!=null){
	    final int len = pattern.length();
	    StringBuffer sb = new StringBuffer();
	    int found = -1;
	    int start = 0;
	    while( (found = source.indexOf(pattern, start) ) != -1) {
		sb.append(source.substring(start, found));
		sb.append(replace);
		start = found + len;
	    }
	    sb.append(source.substring(start));
	    return sb.toString();
        }
        else return "";
    }

    public void update(Graphics g){
        paint(g);
    }

    public void actionPerformed(ActionEvent evt) {
        String command = evt.getActionCommand();
	if (command.equals(ChemInputApplet.Clear)){
	    StringBuffer cd_str = new StringBuffer(100);
	    clear();
	    cd_str.append(ChemInputApplet.applettext);
	    s1=cd_str.toString();
	    update(s1);
            return;
	}
	else
	if(command.equals(ChemInputApplet.Arrow1)){
	    StringBuffer cd_str = new StringBuffer(100);
	    cd_str.append(s1+" "+ChemInputApplet.Arrow1+" ");
	    s1 = cd_str.toString();
	    update(s1);
            return;
	}
	else
	if(command.equals(ChemInputApplet.Arrow2)){
	    StringBuffer cd_str = new StringBuffer(100);
	    cd_str.append(s1+" "+ChemInputApplet.Arrow2+" ");
	    s1 = cd_str.toString();
	    update(s1);
            return;
	}
	else
	if (command.equals(ChemInputApplet.More)){
	    int fontsize=ChemInputApplet.fontsize+4;
	    if(fontsize>60){fontsize=60;}
	    SwitchFont(fontsize);
            return;
	}
	else
	if (command.equals(ChemInputApplet.Less)){
	    int fontsize=ChemInputApplet.fontsize-4;
	    if(fontsize<10){fontsize=10;}
	    SwitchFont(fontsize);
            return;
	}
	else
	if (command.equals(ChemInputApplet.Down)){
	    setsuper(-1);
            return;
	}
	else
	if (command.equals(ChemInputApplet.Up)){
	    setsuper(1);
            return;
	}
	else
	if(command.equals(ChemInputApplet.Solid)){
	    StringBuffer cd_str = new StringBuffer(100);
	    cd_str.append(s1+"_{(s)} ");
	    s1 = cd_str.toString();
	    update(s1);
            return;
	}
	else
	if(command.equals(ChemInputApplet.Liquid)){
	    StringBuffer cd_str = new StringBuffer(100);
	    cd_str.append(s1+"_{(l)} ");
	    s1 = cd_str.toString();
	    update(s1);
            return;
	}
	else
	if(command.equals(ChemInputApplet.Gas)){
	    StringBuffer cd_str = new StringBuffer(100);
	    cd_str.append(s1+"_{(g)} ");
	    s1 = cd_str.toString();
	    update(s1);
            return;
	}
	else
	if(command.equals(ChemInputApplet.Precip)){
	    StringBuffer cd_str = new StringBuffer(100);
	    cd_str.append(s1+"_{\u2193} ");
	    s1 = cd_str.toString();
	    update(s1);
            return;
	}
    }

    public synchronized void mousePressed(MouseEvent evt){
        int x = evt.getX();
        int y = evt.getY();
	if(y<(central_y + offset - 2*fm.getHeight())){
	    setsuper(1);
	}
	else
	{
	    if(y>(central_y + offset + 2*fm.getHeight())){
		setsuper(-1);
	    }
	    else 
	    {
		setsuper(0);
	    }
	}
    }

    public synchronized void mouseDragged(MouseEvent evt){}

    public synchronized void mouseReleased(MouseEvent evt){}

    public void mouseEntered(MouseEvent mouseevent){}

    public void mouseExited(MouseEvent mouseevent){}

    public void mouseMoved(MouseEvent mouseevent){}

    public void mouseClicked(MouseEvent mouseevent){}
    
    public void keyPressed(KeyEvent e){
	ProcessKey(e.getKeyCode());
    }
    
    public void keyTyped(KeyEvent e ) {
    }                                                                                                                                        
                                                                                                                                           
    public void keyReleased(KeyEvent e){
    }     

    public int[] ForbiddenKeys={33,34,35,36,39,42,44,47,58,59,60,61,62,64,92,96};

    public boolean ProcessKey(int key){
	for(int i=0;i<ForbiddenKeys.length;i++){
	    if(key == ForbiddenKeys[i]){return false;}
	}
	if (key == 37 || key == 8 || key == 127){
	    StringBuffer new_str = new StringBuffer(100);
	    new_str.append(s1);
	    int len = new_str.length();//{
	    if(new_str.charAt(len-1) == '}'){
		new_str.setLength(len-1-3);
	    }
	    else 
	    {
		new_str.setLength(len-1);
	    }
	    s1 = new_str.toString();
	    update(s1);return true;
	}
	else
	{
	    if (key == 54 || key == 38 || key == 94 ){setsuper(1);return true;}
	    else
	    if(key == 45 || key == 40 || key == 95){setsuper(-1);return true;}
	    else
	    if( key >= 32 && key <= 122  ){
		StringBuffer new_str = new StringBuffer(100);
		StringBuffer cd = new StringBuffer(1);
		char key_char = (char) key;
		cd.append(key_char);
	    	new_str.append(s1);
		if(state() == 1){new_str.append("^{"+cd+"}");}
		else
		if(state() == -1){new_str.append("_{"+cd+"}");}
		else{ new_str.append(cd);}
		
		s1 = new_str.toString();
		update(s1);return true;
	    }
	    else
	    return false;
	}    
    }

    public static String ReadApplet(){
	return s1.toString();
    }


    public int newsize=ChemInputApplet.fontsize;
    public static String s1=ChemInputApplet.applettext;
    public static int central_y;
    public int increment=0;
    public int offset=0;
    public StringBuffer c1;
    public static int super_flag=0;
    public static FontMetrics fm;
    public static Font f;
    Color pencolor = ChemInputApplet.pencolor;
    Color bgcolor2 = ChemInputApplet.bgcolor2;
}




