#!/bin/sh

#find ./build -type f -name "*.class" -exec rm "{}" ";" 
rm Plot.jar*
ant -v jar -l log.txt
rm -rf ~/.java
if [ -e "Plot.jar" ] ; then
    mozilla file://`pwd`/1.html
    tar cvzf Plot.src.tar.gz ./ptolemy build.xml make.sh 1.html ./examples
    #appletviewer ./1.html
else
    echo "build failed"
    tail -f -n 30 log.txt
fi

