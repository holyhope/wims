//  Copyright (C) 2004 Philip Proudman
//
//  This file is part of Quick3dApplet
//
//  Quick3dApplet is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  Quick3dApplet is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with Quick3dApplet in the file called "COPYING" in the top directory;
//  if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


package Quick3dApplet;
import java.awt.image.PixelGrabber;
import java.applet.Applet;
import java.awt.*;
import java.io.*;

final public class Pixstore
{
    public int[] pix;
    private int width, height;
    
    public int getMax() {
        return width*height;
    }
    
    public int getWidth() {
        return width;
    }
    public int getHeight() {
        return height;
    }

    public Pixstore(tinyptc owner, String filename, Pixstore waitMsg) {
        java.awt.Image image = owner.getImage(owner.getDocumentBase(), filename);
        MediaTracker tracker = new MediaTracker(owner);
        tracker.addImage(image, 0);
        if (waitMsg != null) {
            try {
                while (!tracker.checkID(0, true)) {
                    owner.update(waitMsg.pix);
                    Thread.currentThread().sleep(40);
                }
            }
            catch (java.lang.InterruptedException r) {}
        }
        else {
            try { tracker.waitForID(0); } 
            catch (InterruptedException e) {}
        }
        if (tracker.statusID(0, true) != MediaTracker.COMPLETE) {
            System.err.println("*** Can't find image "+filename);
            System.out.println("*** You may need to copy "+filename+" into the base directory");
        }
        width  = image.getWidth(null);
        height = image.getHeight(null);
        pix = new int[width*height];
        PixelGrabber pg = new PixelGrabber(image, 0, 0, width, height, pix, 0, width);
        try {
            pg.grabPixels();
        }
        catch (InterruptedException e) {}
    }
    
    public Pixstore(int w, int h) {
        width  = w;
        height = h;
        pix = new int[w*h];
    }
}
