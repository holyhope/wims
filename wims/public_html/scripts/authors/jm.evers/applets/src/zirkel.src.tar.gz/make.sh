#!/bin/sh
# copy manually the *.properties files to the build-tree...if changed/edited
#

find ./build -type f -name "*.class" -exec rm "{}" ";" 
rm build/zirkel.jar*
ant -v jar -l log.txt

