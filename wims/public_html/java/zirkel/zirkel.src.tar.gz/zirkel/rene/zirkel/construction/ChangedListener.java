/*
 * Created on 14.01.2006
 *
 */
package rene.zirkel.construction;

public interface ChangedListener 
{	public void notifyChanged ();
}
