package SharpTools;

public abstract class SharpToolsProperties{}
