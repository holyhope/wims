//  Copyright (C) 2004 Philip Proudman
//
//  This file is part of Quick3dApplet
//
//  Quick3dApplet is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  Quick3dApplet is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with Quick3dApplet in the file called "COPYING" in the top directory;
//  if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


package Quick3dApplet;
import java.util.*;

public class RenderObject {
    public Vertex vertv[];
    public VertexNorm vertNorm[];
    public Tri triv[];
    public boolean optimise = true; // Set false if you dynamically change Vertex or VertexNorm in this RenderObject

    public final boolean getOptimised() {
        return optimised;
    }

    public final Vec getCentre() {
        return new Vec(centre);
    }

    public final float getRecipRadiousSq() {
        return recipRadiousSq;
    }
    
    public final float getRadious() {
        return radious;
    }
    
    public final void addVert(Vertex v) {
        if (vertvNum == vertvAlloc) {
            int tmp = (vertvAlloc == 0) ? 10 : vertvAlloc*2;
            alloc(tmp, 0, 0);
        }
        
        vertv[vertvNum] = v;
        ++vertvNum;
    }

    class VertNormSorter implements Lessthan {
        private Vector n;
        
        VertNormSorter(Vector norms) {
            n = norms;
        }
        
        public boolean lessthan(Object lhs, Object rhs) {
            float lg = ((VertexNorm)lhs).norm.x;
            float rg = ((VertexNorm)rhs).norm.x;
            return (lg < rg);
        }
    }
    
    public final void addVertNorm(VertexNorm v) {
        if (vertNormNum == vertNormAlloc) {
            int tmp = (vertNormAlloc == 0) ? 10 : vertNormAlloc*2;
            alloc(0, tmp, 0);
        }

        if (optimise) {
            if (vertNormSorted == null) vertNormSorted = new Vector();
            
            // Are there any similar ones?
            boolean sim = false;
            int ind = Sorter.binSearch(vertNormSorted, v, new VertNormSorter(vertNormSorted));
            for (int i=ind; i<vertNormSorted.size(); ++i) {
                VertexNorm comp = (VertexNorm)vertNormSorted.elementAt(i);
                Vec t = Vec.sub(comp.norm, v.norm);
                final float s = 0.04f;
                if (t.x > s) break;
                if (t.y>-s && t.y<s &&
                    t.z>-s && t.z<s) {
                    v = comp;
                    sim = true;
                    break;
                }
            }
            if (!sim) {
                for (int i=ind-1; i>=0; --i) {
                    VertexNorm comp = (VertexNorm)vertNormSorted.elementAt(i);
                    Vec t = Vec.sub(comp.norm, v.norm);
                    final float s = 0.04f;
                    if (t.x < -s) break;
                    if (t.y>-s && t.y<s &&
                        t.z>-s && t.z<s) {
                        v = comp;
                        sim = true;
                        break;
                    }
                }
            }
            if (!sim) {
                vertNormSorted.insertElementAt(v, ind);
            }

        }
        vertNorm[vertNormNum] = v;
        ++vertNormNum;
    }

    public final void addTri(Tri v) {
        if (trivNum == trivAlloc) {
            int tmp = (trivAlloc == 0) ? 10 : trivAlloc*2;
            alloc(0 ,0, tmp);
        }
        triv[trivNum] = v;
        ++trivNum;
    }

    // You don't have to call alloc, but if you know how big
    // your object is in advance, then this will make your
    // code less resource hungry
    // NB - will not reduce memory already allocated, therefore
    // to increase only one component you can call alloc(100,0,0)
    // which will give you 100 vertices without affecting existing
    // triangles/ normals.
    public final void alloc(int nVert, int nVertNorm, int nTri) {
        if (nVert > vertvAlloc) {
            vertvAlloc = nVert;
            Vertex vertvNew[] = new Vertex[vertvAlloc];
            for (int i=0; i<vertvNum; ++i) vertvNew[i] = vertv[i];
            vertv = vertvNew;
        }
        if (nVertNorm > vertNormAlloc) {
            vertNormAlloc = nVertNorm;
            VertexNorm vertNormNew[] = new VertexNorm[vertNormAlloc];
            for (int i=0; i<vertNormNum; ++i) vertNormNew[i] = vertNorm[i];
            vertNorm = vertNormNew;
        }
        if (nTri > trivAlloc) {
            trivAlloc = nTri;
            Tri trivNew[] = new Tri[trivAlloc];
            for (int i=0; i<trivNum; ++i) trivNew[i] = triv[i];
            triv = trivNew;
        }
    }

    public final int getVertNum() { return vertvNum; }
    public final int getVertNormNum() { return vertNormNum; }
    public final int getTriNum() { return trivNum; }
    
    public final void clear() {
        vertvNum = 0;
        vertNormNum = 0;
        trivNum = 0;
        optimised = false;
    }

    public final void offsetAll(Vec offs, float mult) {
        optimised = false;
        for (int i=0; i<getVertNum(); ++i) {
            Vertex v = vertv[i];
            v.pos = Vec.mul(Vec.add(offs, v.pos), mult);
        }
    }
    
    public final void useRenderObject(RenderObject ro) {
        // Put all vertices/ triangles from ro into this
        // The current offset and rotation of ro are used
        // NB.. you must then discard ro, since this is not a deep copy
        
        alloc(ro.getVertNum() + getVertNum(),
              ro.getVertNormNum() + getVertNormNum(),
              ro.getTriNum() + getTriNum());
        
        for (int i=0; i<ro.getVertNum(); ++i) {
            Vertex v = ro.vertv[i];
            v.reset(ro.rot, ro.offs);
            v.pos = v.xformed;
            addVert(v);
        }        
        for (int i=0; i<ro.getVertNormNum(); ++i) {
            VertexNorm vn = ro.vertNorm[i];
            vn.reset(ro.rot);
            vn.norm = vn.normXformed;
            addVertNorm(vn);
        }        
        for (int i=0; i<ro.getTriNum(); ++i) {
            addTri(ro.triv[i]);
        }
    }
    
    // We only need to do this once. Users call Render.optimise to access.
    final void doOptimise(FastCull fc) {
        if (optimise) {
            optimised = true;
            // Remove any duplicate VertNorms
            if (vertNormSorted != null) {
                vertNormNum = vertNormSorted.size();
                for (int i=0; i<vertNormNum; ++i) {
                    vertNorm[i] = (VertexNorm)vertNormSorted.elementAt(i);
                }
                vertNormSorted = null;
            }
            // Fastcull
            for (int i=0; i<trivNum; ++i) {
                Tri t = triv[i];
                Vec d3 = t.getOrigNorm();
                d3.makeUnitVec();
                t.fastCullNum = (byte)fc.getTriNumber(d3);
            }
            // Centre/ radious (Quick and dirty, not exact)
            if (vertvNum > 1) {
                Vec min = new Vec(vertv[0].pos);
                Vec max = new Vec(vertv[0].pos);
                for (int i=0; i<vertvNum; ++i) {
                    Vec t = vertv[i].pos;
                    if (t.x > max.x) max.x = t.x; else if (t.x < min.x) min.x = t.x;
                    if (t.y > max.y) max.y = t.y; else if (t.y < min.y) min.y = t.y;
                    if (t.z > max.z) max.z = t.z; else if (t.z < min.z) min.z = t.z;
                }
                centre = Vec.mul( Vec.add(max, min), 0.5f );
                max = Vec.sub(max, centre);
                radious = max.x;
                if (max.y>radious) radious = max.y;
                if (max.z>radious) radious = max.z;
            }
            else {
                if (vertvNum > 0)
                    centre = vertv[0].pos;
                else
                    centre=new Vec(0,0,0);
                radious = .01f;
            }
            recipRadiousSq = 1/(radious*radious);
        }
    }

    // Position/ rotation...
    public Matrix rot = new Matrix();
    public Vec offs = new Vec();

    // Vertices
    private int vertvNum = 0;
    private int vertNormNum = 0;
    private int trivNum = 0;
    private int vertvAlloc = 0;
    private int vertNormAlloc = 0;
    private int trivAlloc = 0;
    private boolean optimised = false;
    // These are set if "optimised" = true ...
    private Vec centre;
    private float radious;
    private float recipRadiousSq;     // RecipRadious = 1/radious

    private Vector vertNormSorted;
}
