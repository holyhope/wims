package rene.util.sort;

public interface SortObject
{	public int compare (SortObject o);
}
