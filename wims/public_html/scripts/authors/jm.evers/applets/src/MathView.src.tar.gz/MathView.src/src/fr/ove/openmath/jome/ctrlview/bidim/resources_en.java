package fr.ove.openmath.jome.ctrlview.bidim;

public abstract class resources_en{
}
