package rene.gui;

public interface IconBarListener
{	void iconPressed (String name);
}