package rene.gui;

public interface CloseListener
{   public void closed ();
}