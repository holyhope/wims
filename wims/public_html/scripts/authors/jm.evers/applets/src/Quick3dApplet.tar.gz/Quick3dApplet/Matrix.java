//  Copyright (C) 2004 Philip Proudman
//
//  This file is part of Quick3dApplet
//
//  Quick3dApplet is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  Quick3dApplet is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with Quick3dApplet in the file called "COPYING" in the top directory;
//  if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

package Quick3dApplet;

public final class Matrix
{
    private Vec a = new Vec();
    private Vec b = new Vec();
    private Vec c = new Vec();

    public Matrix() {}

    public void set(Matrix m) {
        a.x=m.a.x; b.x=m.b.x; c.x=m.c.x;
        a.y=m.a.y; b.y=m.b.y; c.y=m.c.y;
        a.z=m.a.z; b.z=m.b.z; c.z=m.c.z;
    }

    public void setIdentity() {
        a.x=1; b.x=0; c.x=0;
        a.y=0; b.y=1; c.y=0;
        a.z=0; b.z=0; c.z=1;        
    }
    
    public void set(float ax, float bx, float cx,
                    float ay, float by, float cy,
                    float az, float bz, float cz) {
        a.set(ax,ay,az); b.set(bx,by,bz); c.set(cx,cy,cz);
    }

    public void setRotationZyzProgressive(float zRot1, float yRot, float zRot2) {
        set( (float)(Math.cos(zRot1)*Math.cos(yRot)*Math.cos(zRot2)-Math.sin(zRot1)*Math.sin(zRot2)), (float)(-Math.sin(zRot1)*Math.cos(yRot)*Math.cos(zRot2)-Math.cos(zRot1)*Math.sin(zRot2)), (float)(Math.sin(yRot)*Math.cos(zRot2)), 
             (float)(Math.cos(zRot1)*Math.cos(yRot)*Math.sin(zRot2)+Math.sin(zRot1)*Math.cos(zRot2)), (float)(-Math.sin(zRot1)*Math.cos(yRot)*Math.sin(zRot2)+Math.cos(zRot1)*Math.cos(zRot2)), (float)(Math.sin(yRot)*Math.sin(zRot2)),
             (float)(-Math.cos(zRot1)*Math.sin(yRot)), (float)(Math.sin(zRot1)*Math.sin(yRot)), (float)(Math.cos(yRot)));
    }

    public void setRotationXyzProgressive(float xRot, float yRot, float zRot) {
        set( (float)(Math.cos(yRot)*Math.cos(zRot)), (float)(Math.cos(zRot)*Math.sin(xRot)*Math.sin(yRot) + Math.cos(xRot)*Math.sin(zRot)), (float)(-(Math.cos(xRot)*Math.cos(zRot)*Math.sin(yRot)) + Math.sin(xRot)*Math.sin(zRot)),
             (float)(-(Math.cos(yRot)*Math.sin(zRot))), (float)( Math.cos(xRot)*Math.cos(zRot) - Math.sin(xRot)*Math.sin(yRot)*Math.sin(zRot)), (float)( Math.cos(zRot)*Math.sin(xRot) + Math.cos(xRot)*Math.sin(yRot)*Math.sin(zRot)),
             (float)(Math.sin(yRot)), (float)(-(Math.cos(yRot)*Math.sin(xRot))), (float)(Math.cos(xRot)*Math.cos(yRot) ));
    }

    public static Matrix mul(Matrix m2, Matrix m1) {
        Matrix t = new Matrix();
        Vec tv = new Vec();
        tv.set(m1.a.x, m1.b.x, m1.c.x);
        t.a.x=Vec.dot(tv, m2.a); t.b.x=Vec.dot(tv, m2.b); t.c.x=Vec.dot(tv, m2.c);
        tv.set(m1.a.y, m1.b.y, m1.c.y);
        t.a.y=Vec.dot(tv, m2.a); t.b.y=Vec.dot(tv, m2.b); t.c.y=Vec.dot(tv, m2.c);
        tv.set(m1.a.z, m1.b.z, m1.c.z);
        t.a.z=Vec.dot(tv, m2.a); t.b.z=Vec.dot(tv, m2.b); t.c.z=Vec.dot(tv, m2.c);
        return t;
    }
    
    public static Vec mul(Matrix m, Vec v) {
        return new Vec(m.a.x*v.x + m.b.x*v.y + m.c.x*v.z,
                       m.a.y*v.x + m.b.y*v.y + m.c.y*v.z,
                       m.a.z*v.x + m.b.z*v.y + m.c.z*v.z);
    }

    public void inverseOf(Matrix tr) {
        float d00 = tr.b.y*tr.c.z - tr.c.y*tr.b.z;
        float d01 = tr.a.y*tr.c.z - tr.c.y*tr.a.z;
        float d02 = tr.a.y*tr.b.z - tr.b.y*tr.a.z;
        
        float d10 = tr.b.x*tr.c.z - tr.c.x*tr.b.z;
        float d11 = tr.a.x*tr.c.z - tr.c.x*tr.a.z;
        float d12 = tr.a.x*tr.b.z - tr.b.x*tr.a.z;
        
        float d20 = tr.b.x*tr.c.y - tr.c.x*tr.b.y;
        float d21 = tr.a.x*tr.c.y - tr.c.x*tr.a.y;
        float d22 = tr.a.x*tr.b.y - tr.b.x*tr.a.y;
        
        float determinant = (tr.a.x*d00 - tr.b.x*d01 + tr.c.x*d02);
        
        if (determinant == 0.0) {
            System.err.println("Matrix inversion impossible");
            return;
        }
        determinant = 1.0f/determinant;
        
        a.set( d00*determinant, -d01*determinant,  d02*determinant );
        b.set(-d10*determinant,  d11*determinant, -d12*determinant );
        c.set( d20*determinant, -d21*determinant,  d22*determinant );
    }
}
