//  Copyright (C) 2004 Philip Proudman
//
//  This file is part of Quick3dApplet
//
//  Quick3dApplet is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  Quick3dApplet is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with Quick3dApplet in the file called "COPYING" in the top directory;
//  if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


package Quick3dApplet;

public final class ColTri extends Tri
{
    private int col;
    private int shadedCol;
    
    public ColTri(Vertex ai, Vertex bi, Vertex ci, int colour) {
        super(ai, bi, ci);
        col = colour;
    }

    public void setCol(int c) {
        col = c;
    }

    public int getCol() {
        return col;
    }
    
    void init(Render r, Vec norm) {
        norm.makeUnitVec();
        float f = Vec.dot(r.lightDir, norm)*256f;
        int lightFrac = (int)f;
        if (lightFrac < r.amb) lightFrac=r.amb;
        else if (lightFrac > 256) lightFrac=256;
        shadedCol = ((((col&0xff00)*lightFrac)&0xff0000) |
                     (((col&0xff00ff)*lightFrac)&0xff00ff00) ) >> 8;
    }

    void map(Render r, Line2 left, float y) {
        byte flag = left.flag;
        final int luTop[] = { -1, 0, 1, -1, 2 };
        flag &= 7;
        Line2 right = l[luTop[in ^ flag]];
        float lFracDelt = 1/(left.p2.y - left.p1.y);
        float rFracDelt = 1/(right.p2.y - right.p1.y);
        {
            // Get l and r leftmost and rightmost
            boolean swap = false;
            if (left.p1 == right.p1) {
                if ((left.p2.x - left.p1.x)*lFracDelt >
                    (right.p2.x - right.p1.x)*rFracDelt) swap = true;
            }
            //UNCOMMENT FOR CHECKING
            //else if (left.p2 != right.p2) System.ouprintln("This should not happen - fix");
            else {
                if ((left.p1.x - left.p2.x)*lFracDelt >
                    (right.p1.x - right.p2.x)*rFracDelt) swap = true;
            }
            if (swap) {
                Line2 tmp = left; left = right; right = tmp;
                float t3 = lFracDelt; lFracDelt = rFracDelt; rFracDelt = t3;
            }
        }
        rightLine = right;
        float lFrac = (y - left.p1.y) * lFracDelt;
        float rFrac = (y - right.p1.y) * rFracDelt;
    }

    void prep(Line2 left, int x) {
        float dif = rightLine.currentX - left.currentX;
        float frac = 1f/dif;
        
        deltaDepth = (rightLine.currentZ - left.currentZ)*frac;
        depth = left.currentZ + deltaDepth*(x-left.currentX);
    }

    void draw(Render r, Pixstore px, int mi, float xStart) {
        for(;r.idx<=mi; ++r.idx) {
            // Colour the pixel
            px.pix[r.idx] = shadedCol;
        }
    }

    void nextLine() {
    }

    void getClipped(float clipPlane, RenderObject cro) {
        Vertex clipped[]=new Vertex[3];
        Vertex notClipped[]=new Vertex[3];
        int nCl = 0;
        int nNotCl = 0;
        if (a.xformed.z < clipPlane) { clipped[nCl] = a; ++nCl; }
        else { notClipped[nNotCl] = a; ++nNotCl; }
        if (b.xformed.z < clipPlane) { clipped[nCl] = b; ++nCl; }
        else { notClipped[nNotCl] = b; ++nNotCl; }
        if (c.xformed.z < clipPlane) { clipped[nCl] = c; ++nCl; }
        else { notClipped[nNotCl] = c; ++nNotCl; }
        switch (nCl) {
        case 3:
            // All vertexes clipped, no triangle visible
            break;
        case 2:
            {
                // Calculate 2 new points on the clipping plane for our triangle
                Vec dir0 = Vec.sub(clipped[0].xformed, notClipped[0].xformed);
                Vec dir1 = Vec.sub(clipped[1].xformed, notClipped[0].xformed);
                float fr0 = ( clipPlane - notClipped[0].xformed.z ) / dir0.z;
                float fr1 = ( clipPlane - notClipped[0].xformed.z ) / dir1.z;

                Vertex v1 = new Vertex(new Vec(notClipped[0].xformed));
                Vertex v2 = new Vertex(Vec.add(notClipped[0].xformed, Vec.mul(dir0, fr0)));
                Vertex v3 = new Vertex(Vec.add(notClipped[0].xformed, Vec.mul(dir1, fr1)));
                v1.xformed = v1.pos;
                v2.xformed = v2.pos;
                v3.xformed = v3.pos;
                cro.addVert(v1);
                cro.addVert(v2);
                cro.addVert(v3);

                if (b == notClipped[0]) cro.addTri(new ColTri(v2,v1,v3,col));
                else cro.addTri(new ColTri(v1,v2,v3,col));
            }
            break;
        case 1:
            {
                // Calculate 2 new points on the clipping plane for our triangle
                Vec dir0 = Vec.sub(notClipped[0].xformed, clipped[0].xformed);
                Vec dir1 = Vec.sub(notClipped[1].xformed, clipped[0].xformed);
                float fr0 = ( clipPlane - clipped[0].xformed.z ) / dir0.z;
                float fr1 = ( clipPlane - clipped[0].xformed.z ) / dir1.z;
                Vec pos0 = Vec.add(clipped[0].xformed, Vec.mul(dir0, fr0));
                Vec pos1 = Vec.add(clipped[0].xformed, Vec.mul(dir1, fr1));

                Vertex v1 = new Vertex(new Vec(notClipped[0].xformed));
                Vertex v2 = new Vertex(new Vec(notClipped[1].xformed));
                Vertex v3 = new Vertex(pos0);
                Vertex v4 = new Vertex(pos1);
                v1.xformed = v1.pos;
                v2.xformed = v2.pos;
                v3.xformed = v3.pos;
                v4.xformed = v4.pos;
                cro.addVert(v1);
                cro.addVert(v2);
                cro.addVert(v3);
                cro.addVert(v4);

                if (b == clipped[0]) {
                    cro.addTri(new ColTri(v2,v1,v3,col));
                    cro.addTri(new ColTri(v4,v2,v3,col));
                }
                else {
                    cro.addTri(new ColTri(v1,v2,v3,col));
                    cro.addTri(new ColTri(v4,v3,v2,col));
                }
            }
            break;
        case 0:
            // Should never happen!
        }
    }
}
