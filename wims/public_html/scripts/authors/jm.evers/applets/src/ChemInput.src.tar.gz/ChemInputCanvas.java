import java.awt.*;
import java.awt.event.*;                                                                                                
import java.util.*;
import java.awt.Color;

public class ChemInputCanvas extends Canvas {
	public void paint(Graphics g ){
	Font f = new Font("TimesRoman",Font.BOLD,ChemInput.fontsize);
	fm = g.getFontMetrics(f);
	g.setFont(f);
	Dimension d = size();
	int client_width = d.width ;
	int sup_sub = 0;
	int h_mul = 1;
	int i,j = 0;
	boolean test;
	int client_height = d.height;
	int cx = client_width /2;
	cy = client_height/2;

	int charWidth = fm.charWidth('W');
	int maxChars = client_width / charWidth;
	g.setColor(ChemInput.bgcolor2);
	offset=offset*2*fm.getHeight();

	if(state() > 0) g.fillRect(0,cy-fm.getHeight()+offset,client_width,fm.getHeight()/2);
	else
	if(state() <0 ) g.fillRect(0,cy+offset,client_width,fm.getHeight()/2);
	else
	g.fillRect(0,cy-fm.getHeight()/2+offset,client_width,fm.getHeight()/2);	

	g.setFont(f);
	g.setColor(ChemInput.pencolor);

	StringBuffer t = new StringBuffer(100);
	t.insert(0,s1);//copy s1 to t
	String s6 = t.toString();//convert t back to String s6
	increment = 0;
	offset = 0;
	for (i=0;i<s6.length();i++){
	    if(increment > ChemInput.xsize - charWidth && increment < ChemInput.xsize + charWidth){
		increment = 0;
		offset++;
		cy = cy+2*fm.getHeight();
	    }
	    if (s6.indexOf("}") != -1){
		if (s6.indexOf("^{",i) == i || s6.indexOf("_{",i)==i){//}}
		    if (s6.indexOf("^{",i) == i ) sup_sub = 1;//}
		    if (s6.indexOf("_{",i) == i ) sup_sub = -1;//}
		    i = i +2;
		    j = fm.getHeight()*h_mul/2;//{
		    test = s6.substring(i,i+1).equals("}"); 	
		    while ( !test){
			g.drawString(s6.substring(i,i+1),4+increment,cy-j*sup_sub);
			increment += fm.stringWidth(s6.substring(i,i+1));//width of font???
			i++;//{
			test = s6.substring(i,i+1).equals("}"); 	
		    }
		}
		else
		{
		    sup_sub = 0;
		    j = 0;
		    g.drawString(s6.substring(i,i+1),4+increment,cy+j*sup_sub);
		    increment += fm.stringWidth(s6.substring(i,i+1));//width of font???
		}
	    }
	    else 
	    {
		g.drawString(s6,4,cy);
		increment += fm.stringWidth(s6);//width of font???
		break;
	    }
	}
   
 }
    
    public void setsuper(int flag){
	ChemInputCanvas.super_flag = state()+flag;
	if(ChemInputCanvas.super_flag > 0 )ChemInputCanvas.super_flag = 1;
	else
	if(ChemInputCanvas.super_flag < 0 )ChemInputCanvas.super_flag = -1;
        else ChemInputCanvas.super_flag = 0;
	repaint();
    }
  
    public int state() {
	if (ChemInputCanvas.super_flag >0) return (1);
	else if (ChemInputCanvas.super_flag <0) return (-1);
	else return (0);
    }

    public void update(String args) {
    	s1=ChemInput.replace(args,"}^{","");
	s1=ChemInput.replace(args,"}_{","");
	ChemInputCanvas.s1 = s1;
	repaint();
    }

    public void clear() {  
	ChemInputCanvas.s1 = "";
	repaint();
    }
    
    public static int cy;
    public int increment;
    public int offset;
    public boolean DeBug = false;
    public StringBuffer c1;
    public static String s1 = "";
    public static int super_flag=0;
    public static FontMetrics fm;

}
