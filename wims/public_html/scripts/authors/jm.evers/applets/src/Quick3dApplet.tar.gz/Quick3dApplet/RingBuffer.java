//  Copyright (C) 2004 Philip Proudman
//
//  This file is part of Quick3dApplet
//
//  Quick3dApplet is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  Quick3dApplet is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with Quick3dApplet in the file called "COPYING" in the top directory;
//  if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


package Quick3dApplet;
import java.util.*;

//***************************************************************************

final class RingBuffer {
    private Line2[] a;
    private int len = 4;
    private int ptrPush = len-1; // Points at the last pushed
    private int ptrPop = 0; // Points at the next to pop
    private boolean empty = true;
    
    public RingBuffer() {
        a = new Line2[len];
    }

    public void reset() {
        //System.out.println("Reset");
        ptrPush = len-1;
        ptrPop = 0;
        empty = true;
    }

    public Line2 popAndPush(Line2 l) {
        push(l);
        Line2 rv = pop();
        return rv;
    }

    public Line2 pop() {
        //if (empty) {
        //    System.out.println("Check failed");
        //    a[-1].currentX = 0; // Crash
        //}
        Line2 rv = a[ptrPop];
        if (ptrPop == ptrPush) empty = true;
        ++ptrPop; if (ptrPop >= len) ptrPop = 0;
        //System.out.println("Pop " + rv.currentX);
        return rv;
    }

    public void pushBot(Line2 l) {
        //System.out.println("PushBot " + l.currentX);
        --ptrPop; if (ptrPop < 0) ptrPop = len-1;
        if (!empty && ptrPush == ptrPop) {
            ++ptrPop; if (ptrPop >= len) ptrPop = 0;
            expand();
            --ptrPop; if (ptrPop < 0) ptrPop = len-1;
        }
        empty = false;
        a[ptrPop] = l;
    }
    
    public void push(Line2 l) {
        //System.out.println("Push " + l.currentX);
        ++ptrPush; if (ptrPush >= len) ptrPush = 0;
        if (!empty && ptrPush == ptrPop) {
            --ptrPush; if (ptrPush < 0) ptrPush = len-1;
            expand();
            ++ptrPush; if (ptrPush >= len) ptrPush = 0;
        }
        empty = false;
        a[ptrPush] = l;
    }

    //private void show() {
    //    int i=ptrPop;
    //    System.out.println("Show");
    //    int num = 0;
    //    while (num == 0 || i != ptrPush) {
    //        System.out.println(a[i].currentX);
    //        ++i; ++num;
    //        if (i >= len) i = 0;
    //    }
    //    System.out.println(a[i].currentX);
    //    ++num;
    //    System.out.println("Shown" + num);
    //}
    
    private void expand() {
        //System.out.println("Expand");
        int newLen = len*2;
        Line2[] b = new Line2[newLen];
        
        int id = 0;
        for (int i = ptrPop; i < len; ++i, ++id) b[id] = a[i];
        for (int i = 0; i < ptrPop; ++i, ++id) b[id] = a[i];
        ptrPop = 0;
        ptrPush = len-1;
        a = b;
        len = newLen;
    }
};
