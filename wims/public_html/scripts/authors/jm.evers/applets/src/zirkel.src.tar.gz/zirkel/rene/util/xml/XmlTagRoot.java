package rene.util.xml;

public class XmlTagRoot extends XmlTag
{	String Content;
	public XmlTagRoot ()
	{	super("#ROOT");
	}
}
