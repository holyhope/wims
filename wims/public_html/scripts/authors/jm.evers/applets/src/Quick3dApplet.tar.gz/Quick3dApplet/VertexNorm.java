//  Copyright (C) 2004 Philip Proudman
//
//  This file is part of Quick3dApplet
//
//  Quick3dApplet is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  Quick3dApplet is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with Quick3dApplet in the file called "COPYING" in the top directory;
//  if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

package Quick3dApplet;

public final class VertexNorm {
    public Vec norm; // The original norm
    Vec normXformed; // Used for rendering calculations
    
    public VertexNorm(Vec n) {
        norm = n;
    }

    public void reset(Matrix rot) {
        normXformed = Matrix.mul(rot, norm);
    }
}
