package geo ;

import java.awt.Graphics ;

/**
 * Objet g�om�trique li� � un rep�re.
 */

public class ObjetRepere
{

/**
 * Repere associ�.
 */

  public Repere R ;

/**
 * Existence de l'objet.
 */

  public boolean defini ;

/**
 * Nom de l'objet.
 */

  public String Nom ;

/**
 * Construit un objet non d�fini.
 */

  public ObjetRepere (String Nom, Repere R )
  { this.Nom = Nom ; this.R = R ; defini = false ; }

/**
 * Test la proximit� de la souris.
 */

  public boolean zone (int X, int Y)
  { return false ; }

/**
 * Trace l'objet.
 */

  public void trace (Graphics g)
  {  }

}
