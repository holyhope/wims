package rene.zirkel.docs;

public abstract class ZirkelProperties_pt{
}
