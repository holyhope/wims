package fr.ove.openmath.jome.model;
public class resources2_en{
}
