package rene.zirkel.expression;

import rene.zirkel.construction.Construction;

/**
 * @author Rene
 *
 */
public interface Translator
{	public void laterTranslate (Construction from);
}
