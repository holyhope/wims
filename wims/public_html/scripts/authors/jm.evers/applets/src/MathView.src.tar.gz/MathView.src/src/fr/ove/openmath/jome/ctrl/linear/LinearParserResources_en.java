package fr.ove.openmath.jome.ctrl.linear;
public class LinearParserResources_en{
}