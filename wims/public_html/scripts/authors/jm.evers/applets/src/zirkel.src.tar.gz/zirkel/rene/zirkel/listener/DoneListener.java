package rene.zirkel.listener;

public interface DoneListener
{	public void notifyDone ();
}
