package rene.viewer;

public interface WheelListener
{	void up (int n);
	void down (int n);
	void pageUp ();
	void pageDown ();
}