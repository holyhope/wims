import java.awt.*;
import java.awt.event.*;
import java.util.Vector;

class ChemInputCanvas extends Canvas implements MouseListener, MouseMotionListener,KeyListener{

    ChemInputCanvas(){
        setBackground(ChemInputApplet.bgcolor3);
        addMouseListener(this);
	addKeyListener(this); 
        addMouseMotionListener(this);
    }

    public synchronized void paint(Graphics g){
	f = new Font("TimesRoman",Font.BOLD,newsize);
	fm = g.getFontMetrics(f);
	fh = fm.getHeight();
	fw = fm.charWidth('W');
	fp = fm.charWidth('.');
	if(once == false){
	    AppletText2Array(applettext);
	}
	int wmax=getSize().width;
	int hmax = getSize().height;
	y0 = hmax/2;
	g.clearRect(0,0,wmax,hmax);
	g.setFont(f);
	g.setColor(bgcolor2);
	int x1=0;
	int y1;
	int x2=getSize().width;
	int y2;
                                                                                                                                        
        if(position == 2){y1=y0-fh;y2=fh/2;}
        else                                                                                                                               
        if(position == 0){y1=y0;y2=fh/2;}
        else {y1=y0-fh/2;y2=fh/2;}
	
	g.fillRect(x1,y1,x2,y2);
	g.setFont(f);
	g.setColor(pencolor);
	int w=0;
	for(int i=0;i<index;i++){
	    if(CharArray[i] != null){
		if(i != charclicked){g.setColor(pencolor);}else{g.setColor(Color.red);}
		if(CharPosition[i] == 1){g.drawString(CharArray[i],w,y0);}
		else
		if(CharPosition[i] == 0){g.drawString(CharArray[i],w,y0 + fh/2);}
	        else
		if(CharPosition[i] == 2){g.drawString(CharArray[i],w,y0-fh/2);}
		w=w+CharWidth[i];    
	    }
	}
    }
    
    public void update(){
	if(index > max_chars - 4){index = max_chars - 4;}
	repaint();
    }

    public String[] ForbiddenKeysChars={"!","~","`","@","#","$","%","&","|","\\","=","/","{","}"};
    public int[] ForbiddenKeys={16,17,18,20,27,37,39,112,113,114,115,116,117,118,119,120};

    public void clear(){// niet vergeten applettxt in de arrays !
	position=1;
	charclicked=-1;
	once=false;
	CharArray = new String[max_chars];
	CharPosition = new int[max_chars];
	CharWidth = new int[max_chars];
	update();
	index=0;
    }
    
    public void SwitchFont(int s){
	newsize=newsize + s;
	update();
    }
    
    public void AppletText2Array(String text){
	once=true;
	if(text.length() != 0){
	    text = replace(text," ","");
	    text = replace(text,"{","");
	    text = replace(text,"\\rightarrow","\u21C4");
	    text = replace(text,"\\leftrightarrow","\u2192");
	    text = replace(text,"\\downarrow","\u2193");
	    int i;
	    for( i=0;i<text.length();i++){
		if( text.charAt(i) == '^'){
		    i++;//remove ^  Cu(OH)_{6}
		    while(text.charAt(i) != '}' && i < text.length()){
			CharArray[i] = Character.toString(text.charAt(i));
		        CharPosition[i] = 2;
			CharWidth[i] = fp+fm.charWidth(text.charAt(i));
			i++;
		    }
		}
		else
		if(text.charAt(i) == '_'){
		    i++;
		    while(text.charAt(i) != '}' && i < text.length()){
			CharArray[i] =  Character.toString(text.charAt(i));
			CharPosition[i] = 0;
			CharWidth[i] = fp+fm.charWidth(text.charAt(i));
			i++;
		    }
		}
		else
		{
			CharArray[i] =  Character.toString(text.charAt(i));
			CharPosition[i] = 1;
			CharWidth[i] = fp+fm.charWidth(text.charAt(i));
		}
	    }
	    charclicked = -1;
	    position = 1;
	    index =  i;
	}
    }

    public synchronized void mousePressed(MouseEvent evt){
	charclicked=-1;
        int x = evt.getX();int y = evt.getY();int p=1;
	if( y >  y0 - 2*fh && y <  y0 + 2*fh ){
	    if( y < y0 + fh && y > y0 + fh/4 ){ p = 0; } else { if ( y > y0 - 2*fh && y < y0 - fh/4){ p = 2;}}
	    int widthprogress=0;
	    for(int i=0; i<index;i++){
		if(x > widthprogress  && x< widthprogress+CharWidth[i]){
		    //System.out.println("geklikt op letter"+i);
		    charclicked=i;
		    if(p!=1){ position=p;}else{position=CharPosition[i];}
		    if(evt.getButton() == MouseEvent.BUTTON3 || evt.getButton() == MouseEvent.BUTTON2){DeleteChar(i);}
		    //System.out.println("geklikt op letter"+CharArray[i]+" en positie"+CharPosition[i]);
		    repaint();
		} 
		widthprogress = widthprogress + CharWidth[i];
	    }
	}
    }

    public synchronized void mouseDragged(MouseEvent evt){}
    public synchronized void mouseReleased(MouseEvent evt){}
    public void mouseEntered(MouseEvent mouseevent){}
    public void mouseExited(MouseEvent mouseevent){}
    public void mouseMoved(MouseEvent mouseevent){}
    public void mouseClicked(MouseEvent mouseevent){}

    public void keyPressed(KeyEvent e){
	ProcessKey(Character.toString(e.getKeyChar()),e.getKeyCode());
	repaint();
    }
    
    public void keyTyped(KeyEvent e ) {
    }                                                                                                                                        
                                                                                                                                           
    public void keyReleased(KeyEvent e){
    }     

    public void MarkedKey(String key_char ,int key){// only called if charclicked>-1
	boolean goodkey=true;
	for(int i=0;i<ForbiddenKeysChars.length;i++){ if(key_char.equals(ForbiddenKeysChars[i]) && goodkey){ goodkey = false;} }
	if(goodkey){
	    if(key == 10 || key == 27 ){charclicked=-1;}//enter
	    else
	    if(key == 37 ){charclicked=charclicked - 1;if(charclicked<0){charclicked=0;}}// linker pijl
	    else
	    if(key == 39 ){charclicked=charclicked + 1;if(charclicked >= index){charclicked=index-1;}}// recher pijl
	    else
	    if( key == 95){MoveChar(charclicked,position);}// linker pijl
	    else
	    if( key == 8 || key == 127){DeleteChar(charclicked);}//backspace & delete on marked 
	    else
	    if( key == 38 || key == 33){position = NewPosition(1 , position);CharPosition[charclicked] = position;}//up
	    else
	    if( key == 40 || key == 34){position = NewPosition(-1 , position);CharPosition[charclicked] = position;}//down
	    else
	    if( key == 8 ){DeleteChar(charclicked);}// delete char index from the array
	    else
	    if( key == 155){ // insert buttonn
		index++;
	    	for(int i=index;i>charclicked;i--){
		    CharArray[i]=CharArray[i-1];
		    CharPosition[i]=CharPosition[i-1];
		    CharWidth[i]=CharWidth[i-1];
		}
		CharArray[charclicked] = key_char;
		CharPosition[charclicked] = position;
		CharWidth[charclicked] =  fp + fm.charWidth(key_char.charAt(0));
		//System.out.println("inserting "+key_char+" op positie "+position);	
	    }
	    else
	    {
		CharArray[charclicked]=key_char;
		CharPosition[charclicked]=position;
		CharWidth[charclicked]= fp + fm.charWidth(key_char.charAt(0));
	    }
	}
    }

    public void AppendSymbol(String s, int pos){// VIA MUISKLIK + TOETSENBORD
	CharPosition[index] = pos;
	CharArray[index] = s;
	int w=0;// find length string
	for(int i=0;i<s.length();i++){
	    w=w+fm.charWidth(s.charAt(i));
	}
	CharWidth[index] = fp+w;
	update();
	index++;
    }
    public void MoveChar(int i , int p){
	CharPosition[i] = p;
	update();
	//charclicked=-1;
    }


    public void ProcessKey(String key_char ,int key){
	if(charclicked != -1 ){MarkedKey(key_char,key);}
	else
	{
	    boolean goodkey=true;
	    for(int i=0;i<ForbiddenKeysChars.length;i++){ if(key_char.equals(ForbiddenKeysChars[i]) && goodkey){ goodkey = false;} }
	    for(int i=0;i<ForbiddenKeys.length;i++){ if(key == ForbiddenKeys[i] && goodkey){ goodkey = false;} }
	    if(goodkey){
		if( key == 33 ){ position = NewPosition(1 , position);}//pageup
		else
		if( key == 34 ){ position = NewPosition(-1 , position);}//pagedown
		else
		if( key == 36 ){charclicked = 0;}//home
		else
		if( key == 35 ){charclicked = index-1;}//end
		else
		if( (key == 127 || key == 8) && index>0 ){DeleteChar(index);}
		else
		if( key == 38 || key == 94 ){ position = NewPosition(1 , position);}
		else
		if(  key == 40 || key == 95 ){ position = NewPosition(-1 , position);}
		else{
		    CharArray[index]=key_char;
		    CharPosition[index]=position;
		    CharWidth[index]=  fp + fm.charWidth(key_char.charAt(0));;
		    index++;
		}
	    }
	}
    }

    
    public int NewPosition(int P , int old){
	int n = old + ( P );
	if(n>2){n=2;}
	else 
	if(n<0){n=0;}
	return n;
    }
    
    public void DeleteChar(int d){
	int m;index=index-1;
	for(int i=0;i<index;i++){
	    if(i >= d){
		m=i+1;
		CharArray[i]=CharArray[m];
		CharPosition[i]=CharPosition[m];
		CharWidth[i]=CharWidth[m];	    
	    }
	}
	CharArray[index]=null;
    }
    

    public String replace(String source, String pattern, String replace){
        if (source!=null){
	    final int len = pattern.length();
	    StringBuffer sb = new StringBuffer();
	    int found = -1;
	    int start = 0;
	    while( (found = source.indexOf(pattern, start) ) != -1) {
		sb.append(source.substring(start, found));
		sb.append(replace);
		start = found + len;
	    }
	    sb.append(source.substring(start));
	    return sb.toString();
        }
        else return "";
    }

    public void ShowHelp(){
	System.out.println("laat helptext zien");
    }

    public static String MakeText(){
	StringBuffer Text = new StringBuffer();
	for(int i=0;i<max_chars;i++){
	    if(CharArray[i] != null){
		if(CharPosition[i] == 1){Text.append(CharArray[i]);}
		else
		if(CharPosition[i] == 2 ){Text.append("^") ;
		    while(CharPosition[i] == 2  && CharArray[i]!=null){
		        Text.append(CharArray[i]) ;
			i++;
		    }
		    Text.append(" ");
		    i=i-1;
		}
		else
		if(CharPosition[i] == 0 ){
		    while(CharPosition[i] == 0 && CharArray[i]!=null){
			Text.append(CharArray[i]) ;
			i++;
		    }
		    Text.append(" ");
		    i=i-1;
		}
	    }
	}
	return Text.toString();
    }
    
    public static String MakeLaTeX(){
	StringBuffer LaTeX = new StringBuffer();
	for(int i=0;i<max_chars;i++){
	    if(CharArray[i] != null){
		if(CharPosition[i] == 1){LaTeX.append(CharArray[i]);}
		else
		if(CharPosition[i] == 2 ){LaTeX.append("^{") ;
		    while(CharPosition[i] == 2  && CharArray[i]!=null){
		        LaTeX.append(CharArray[i]) ;
			i++;
		    }
		    i=i-1;
		    LaTeX.append("}");
		}
		else
		if(CharPosition[i] == 0 ){LaTeX.append("_{");
		    while(CharPosition[i] == 0  && CharArray[i]!=null){
		    LaTeX.append(CharArray[i]) ;
			i++;
		    }
		    i=i-1;
		    LaTeX.append("}");
		}
	    }
	}
	return LaTeX.toString();
    }
    boolean once = false;
    public static int max_chars = 100;
    public static String[] CharArray = new String[max_chars];
    public static int[] CharPosition = new int[max_chars];
    public static int[] CharWidth = new int[max_chars];
    public int index=0;
    public static int position=1;// 0,1,2 last edit
    public int charclicked=-1;
    public int newsize=ChemInputApplet.fontsize;
    public static String applettext=ChemInputApplet.applettext;
    public static int y0;
    public static FontMetrics fm;
    public static Font f;
    public static int fh; //font height
    public static int fw; //font width 'W'
    public static int fp; //font width '.'
    public static int highlight=0;
    Color pencolor = ChemInputApplet.pencolor;
    Color bgcolor2 = ChemInputApplet.bgcolor2;
}



