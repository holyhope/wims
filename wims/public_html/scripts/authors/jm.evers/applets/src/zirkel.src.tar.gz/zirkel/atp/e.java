package atp;


class e
{

    public int y;
    public String w;
    public static final int k = 0;
    public static final int _fldbyte = 1;
    public static final int o = 2;
    public static final int r = 3;
    public static final int _fldlong = 4;
    public static final int j = 5;
    public static final int _fldelse = 7;
    public static final int _fldfor = 8;
    public static final int q = 9;
    public static final int s = 10;
    public static final int B = 11;
    public static final int _fldvoid = 12;
    public static final int _flddo = 13;
    public static final int t = 14;
    public static final int _fldchar = 15;
    public static final int i = 16;
    public static final int A = 17;
    public static final int u = 18;
    public static final int _fldcase = 19;
    public static final int C = 20;
    public static final int d = 22;
    public static final int m = 24;
    public static final int g = 25;
    public static final int f = 50;
    public static final int v = 51;
    public static final int _fldint = 99;
    public static final int p = 100;
    public static final int _fldif = 108;
    public static final int n = 109;
    public static final int _fldnull = 110;
    public static final int a = 113;
    public static final int b = 114;
    public static final int c = 115;
    public static final int D = 116;
    public static final int l = 117;
    public static final int h = 118;
    public static final int z = 119;
    public static final int x = 120;
    public static final int _fldnew = 121;
    public static final int _fldtry = 122;
    public static final int e = 123;
    public static final int _fldgoto = 124;

    public e(int i1, String s1)
    {
        y = i1;
        w = s1;
    }

    public e(int i1)
    {
        y = i1;
        w = "";
    }

    public e()
    {
        y = 0;
        w = "";
    }
}
