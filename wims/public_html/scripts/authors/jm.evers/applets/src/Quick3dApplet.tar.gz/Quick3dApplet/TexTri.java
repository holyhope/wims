//  Copyright (C) 2004 Philip Proudman
//
//  This file is part of Quick3dApplet
//
//  Quick3dApplet is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  Quick3dApplet is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with Quick3dApplet in the file called "COPYING" in the top directory;
//  if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


package Quick3dApplet;

public final class TexTri extends Tri
{
    float lastX;

    // Texture
    private Pixstore texture = null;
    private Vec2 texPos[] = new Vec2[3];

    // Used by the render method...
    private int lightFrac;
    private Vec2 texScanlineStart = new Vec2();
    private Vec2 texScanlineEnd = new Vec2();
    private Vec2 texScanlineDeltaStart = new Vec2();
    private Vec2 texScanlineDeltaEnd = new Vec2();
    private Vec2 texRow = new Vec2();
    private Vec2 texRowDelta = new Vec2();
    
    public TexTri(Vertex ai, Vertex bi, Vertex ci,
                  Pixstore t, Vec2 at, Vec2 bt, Vec2 ct) {
        super(ai, bi, ci);
        texture = t;
        texPos[0] = at;  
        texPos[1] = bt;
        texPos[2] = ct;
    }

    public void setTex(Pixstore tex) {
        // User can replace with a Pixstore of equal size after instantiation
        texture = tex;
    }

    public Pixstore getTex() {
        return texture;
    }
    
    void init(Render r, Vec norm) {
        if (r.shade) {
            norm.makeUnitVec();
            float f = Vec.dot(r.lightDir, norm)*256f;
            lightFrac = (int)f;
            if (lightFrac < r.amb) lightFrac=r.amb;
            else if (lightFrac > 256) lightFrac=256;
        }
        else lightFrac = 256;
    }
    
    void map(Render r, Line2 left, float y) {
        byte flag = left.flag; flag &= (byte)15;
        final int luTop[] = { -1, 0, 1, -1, 2, -1,-1,-1,-1, 1, 2, -1, 0 };
        final int luBot[] = { -1, 1, 2, -1, 0, -1,-1,-1,-1, 0, 1, -1, 2 };
        Vec2 lTexTop = texPos[luTop[flag]];
        Vec2 lTexBot = texPos[luBot[flag]];
        flag &= 7;
        flag ^= in;
        Line2 right = l[luTop[flag]];
        flag = right.flag; flag &= (byte)15;
        Vec2 rTexTop = texPos[luTop[flag]];
        Vec2 rTexBot = texPos[luBot[flag]];
        float lFracDelt = 1/(left.p2.y - left.p1.y);
        float rFracDelt = 1/(right.p2.y - right.p1.y);
        {
            // Get l and r leftmost and rightmost
            boolean swap = false;
            if (left.p1 == right.p1) {
                if ((left.p2.x - left.p1.x)*lFracDelt >
                    (right.p2.x - right.p1.x)*rFracDelt) swap = true;
            }
            //UNCOMMENT FOR CHECKING
            //else if (left.p2 != right.p2) System.ouprintln("This should not happen - fix");
            else {
                if ((left.p1.x - left.p2.x)*lFracDelt >
                    (right.p1.x - right.p2.x)*rFracDelt) swap = true;
            }
            if (swap) {
                Line2 tmp = left; left = right; right = tmp;
                Vec2 t2;
                t2 = lTexTop; lTexTop = rTexTop; rTexTop = t2;
                t2 = lTexBot; lTexBot = rTexBot; rTexBot = t2;
                float t3 = lFracDelt; lFracDelt = rFracDelt; rFracDelt = t3;
            }
        }
        rightLine = right;
        float lFrac = (y - left.p1.y) * lFracDelt;
        float rFrac = (y - right.p1.y) * rFracDelt;

        lTexTop = Vec2.mul(lTexTop, left.p1.z);
        lTexBot = Vec2.mul(lTexBot, left.p2.z);
        rTexTop = Vec2.mul(rTexTop, right.p1.z);
        rTexBot = Vec2.mul(rTexBot, right.p2.z);

        texScanlineStart.set(lTexTop.x + (lTexBot.x-lTexTop.x)*lFrac,
                             lTexTop.y + (lTexBot.y-lTexTop.y)*lFrac);
        texScanlineEnd.set(rTexTop.x + (rTexBot.x-rTexTop.x)*rFrac,
                           rTexTop.y + (rTexBot.y-rTexTop.y)*rFrac);
                                
        texScanlineDeltaStart.set((lTexBot.x-lTexTop.x)*lFracDelt,
                                  (lTexBot.y-lTexTop.y)*lFracDelt);
        texScanlineDeltaEnd.set((rTexBot.x-rTexTop.x)*rFracDelt,
                                (rTexBot.y-rTexTop.y)*rFracDelt);
    }

    void prep(Line2 left, int x) {
        texRow.set(texScanlineStart.x, texScanlineStart.y);
        float dif = rightLine.currentX - left.currentX;
        float frac = 1f/dif;
        texRowDelta.set((texScanlineEnd.x-texScanlineStart.x)*frac,
                          (texScanlineEnd.y-texScanlineStart.y)*frac);
        
        deltaDepth = (rightLine.currentZ - left.currentZ)*frac;
        lastX = left.currentX;
        depth = left.currentZ + deltaDepth*(x-left.currentX);
    }

    void draw(Render r, Pixstore px, int mi, float xStart) {
        {
            float frac = xStart - lastX;
            texRow.set(texRow.x + texRowDelta.x*frac,
                       texRow.y + texRowDelta.y*frac);
        }

        int wid = texture.getWidth();
        int max = texture.getMax();
        float d = depth;
        lastX = xStart + (1+mi-r.idx);

        for(;r.idx<=mi; ++r.idx) {
            // Colour the pixel
            int c;
            {
                float dep = 1/d; d+=deltaDepth;
                int tx = (int)(texRow.x * dep);
                texRow.x += texRowDelta.x;
                int ty = (int)(texRow.y * dep);
                texRow.y += texRowDelta.y;
                c = tx+ty*wid;
                if (c<0 || c>=max) c = 0;  // This won't happen oft!
                c = texture.pix[c];
            }
            px.pix[r.idx] = ((((c&0xff00)*lightFrac)&0xff0000) |
                             (((c&0xff00ff)*lightFrac)&0xff00ff00) ) >> 8;
        }
    }

    void nextLine() {
        texScanlineStart.x += texScanlineDeltaStart.x;
        texScanlineStart.y += texScanlineDeltaStart.y;
        texScanlineEnd.x += texScanlineDeltaEnd.x;
        texScanlineEnd.y += texScanlineDeltaEnd.y;
    }

    void getClipped(float clipPlane, RenderObject cro) {
        Vertex clipped[]=new Vertex[3];
        Vertex notClipped[]=new Vertex[3];
        Vec2 clippedTx[]=new Vec2[3];
        Vec2 notClippedTx[]=new Vec2[3];
        int nCl = 0;
        int nNotCl = 0;
        if (a.xformed.z < clipPlane) { clipped[nCl] = a; clippedTx[nCl] = texPos[0]; ++nCl; }
        else { notClipped[nNotCl] = a; notClippedTx[nNotCl] = texPos[0]; ++nNotCl; }
        if (b.xformed.z < clipPlane) { clipped[nCl] = b; clippedTx[nCl] = texPos[1]; ++nCl; }
        else { notClipped[nNotCl] = b; notClippedTx[nNotCl] = texPos[1]; ++nNotCl; }
        if (c.xformed.z < clipPlane) { clipped[nCl] = c; clippedTx[nCl] = texPos[2]; ++nCl; }
        else { notClipped[nNotCl] = c; notClippedTx[nNotCl] = texPos[2]; ++nNotCl; }
        switch (nCl) {
        case 3:
            // All vertexes clipped, no triangle visible
            break;
        case 2:
            {
                // Calculate 2 new points on the clipping plane for our triangle
                Vec dir0 = Vec.sub(clipped[0].xformed, notClipped[0].xformed);
                Vec dir1 = Vec.sub(clipped[1].xformed, notClipped[0].xformed);
                float fr0 = ( clipPlane - notClipped[0].xformed.z ) / dir0.z;
                float fr1 = ( clipPlane - notClipped[0].xformed.z ) / dir1.z;

                Vertex v1 = new Vertex(new Vec(notClipped[0].xformed));
                Vertex v2 = new Vertex(Vec.add(notClipped[0].xformed, Vec.mul(dir0, fr0)));
                Vertex v3 = new Vertex(Vec.add(notClipped[0].xformed, Vec.mul(dir1, fr1)));
                v1.xformed = v1.pos;
                v2.xformed = v2.pos;
                v3.xformed = v3.pos;
                cro.addVert(v1);
                cro.addVert(v2);
                cro.addVert(v3);

                if (b == notClipped[0])
                    cro.addTri(new TexTri(v2,v1,v3,
                                          texture,
                                          Vec2.add(notClippedTx[0], Vec2.mul(Vec2.sub(clippedTx[0], notClippedTx[0]),fr0)),
                                          notClippedTx[0],
                                          Vec2.add(notClippedTx[0], Vec2.mul(Vec2.sub(clippedTx[1], notClippedTx[0]),fr1))));
                else
                    cro.addTri(new TexTri(v1,v2,v3,
                                          texture,
                                          notClippedTx[0],
                                          Vec2.add(notClippedTx[0], Vec2.mul(Vec2.sub(clippedTx[0], notClippedTx[0]),fr0)),
                                          Vec2.add(notClippedTx[0], Vec2.mul(Vec2.sub(clippedTx[1], notClippedTx[0]),fr1))));
            }
            break;
        case 1:
            {
                // Calculate 2 new points on the clipping plane for our triangle
                Vec dir0 = Vec.sub(clipped[0].xformed, notClipped[0].xformed);
                Vec dir1 = Vec.sub(clipped[0].xformed, notClipped[1].xformed);
                float fr0 = ( clipPlane - notClipped[0].xformed.z ) / dir0.z;
                float fr1 = ( clipPlane - notClipped[1].xformed.z ) / dir1.z;

                Vertex v1 = new Vertex(new Vec(notClipped[0].xformed));
                Vertex v2 = new Vertex(new Vec(notClipped[1].xformed));
                Vertex v3 = new Vertex(Vec.add(notClipped[0].xformed, Vec.mul(dir0, fr0)));
                Vertex v4 = new Vertex(Vec.add(notClipped[1].xformed, Vec.mul(dir1, fr1)));
                v1.xformed = v1.pos;
                v2.xformed = v2.pos;
                v3.xformed = v3.pos;
                v4.xformed = v4.pos;
                cro.addVert(v1);
                cro.addVert(v2);
                cro.addVert(v3);
                cro.addVert(v4);

                if (b == clipped[0]) {
                    cro.addTri(new TexTri(v2,v1,v3,
                                          texture,
                                          notClippedTx[1],
                                          notClippedTx[0],
                                          Vec2.add(notClippedTx[0], Vec2.mul(Vec2.sub(clippedTx[0], notClippedTx[0]),fr0))));
                    cro.addTri(new TexTri(v4,v2,v3,
                                          texture,
                                          Vec2.add(notClippedTx[1], Vec2.mul(Vec2.sub(clippedTx[0], notClippedTx[1]),fr1)),
                                          notClippedTx[1],
                                          Vec2.add(notClippedTx[0], Vec2.mul(Vec2.sub(clippedTx[0], notClippedTx[0]),fr0))));
                }
                else {
                    cro.addTri(new TexTri(v1,v2,v3,
                                          texture,
                                          notClippedTx[0],
                                          notClippedTx[1],
                                          Vec2.add(notClippedTx[0], Vec2.mul(Vec2.sub(clippedTx[0], notClippedTx[0]),fr0))));
                    cro.addTri(new TexTri(v4,v3,v2,
                                          texture,
                                          Vec2.add(notClippedTx[1], Vec2.mul(Vec2.sub(clippedTx[0], notClippedTx[1]),fr1)),
                                          Vec2.add(notClippedTx[0], Vec2.mul(Vec2.sub(clippedTx[0], notClippedTx[0]),fr0)),
                                          notClippedTx[1]));
                }
            }
            break;
        case 0:
            // Should never happen!
        }
    }    
}
