#!/bin/sh

rm -rf ~/.java
rm *.class

javac *java

jar cvf WClock.jar *.class

tar cvzf WClock.tar.gz WClock.java test.html make.sh

mozilla file://`pwd`/test.html
#appletviewer test.html