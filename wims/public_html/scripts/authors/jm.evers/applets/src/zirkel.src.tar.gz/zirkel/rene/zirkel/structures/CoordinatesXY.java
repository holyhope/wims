package rene.zirkel.structures;

// file: CoordinatesXY.java

public class CoordinatesXY
{	public double X,Y;
	public CoordinatesXY (double x, double y)
	{	X=x; Y=y;
	}
}
