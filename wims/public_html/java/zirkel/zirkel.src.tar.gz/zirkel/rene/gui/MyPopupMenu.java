package rene.gui;

import java.awt.Frame;
import java.awt.Window;

public class MyPopupMenu extends Window
{	public MyPopupMenu ()
	{	super(new Frame());
		setSize(200,200);
	}
}